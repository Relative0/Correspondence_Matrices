from os.path import dirname, abspath
from siliconcompiler import Design
from logikbench.benchmarks.basic.variants import BASIC_DW


class Bxnor(Design):
    def __init__(self):
        name = 'bxnor'
        root = dirname(abspath(__file__))
        super().__init__(name)
        self.add_file(f"{root}/rtl/{name}.v", 'rtl')
        self.set_topmodule(name, 'rtl')
        # self-checking testbench (`lb sim`)
        self.add_file(f"{root}/testbench/test_{name}_smoke.v", 'testbench')
        self.set_topmodule(f"test_{name}_smoke", 'testbench')

        # variants
        self.variants = {
            "DW": BASIC_DW,
        }


if __name__ == "__main__":
    d = Bxnor()
    d.write_fileset("bxnor.f", fileset="rtl")
