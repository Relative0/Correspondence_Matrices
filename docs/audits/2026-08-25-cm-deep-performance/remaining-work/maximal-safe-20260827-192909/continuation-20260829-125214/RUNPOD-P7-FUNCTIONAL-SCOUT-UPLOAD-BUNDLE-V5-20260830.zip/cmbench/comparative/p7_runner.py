"""Fail-closed Linux isolated-cell runner for the frozen P7 development study."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sys
import time
from collections.abc import Callable, Mapping, Sequence
from typing import Any

from . import linux_supervisor, p7
from .arms import execute_arm, scalar_relation, semantic_sha256
from .contracts import RESULT_STATUSES, canonical_bytes
from .corpus_freeze import validate_freeze, verify_sources
from .evidence import append_record


PLAN_SCHEMA = "cm-comparative-p7-isolated-plan/v1"
REQUEST_SCHEMA = "cm-comparative-p7-isolated-request/v1"
WORKER_SCHEMA = "cm-comparative-p7-isolated-worker/v1"
SUMMARY_SCHEMA = "cm-comparative-p7-isolated-summary/v1"
SOURCE_SCHEMA = "cm-comparative-p7-isolated-source-identity/v1"
ENVIRONMENT_SCHEMA = "cm-comparative-p7-isolated-environment/v1"
SEGMENT = re.compile(r"segment-(\d{6})\.jsonl")
MAX_REQUEST_BYTES = 64 << 10
MAX_WORKER_BYTES = 1 << 20
P7_POLICIES = frozenset(p7.P7_POLICIES)


def require(condition: Any, message: str) -> None:
    if not condition:
        raise ValueError(message)


def strict_json(payload: bytes, *, limit: int) -> Any:
    require(isinstance(payload, bytes) and 0 < len(payload) <= limit, "bounded JSON payload required")

    def pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, "duplicate JSON key")
            value[key] = item
        return value

    def constant(_value):
        raise ValueError("nonfinite JSON")

    try:
        return json.loads(payload, object_pairs_hook=pairs, parse_constant=constant)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ValueError("invalid JSON payload") from exc


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def _case_digest(case: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_bytes(case)).hexdigest()


def build_plan(
    freeze: Mapping[str, Any],
    *,
    policy_id: str,
    roles: Sequence[str],
    blocks: int,
    case_limit: int | None = None,
    profile: str = "functional",
    _validate: bool = True,
) -> dict[str, Any]:
    """Select an order-preserving bounded shard from the immutable P6 ledger."""
    validate_freeze(freeze)
    require(policy_id in P7_POLICIES, "only frozen P7 policies are executable")
    policies = {row["policy_id"]: row for row in freeze["schedule_policies"]}
    policy = policies[policy_id]
    task, bindings = p7.P7_POLICIES[policy_id]
    require(policy["task"] == task and policy["arms"] == list(bindings), "P7 binding changed")
    selected_roles = tuple(roles)
    require(
        selected_roles
        and len(set(selected_roles)) == len(selected_roles)
        and set(selected_roles).issubset(policy["eligible_roles"]),
        "invalid P7 roles",
    )
    require(type(blocks) is int and 1 <= blocks <= policy["maximum_blocks"], "invalid block bound")
    performance = profile == "performance"
    require(profile in {"functional", "performance"}, "invalid runner profile")
    cycle = 2 * len(policy["arms"])
    if performance:
        require(
            policy["minimum_blocks"] <= blocks <= policy["maximum_blocks"]
            and blocks % cycle == 0,
            "performance blocks must contain complete frozen counterbalance cycles",
        )
    require(case_limit is None or type(case_limit) is int and 1 <= case_limit <= 10_000, "invalid case limit")
    cases = {row["case_id"]: row for row in freeze["cases"]}
    eligible = {
        case_id for case_id, case in cases.items()
        if case["role"] in selected_roles and task in case["tasks"]
    }
    ordered: list[str] = []
    for row in policy["order_ledger"]:
        if row["case_id"] in eligible and row["case_id"] not in ordered:
            ordered.append(row["case_id"])
    if case_limit is not None:
        ordered = ordered[:case_limit]
    require(ordered, "P7 selection has no cases")
    selected = set(ordered)
    schedule_rows = [
        row for row in policy["order_ledger"]
        if row["case_id"] in selected and row["block"] < blocks
    ]
    require(len(schedule_rows) == len(ordered) * blocks, "frozen order-ledger coverage mismatch")
    cells: list[dict[str, Any]] = []
    seen_case_blocks: set[tuple[str, int]] = set()
    for schedule_position, row in enumerate(schedule_rows):
        case = cases[row["case_id"]]
        key = (row["case_id"], row["block"])
        require(key not in seen_case_blocks, "duplicate frozen case/block")
        seen_case_blocks.add(key)
        require(
            row["policy_id"] == policy_id
            and row["task"] == task
            and row["cluster_id"] == case["cluster_id"]
            and row["arm_order"] and set(row["arm_order"]) == set(policy["arms"]),
            "frozen order row changed",
        )
        for arm_position, arm in enumerate(row["arm_order"]):
            core = {
                "policy_id": policy_id,
                "task": task,
                "case_id": row["case_id"],
                "cluster_id": case["cluster_id"],
                "role": case["role"],
                "case_sha256": _case_digest(case),
                "block": row["block"],
                "schedule_position": schedule_position,
                "arm": arm,
                "arm_position": arm_position,
                "order_sha256": row["order_sha256"],
                "conditional_extension": row["conditional_extension"],
            }
            cells.append({**core, "cell_id": hashlib.sha256(canonical_bytes(core)).hexdigest()})
    core_plan = {
        "schema": PLAN_SCHEMA,
        "freeze_sha256": freeze["freeze_sha256"],
        "policy_id": policy_id,
        "task": task,
        "roles": list(selected_roles),
        "profile": profile,
        "performance_measurement": performance,
        "blocks": blocks,
        "arms": list(policy["arms"]),
        "case_ids": ordered,
        "cells": cells,
    }
    plan = {**core_plan, "plan_sha256": hashlib.sha256(canonical_bytes(core_plan)).hexdigest()}
    if _validate:
        validate_plan(plan, freeze)
    return plan


def validate_plan(plan: Mapping[str, Any], freeze: Mapping[str, Any]) -> None:
    expected = {
        "schema", "freeze_sha256", "policy_id", "task", "roles", "profile",
        "performance_measurement", "blocks", "arms", "case_ids", "cells", "plan_sha256",
    }
    require(isinstance(plan, Mapping) and set(plan) == expected and plan["schema"] == PLAN_SCHEMA, "plan fields")
    core = {key: plan[key] for key in expected if key != "plan_sha256"}
    require(plan["plan_sha256"] == hashlib.sha256(canonical_bytes(core)).hexdigest(), "plan identity")
    # Avoid recursive reconstruction; validate every frozen identity directly.
    require(plan["freeze_sha256"] == freeze["freeze_sha256"], "freeze identity")
    require(plan["policy_id"] in P7_POLICIES and plan["task"] == p7.P7_POLICIES[plan["policy_id"]][0], "plan policy")
    require(plan["performance_measurement"] is (plan["profile"] == "performance"), "profile flag")
    ids = []
    for cell in plan["cells"]:
        require(isinstance(cell, Mapping) and set(cell) == {
            "policy_id", "task", "case_id", "cluster_id", "role", "case_sha256", "block",
            "schedule_position", "arm", "arm_position", "order_sha256", "conditional_extension", "cell_id",
        }, "cell fields")
        core_cell = {key: cell[key] for key in cell if key != "cell_id"}
        require(cell["cell_id"] == hashlib.sha256(canonical_bytes(core_cell)).hexdigest(), "cell identity")
        require(cell["case_id"] in plan["case_ids"] and cell["arm"] in plan["arms"], "cell membership")
        ids.append(cell["cell_id"])
    require(ids and len(ids) == len(set(ids)), "cell cardinality")
    expected_plan = build_plan(
        freeze,
        policy_id=plan["policy_id"],
        roles=plan["roles"],
        blocks=plan["blocks"],
        case_limit=len(plan["case_ids"]),
        profile=plan["profile"],
        _validate=False,
    )
    require(dict(plan) == expected_plan, "plan differs from frozen order ledger")


def case_oracles(plan: Mapping[str, Any], freeze: Mapping[str, Any], project_root: Path) -> dict[str, str]:
    cases = {row["case_id"]: row for row in freeze["cases"]}
    output = {}
    for case_id in plan["case_ids"]:
        expression, variables = p7.load_case_expression(cases[case_id], project_root)
        relation = scalar_relation(expression, variables, {})
        output[case_id] = semantic_sha256(relation, len(variables))
    return output


def request_for(plan: Mapping[str, Any], cell: Mapping[str, Any], oracle_sha256: str) -> dict[str, Any]:
    request = {
        "schema": REQUEST_SCHEMA,
        "freeze_sha256": plan["freeze_sha256"],
        "plan_sha256": plan["plan_sha256"],
        "cell_id": cell["cell_id"],
        "policy_id": cell["policy_id"],
        "task": cell["task"],
        "case_id": cell["case_id"],
        "arm": cell["arm"],
        "oracle_sha256": oracle_sha256,
        "performance_measurement": plan["performance_measurement"],
    }
    require(len(canonical_bytes(request)) <= MAX_REQUEST_BYTES, "worker request bound")
    return request


def _pin_worker() -> list[int]:
    if not hasattr(os, "sched_getaffinity") or not hasattr(os, "sched_setaffinity"):
        return []
    available = sorted(os.sched_getaffinity(0))
    require(available, "empty worker affinity")
    os.sched_setaffinity(0, {available[0]})
    return sorted(os.sched_getaffinity(0))


def execute_worker(
    request: Mapping[str, Any],
    freeze: Mapping[str, Any],
    project_root: Path,
    *,
    clock=time.perf_counter_ns,
) -> dict[str, Any]:
    validate_freeze(freeze)
    expected = {
        "schema", "freeze_sha256", "plan_sha256", "cell_id", "policy_id", "task",
        "case_id", "arm", "oracle_sha256", "performance_measurement",
    }
    require(isinstance(request, Mapping) and set(request) == expected and request["schema"] == REQUEST_SCHEMA, "request fields")
    require(request["freeze_sha256"] == freeze["freeze_sha256"], "request freeze identity")
    require(request["policy_id"] in P7_POLICIES, "request policy")
    task, bindings = p7.P7_POLICIES[request["policy_id"]]
    require(request["task"] == task and request["arm"] in bindings, "request task/arm")
    cases = [row for row in freeze["cases"] if row["case_id"] == request["case_id"]]
    require(len(cases) == 1 and task in cases[0]["tasks"], "request case")
    expression, variables = p7.load_case_expression(cases[0], project_root)
    affinity = _pin_worker()
    if task == "ir_preparation":
        result = p7.execute_ir_cell(expression, variables, request["arm"], clock=clock)
    else:
        implementation, _artifact = p7.RELATION_ARMS[request["arm"]]
        result_row = execute_arm(
            expr=expression,
            contract=p7._relation_contract(
                request["arm"], variables, request["oracle_sha256"], lifecycle="fresh_process",
            ),
            case_id=request["case_id"],
            arm=implementation,
            smoke_bound=16,
            clock=clock,
        )
        result = {
            "arm": request["arm"],
            "artifact_kind": result_row["artifact"]["kind"],
            "artifact_sha256": result_row["artifact"]["sha256"],
            "semantic_sha256": result_row["artifact"]["sha256"],
            "timings_ns": {"task_total_wall_ns": result_row["timings_ns"]["task_total_ns"]},
            "validation_in_timed_span": False,
        }
    return {
        "schema": WORKER_SCHEMA,
        "cell_id": request["cell_id"],
        "policy_id": request["policy_id"],
        "task": task,
        "case_id": request["case_id"],
        "arm": request["arm"],
        "status": "ok",
        "artifact_kind": result["artifact_kind"],
        "artifact_sha256": result["artifact_sha256"],
        "semantic_sha256": result["semantic_sha256"],
        "timings_ns": result["timings_ns"],
        "validation_in_timed_span": False,
        "performance_measurement": request["performance_measurement"],
        "environment": {"pid": os.getpid(), "affinity": affinity},
    }


def validate_worker(
    payload: bytes,
    request: Mapping[str, Any],
) -> dict[str, Any]:
    result = strict_json(payload, limit=MAX_WORKER_BYTES)
    expected = {
        "schema", "cell_id", "policy_id", "task", "case_id", "arm", "status",
        "artifact_kind", "artifact_sha256", "semantic_sha256", "timings_ns",
        "validation_in_timed_span", "performance_measurement", "environment",
    }
    require(isinstance(result, Mapping) and set(result) == expected and result["schema"] == WORKER_SCHEMA, "worker fields")
    for key in ("cell_id", "policy_id", "task", "case_id", "arm", "performance_measurement"):
        require(result[key] == request[key], "worker identity mismatch")
    require(result["status"] == "ok" and result["validation_in_timed_span"] is False, "worker status")
    duration = result["timings_ns"].get("task_total_wall_ns") if isinstance(result["timings_ns"], Mapping) else None
    require(type(duration) is int and duration > 0, "worker duration")
    for key in ("artifact_sha256", "semantic_sha256"):
        value = result[key]
        require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value), "worker digest")
    return dict(result)


def execute_cell(
    *,
    plan: Mapping[str, Any],
    cell: Mapping[str, Any],
    oracle_sha256: str,
    python: Path,
    worker_program: Path,
    project_root: Path,
    freeze_path: Path,
    limits: linux_supervisor.Limits,
    supervise: Callable[..., Any] = linux_supervisor.run,
) -> tuple[dict[str, Any], dict[str, Any]]:
    request = request_for(plan, cell, oracle_sha256)
    request_bytes = canonical_bytes(request)
    request_sha = hashlib.sha256(request_bytes).hexdigest()
    supervised = supervise(
        [str(python.resolve()), "-B", str(worker_program.resolve()), "worker",
         "--project-root", str(project_root.resolve()), "--freeze", str(freeze_path.resolve())],
        input=request_bytes,
        cwd=project_root,
        limits=limits,
    )
    status = supervised.status
    reason = supervised.reason
    worker = None
    if status == "ok":
        try:
            worker = validate_worker(supervised.stdout, request)
        except ValueError as exc:
            status, reason = "error", "invalid_worker_output:" + str(exc)
        else:
            if worker["semantic_sha256"] != oracle_sha256:
                status, reason = "mismatch", "outside_span_scalar_oracle_mismatch"
    resources = dict(supervised.resources)
    if resources.get("cleanup_verified") is not True or resources.get("streams_closed") is not True:
        status, reason = "error", "cleanup_or_streams_unverified"
    require(status in RESULT_STATUSES, "unknown supervisor result")
    result = {
        "status": status,
        "reason": reason,
        "worker": worker,
        "timings_ns": {
            "task_total_wall_ns": worker["timings_ns"]["task_total_wall_ns"] if worker else None,
            "fresh_process_controller_wall_ns": supervised.wall_ns,
        },
        "process_tree_peak_rss_bytes": resources.get("peak_sampled_tree_rss_bytes"),
        "resources": resources,
        "returncode": supervised.returncode,
        "stdout_sha256": hashlib.sha256(supervised.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(supervised.stderr).hexdigest(),
        "outside_span_validation": True,
        "performance_measurement": plan["performance_measurement"],
    }
    return result, {"request": request, "request_sha256": request_sha}


def new_segment(directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    indices = []
    for path in directory.iterdir():
        match = SEGMENT.fullmatch(path.name)
        require(match is not None and path.is_file(), "unexpected ledger segment entry")
        indices.append(int(match.group(1)))
    expected = list(range(len(indices)))
    require(sorted(indices) == expected, "ledger segments are not contiguous")
    path = directory / f"segment-{len(indices):06}.jsonl"
    path.touch(exist_ok=False)
    return path


def read_segments(directory: Path) -> dict[str, Any]:
    require(directory.is_dir(), "ledger segment directory missing")
    paths = sorted(directory.iterdir())
    require(paths and all(SEGMENT.fullmatch(path.name) and path.is_file() for path in paths), "invalid ledger segments")
    histories: dict[str, list[dict[str, Any]]] = {}
    partial_tails = []
    for path in paths:
        raw = path.read_bytes()
        for index, line in enumerate(raw.splitlines()):
            try:
                row = strict_json(line, limit=MAX_WORKER_BYTES)
            except ValueError:
                require(index == len(raw.splitlines()) - 1 and not raw.endswith(b"\n"), "corrupt complete ledger record")
                partial_tails.append(path.name)
                break
            require(isinstance(row, Mapping) and isinstance(row.get("cell_id"), str), "ledger row")
            require(type(row.get("attempt")) is int and row["attempt"] >= 1, "ledger attempt")
            require(row.get("status") in RESULT_STATUSES | {"running"}, "ledger status")
            history = histories.setdefault(row["cell_id"], [])
            if not history:
                require(row["status"] == "running" and row["attempt"] == 1, "first ledger transition")
            else:
                prior = history[-1]
                if prior["status"] == "running":
                    require(row["status"] != "running" and row["attempt"] == prior["attempt"], "terminal ledger transition")
                    require(row.get("request_sha256") == prior.get("request_sha256"), "request identity changed")
                else:
                    require(
                        prior.get("reason") == "interrupted_before_terminal_evidence"
                        and row["status"] == "running"
                        and row["attempt"] == prior["attempt"] + 1,
                        "unexpected cell retry",
                    )
            history.append(dict(row))
    latest = {cell: rows[-1] for cell, rows in histories.items()}
    return {"histories": histories, "latest": latest, "partial_tail_segments": partial_tails}


def recover_interrupted(state: Mapping[str, Any], segment: Path) -> list[str]:
    recovered = []
    for cell_id, row in sorted(state["latest"].items()):
        if row["status"] == "running":
            append_record(segment, {
                "cell_id": cell_id,
                "request_sha256": row["request_sha256"],
                "attempt": row["attempt"],
                "status": "error",
                "reason": "interrupted_before_terminal_evidence",
            })
            recovered.append(cell_id)
    return recovered


def reconcile(plan: Mapping[str, Any], state: Mapping[str, Any]) -> dict[str, Any]:
    planned = {row["cell_id"] for row in plan["cells"]}
    latest = state["latest"]
    observed = set(latest)
    statuses: dict[str, int] = {}
    for row in latest.values():
        statuses[row["status"]] = statuses.get(row["status"], 0) + 1
    return {
        "planned_cells": len(planned),
        "observed_cells": len(observed),
        "missing_cells": sorted(planned - observed),
        "unexpected_cells": sorted(observed - planned),
        "running_cells": sorted(cell for cell, row in latest.items() if row["status"] == "running"),
        "partial_tail_segments": state["partial_tail_segments"],
        "statuses": dict(sorted(statuses.items())),
        "complete": planned == observed and not any(row["status"] == "running" for row in latest.values()),
    }


def validate_state(
    plan: Mapping[str, Any],
    state: Mapping[str, Any],
    oracles: Mapping[str, str],
) -> None:
    cells = {row["cell_id"]: row for row in plan["cells"]}
    require(set(state["latest"]).issubset(cells), "ledger contains unexpected cells")
    require(set(oracles) == set(plan["case_ids"]), "oracle case coverage")
    for case_id, digest in oracles.items():
        require(isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest), "oracle digest")
    for cell_id, history in state["histories"].items():
        cell = cells[cell_id]
        expected_request = request_for(plan, cell, oracles[cell["case_id"]])
        expected_sha = hashlib.sha256(canonical_bytes(expected_request)).hexdigest()
        for row in history:
            require(row.get("request_sha256") == expected_sha, "ledger request identity")
            if row["status"] == "running" or row.get("reason") == "interrupted_before_terminal_evidence":
                continue
            result = row.get("result")
            require(isinstance(result, Mapping) and result.get("status") == row["status"], "terminal result identity")
            resources = result.get("resources")
            require(
                isinstance(resources, Mapping)
                and resources.get("cleanup_verified") is True
                and resources.get("streams_closed") is True,
                "terminal cleanup evidence",
            )
            require(result.get("outside_span_validation") is True, "outside-span validation evidence")
            require(result.get("performance_measurement") is plan["performance_measurement"], "performance flag")
            if row["status"] == "ok":
                worker = result.get("worker")
                require(
                    isinstance(worker, Mapping)
                    and worker.get("cell_id") == cell_id
                    and worker.get("semantic_sha256") == oracles[cell["case_id"]],
                    "successful cell semantic identity",
                )
                timings = result.get("timings_ns")
                require(
                    isinstance(timings, Mapping)
                    and type(timings.get("task_total_wall_ns")) is int
                    and timings["task_total_wall_ns"] > 0
                    and type(timings.get("fresh_process_controller_wall_ns")) is int
                    and timings["fresh_process_controller_wall_ns"] > 0,
                    "successful cell timing evidence",
                )
                require(
                    type(result.get("process_tree_peak_rss_bytes")) is int
                    and result["process_tree_peak_rss_bytes"] > 0
                    and resources.get("whole_tree_rss_measured") is True,
                    "successful cell RSS evidence",
                )


def source_identity(project_root: Path, freeze: Mapping[str, Any], code_paths: Sequence[str]) -> dict[str, Any]:
    verify = verify_sources(freeze, project_root)
    require(verify["verified"] is True, "frozen corpus source identity failed")
    names = set(code_paths)
    names.update(case["source"]["path"] for case in freeze["cases"])
    rows = []
    for name in sorted(names):
        path = (project_root / name).resolve()
        require(path.is_relative_to(project_root) and path.is_file() and not path.is_symlink(), "source identity path")
        rows.append({"path": name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    return {"schema": SOURCE_SCHEMA, "freeze_sha256": freeze["freeze_sha256"], "files": rows}


def environment_identity() -> dict[str, Any]:
    affinity = sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else []
    return {
        "schema": ENVIRONMENT_SCHEMA,
        "python": sys.version,
        "executable": str(Path(sys.executable).resolve()),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "logical_cpus": os.cpu_count(),
        "affinity": affinity,
        "linux_supervisor_available": linux_supervisor.platform_supported(),
    }


def summary(
    plan: Mapping[str, Any],
    state: Mapping[str, Any],
    oracles: Mapping[str, str],
    *,
    source_unchanged: bool,
) -> dict[str, Any]:
    validate_state(plan, state, oracles)
    reconciliation = reconcile(plan, state)
    ok = reconciliation["complete"] and reconciliation["statuses"] == {"ok": len(plan["cells"])}
    return {
        "schema": SUMMARY_SCHEMA,
        "freeze_sha256": plan["freeze_sha256"],
        "plan_sha256": plan["plan_sha256"],
        "policy_id": plan["policy_id"],
        "profile": plan["profile"],
        "performance_measurement": plan["performance_measurement"],
        "performance_claim_permitted": bool(plan["performance_measurement"] and ok and source_unchanged),
        "source_unchanged": source_unchanged,
        "reconciliation": reconciliation,
        "status": "passed" if ok and source_unchanged else "failed",
    }
