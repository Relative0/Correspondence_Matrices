from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest

from cmbench.comparative import linux_supervisor, p7_runner
from cmbench.comparative.contracts import canonical_bytes
from cmbench.comparative.evidence import append_record


ROOT = Path(__file__).resolve().parents[1]
FREEZE = ROOT / "docs/research/verification/comparative-p6-candidate-v4-2026-08-30/freeze.json"


class ComparativeP7RunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.freeze = json.loads(FREEZE.read_text(encoding="utf-8"))

    def plan(self):
        return p7_runner.build_plan(
            self.freeze,
            policy_id="p7-ir",
            roles=("development",),
            blocks=1,
            case_limit=1,
            profile="functional",
        )

    def test_functional_plan_preserves_frozen_order_and_performance_requires_full_cycle(self):
        plan = self.plan()
        self.assertEqual(len(plan["case_ids"]), 1)
        self.assertEqual(len(plan["cells"]), 4)
        self.assertFalse(plan["performance_measurement"])
        self.assertEqual([row["arm"] for row in plan["cells"]], [
            "cm-ir-two-memo", "cm-cse-flat", "cm-raw-flat", "cm-ir-current",
        ])
        p7_runner.validate_plan(plan, self.freeze)
        with self.assertRaises(ValueError):
            p7_runner.build_plan(
                self.freeze, policy_id="p7-ir", roles=("development",),
                blocks=1, case_limit=1, profile="performance",
            )
        performance = p7_runner.build_plan(
            self.freeze, policy_id="p7-ir", roles=("development",),
            blocks=8, case_limit=1, profile="performance",
        )
        self.assertEqual(len(performance["cells"]), 32)
        self.assertTrue(performance["performance_measurement"])
        self.assertFalse(any(row["conditional_extension"] for row in performance["cells"]))

    def _fake_supervisor(self, mutate=None):
        def supervise(_command, *, input, cwd, limits):
            request = p7_runner.strict_json(input, limit=p7_runner.MAX_REQUEST_BYTES)
            worker = p7_runner.execute_worker(
                request, self.freeze, Path(cwd), clock=iter(range(1_000_000)).__next__,
            )
            if mutate is not None:
                mutate(worker)
            return linux_supervisor.Result(
                "ok", "completed", returncode=0,
                stdout=canonical_bytes(worker) + b"\n", stderr=b"", wall_ns=123456,
                resources={
                    "cleanup_verified": True, "streams_closed": True,
                    "whole_tree_rss_measured": True,
                    "peak_sampled_tree_rss_bytes": 1234,
                },
            )
        return supervise

    def test_cell_success_is_exact_and_validation_is_outside_timed_span(self):
        plan = self.plan()
        cell = plan["cells"][0]
        oracle = p7_runner.case_oracles(plan, self.freeze, ROOT)[cell["case_id"]]
        result, request = p7_runner.execute_cell(
            plan=plan, cell=cell, oracle_sha256=oracle,
            python=Path(__file__), worker_program=Path(__file__), project_root=ROOT,
            freeze_path=FREEZE, limits=linux_supervisor.Limits(),
            supervise=self._fake_supervisor(),
        )
        self.assertEqual(result["status"], "ok")
        self.assertTrue(result["outside_span_validation"])
        self.assertEqual(result["worker"]["semantic_sha256"], oracle)
        self.assertGreater(result["timings_ns"]["task_total_wall_ns"], 0)
        self.assertEqual(result["process_tree_peak_rss_bytes"], 1234)
        self.assertEqual(len(request["request_sha256"]), 64)

    def test_complete_relation_worker_uses_fresh_process_contract_and_exact_oracle(self):
        plan = p7_runner.build_plan(
            self.freeze,
            policy_id="p7-relation",
            roles=("development",),
            blocks=1,
            case_limit=1,
            profile="functional",
        )
        cell = plan["cells"][0]
        oracle = p7_runner.case_oracles(plan, self.freeze, ROOT)[cell["case_id"]]
        result, _ = p7_runner.execute_cell(
            plan=plan, cell=cell, oracle_sha256=oracle,
            python=Path(__file__), worker_program=Path(__file__), project_root=ROOT,
            freeze_path=FREEZE, limits=linux_supervisor.Limits(),
            supervise=self._fake_supervisor(),
        )
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["worker"]["semantic_sha256"], oracle)
        self.assertIn(result["worker"]["artifact_kind"],
                      {"dense_cm", "packed_bigint", "packed_words"})

    def test_mismatch_timeout_and_cleanup_fail_closed(self):
        plan = self.plan()
        cell = plan["cells"][0]
        oracle = p7_runner.case_oracles(plan, self.freeze, ROOT)[cell["case_id"]]

        def mismatch(worker):
            worker["semantic_sha256"] = "0" * 64

        result, _ = p7_runner.execute_cell(
            plan=plan, cell=cell, oracle_sha256=oracle,
            python=Path(__file__), worker_program=Path(__file__), project_root=ROOT,
            freeze_path=FREEZE, limits=linux_supervisor.Limits(),
            supervise=self._fake_supervisor(mismatch),
        )
        self.assertEqual((result["status"], result["reason"]),
                         ("mismatch", "outside_span_scalar_oracle_mismatch"))

        for supervised, expected in (
            (linux_supervisor.Result(
                "refused", "linux_proc_process_group_unavailable", wall_ns=1,
                resources={"cleanup_verified": True, "streams_closed": True}), "refused"),
            (linux_supervisor.Result(
                "timeout", "worker_deadline", wall_ns=1,
                resources={"cleanup_verified": True, "streams_closed": True}), "timeout"),
            (linux_supervisor.Result(
                "ok", "completed", stdout=b"{}", wall_ns=1,
                resources={"cleanup_verified": False, "streams_closed": True}), "error"),
        ):
            with self.subTest(expected=expected):
                result, _ = p7_runner.execute_cell(
                    plan=plan, cell=cell, oracle_sha256=oracle,
                    python=Path(__file__), worker_program=Path(__file__), project_root=ROOT,
                    freeze_path=FREEZE, limits=linux_supervisor.Limits(),
                    supervise=lambda *_args, **_kwargs: supervised,
                )
                self.assertEqual(result["status"], expected)

    def test_segmented_resume_preserves_interrupted_attempt_and_retries_exact_request(self):
        cell = self.plan()["cells"][0]
        with tempfile.TemporaryDirectory(prefix="cm-p7-ledger-") as directory:
            root = Path(directory)
            first = p7_runner.new_segment(root)
            append_record(first, {
                "cell_id": cell["cell_id"], "request_sha256": "1" * 64,
                "attempt": 1, "status": "running",
            })
            second = p7_runner.new_segment(root)
            recovered = p7_runner.recover_interrupted(p7_runner.read_segments(root), second)
            self.assertEqual(recovered, [cell["cell_id"]])
            append_record(second, {
                "cell_id": cell["cell_id"], "request_sha256": "1" * 64,
                "attempt": 2, "status": "running",
            })
            append_record(second, {
                "cell_id": cell["cell_id"], "request_sha256": "1" * 64,
                "attempt": 2, "status": "ok", "reason": "completed",
            })
            state = p7_runner.read_segments(root)
        self.assertEqual([row["status"] for row in state["histories"][cell["cell_id"]]],
                         ["running", "error", "running", "ok"])
        self.assertEqual(state["latest"][cell["cell_id"]]["attempt"], 2)

    def test_successful_ledger_state_requires_primary_metrics_cleanup_and_oracle_identity(self):
        plan = self.plan()
        cell = plan["cells"][0]
        oracle = p7_runner.case_oracles(plan, self.freeze, ROOT)[cell["case_id"]]
        result, request = p7_runner.execute_cell(
            plan=plan, cell=cell, oracle_sha256=oracle,
            python=Path(__file__), worker_program=Path(__file__), project_root=ROOT,
            freeze_path=FREEZE, limits=linux_supervisor.Limits(),
            supervise=self._fake_supervisor(),
        )
        history = [{
            "cell_id": cell["cell_id"], "request_sha256": request["request_sha256"],
            "attempt": 1, "status": "running",
        }, {
            "cell_id": cell["cell_id"], "request_sha256": request["request_sha256"],
            "attempt": 1, "status": "ok", "reason": "completed", "result": result,
        }]
        state = {
            "histories": {cell["cell_id"]: history},
            "latest": {cell["cell_id"]: history[-1]},
            "partial_tail_segments": [],
        }
        p7_runner.validate_state(plan, state, {cell["case_id"]: oracle})
        result["process_tree_peak_rss_bytes"] = 0
        with self.assertRaises(ValueError):
            p7_runner.validate_state(plan, state, {cell["case_id"]: oracle})


if __name__ == "__main__":
    unittest.main()
