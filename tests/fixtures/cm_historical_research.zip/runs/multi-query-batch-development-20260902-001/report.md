# Multi-query exact batching development result

Status: **complete**

All eight methods delivered byte-identical exact prefix documents.

| Q | Best fixed | Best batch | Batch vs best nonbatch | CSE words vs bigint | CM words vs bigint |
|---:|---|---|---:|---:|---:|
| 1 | r2_per_query | concatenated_r2 | 0.1879x | 0.8035x | 0.9178x |
| 4 | r2_per_query | concatenated_r2 | 0.0997x | 0.7094x | 0.8485x |
| 16 | cse_bigint | union_care_r2 | 0.0524x | 0.6037x | 0.7134x |
| 64 | cse_bigint | union_care_r2 | 0.0447x | 0.5698x | 0.6112x |

## Decision

The q64 batch continuation gate **did not pass**. The best batch was `union_care_r2` at 0.0447x versus the best nonbatch backend.

The overall q64 best fixed arm was `cse_bigint`.
No formal confirmation or production promotion is permitted by this exposed-data run.
