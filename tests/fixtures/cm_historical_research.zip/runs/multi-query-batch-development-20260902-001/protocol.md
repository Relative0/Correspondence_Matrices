# Multi-query exact batching development protocol

Run ID: `multi-query-batch-development-20260902-001`

Development-only use of the exposed C36 corpus; not C37 confirmation.
The frozen relation/count/SAT/witness delivery semantics and variable order
are retained for independent q1, q4, q16, and q64 prefix tasks.

Arms: repaired R2 per-query restriction, CSE bigint/words, CM-IR
bigint/words, concatenated arbitrary lanes, union-care arbitrary lanes,
and compiled full-truth projection.

Dataset: `docs/recognition/c36_wide_repeated_query_dataset.json`
Dataset verification: `docs/recognition/c36_wide_repeated_query_dataset_verification.json`
Blocks: 8; seed: 20260902; continuation gate: 1.10x over the best nonbatch backend at q64.

All decode, representation, batch/restriction setup, evaluation, delivery,
and cleanup costs are charged. Memory sessions are separate and excluded
from performance summaries. No threshold/model fitting or promotion is allowed.
