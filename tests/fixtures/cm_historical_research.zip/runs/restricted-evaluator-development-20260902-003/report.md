# Restricted evaluator development result

Status: **complete**

All six methods produced byte-identical canonical C36 deliveries with zero
relation, count, SAT, or witness mismatches.

| Q | Best fixed | R1 vs R0 | R2 vs R0 | R2 vs R1 |
|---:|---|---:|---:|---:|
| 1 | restricted_r1_identity_memo | 2.5142x | 2.1031x | 0.8365x |
| 4 | restricted_r2_topological_liveness | 3.9576x | 4.0444x | 1.0219x |
| 16 | restricted_r2_topological_liveness | 5.3136x | 6.1343x | 1.1545x |
| 64 | restricted_r2_topological_liveness | 6.1481x | 7.5555x | 1.2289x |

## Measured conclusion

The memoization finding is **supported** on this development run. The fastest repaired direct arm is `restricted_r2_topological_liveness`.

The recomputed q64 best fixed backend is `restricted_r2_topological_liveness`. The optimized per-case oracle retains 1.0004x headroom over the best optimized fixed backend.

The descriptive high-expansion subgroup contains 4 cases and its best optimized arm is `restricted_r2_topological_liveness`. This is exposed-data diagnosis, not a frozen routing policy.

Memory-profile timings were excluded from performance aggregates. RSS values are
stage-boundary samples plus the process-wide high-water mark; tracemalloc reports
Python allocations for the separate profile sessions.

No C37 or production promotion is permitted by this result.
