# Restricted evaluator development protocol

Run ID: `restricted-evaluator-development-20260902-003`

Status: development-only, exposed C36 data; not prospective C37 evidence.

The exact C36 task contract is unchanged: each of 64 restrictions must emit
the reduced relation, relation digest, exact count, SAT status, and canonical
witness in the frozen remaining-variable order.

Compared arms: R0 occurrence recursion, R1 query-local identity memoization,
R2 topological DAG-v2 slots with last-use release, flattened CSE words, CM-IR
words, and compiled full-truth projection.

Dataset: `docs/recognition/c36_wide_repeated_query_dataset.json`
Dataset verification: `docs/recognition/c36_wide_repeated_query_dataset_verification.json`
Counterbalanced blocks: 12; seed: 20260902.

Performance rows run without tracemalloc. Separate memory-profile rows run once
per case/arm with tracemalloc and are excluded from performance aggregation.
RSS is sampled at stage boundaries; process peak RSS is an OS high-water mark.
R0 remains available unchanged in the C36 module; its development control only
splits environment construction from the same recursive gate evaluation.

No threshold is fitted, no confirmation data is consumed, and no production
write or promotion is authorized by this run.
