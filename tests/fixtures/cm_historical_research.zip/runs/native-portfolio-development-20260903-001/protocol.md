# Native exact-portfolio development protocol

Development-only, cache-isolated q64 comparison on the exposed C36 cohort. The arms are R2, CSE bigint/words, CM-IR bigint/words, uint16 projection, and fused native slots. Every arm returns the identical relation/count/SAT/witness delivery. Memory sessions are excluded from timing. No prospective data, training, routing, or production promotion.
