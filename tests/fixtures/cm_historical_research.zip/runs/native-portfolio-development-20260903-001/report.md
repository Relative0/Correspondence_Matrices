# Native exact-portfolio development result

Best fixed method: `native_fused_slots`. Native: 111.451 ms; best non-native `cse_bigint`: 141.849 ms. Native speedup over that baseline: 1.2727x. Per-case oracle headroom: 1.000000x. Prospective gate: false.
