# C36 wider natural repeated-query adjudication

Status: **complete**

Eighteen fresh parameter/truth identities from the pinned Yosys source cover
widths 11-16 with three cases per width. All timed methods deliver the same
reduced relation, exact count, SAT status, and canonical witness.

| Queries | Best fixed | CM vs CSE | CM vs direct | CM vs compiled projection |
|---:|---|---:|---:|---:|
| 1 | flattened_cse_words | 0.4313x | 0.6403x | 3.9260x |
| 4 | flattened_cse_words | 0.5410x | 1.5942x | 3.1779x |
| 16 | flattened_cse_words | 0.7153x | 3.5346x | 1.9507x |
| 64 | flattened_cse_words | 0.8783x | 5.3326x | 0.9376x |

Frozen CM gate: **fail**.
Post-hoc family-rule speedup after frozen routing budget: **1.2841x**.
This is exploratory headroom only; the rule was observed on these cases.
