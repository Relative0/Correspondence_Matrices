# Neural architecture reassessment development artifact

Status: **training stopped by the exact-economics gate**

This artifact consumes exposed C36 development evidence only. It does not train a model,
change production routing, consume prospective data, or promote a backend.

## Recomputed economics

- Post-R2 word-portfolio oracle headroom: `1.000415621x`.
- Current bigint-engine oracle headroom: `1.000000000x`.
- Current best fixed development arm: `cse_bigint`.
- Optimistic feature-only charged speedup: `0.974698612x`.
- Model inference, exact verification, and fallback were set to zero for that optimistic bound.

## Decision

Pre-R2 family labels and post-R2 word-only labels are rejected for training. The verified
bigint comparison labels all 18 exposed cases `cse_bigint`, leaving no decision for a
selector to learn. Existing C5 decomposition models remain frozen negative research
artifacts; no architecture or hyperparameter update is scientifically justified.
