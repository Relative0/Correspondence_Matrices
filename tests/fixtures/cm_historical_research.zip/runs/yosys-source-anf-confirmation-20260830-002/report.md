# Yosys independent source-ANF confirmation

Status: **complete**

| Method / split | Median total ns | p95 total ns | Maximum total ns |
| --- | ---: | ---: | ---: |
| bitset_truth_vector_anf/sealed_a | 143500 | 1264600 | 1401500 |
| bitset_truth_vector_anf/sealed_b | 182350 | 2835700 | 5915200 |
| cached_packed_source_anf/sealed_a | 127700 | 668700 | 738000 |
| cached_packed_source_anf/sealed_b | 166450 | 1388400 | 2562300 |
| numpy_truth_vector_anf/sealed_a | 272000 | 1451500 | 1529900 |
| numpy_truth_vector_anf/sealed_b | 359100 | 3035200 | 6128100 |
| packed_source_anf/sealed_a | 121300 | 657300 | 738400 |
| packed_source_anf/sealed_b | 167300 | 1353700 | 2567600 |
| set_source_anf/sealed_a | 65800 | 574000 | 738400 |
| set_source_anf/sealed_b | 68150 | 1205700 | 2385300 |

The NumPy path preserves the C6 reference contract. The bigint path is a stronger production-style truth-vector control.

Criteria: `{"c6_baseline_cost": true, "exact": true, "independent_source": true, "legacy_set_cost": false, "production_promotion": false, "safety": true, "strong_baseline_cost": true}`
