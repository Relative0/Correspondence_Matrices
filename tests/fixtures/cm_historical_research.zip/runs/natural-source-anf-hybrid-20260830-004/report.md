# Natural source ANF hybrid run

Status: **complete**

Validation-frozen product-pair budget: **16789**.

| Method / split | Median total ns | p95 total ns | Maximum total ns | Fallbacks |
| --- | ---: | ---: | ---: | ---: |
| budgeted_hybrid/confirmatory | 399500 | 7506500 | 9013200 | 7 |
| budgeted_hybrid/test | 538150 | 2790200 | 3900400 | 0 |
| budgeted_hybrid/train | 400750 | 3341000 | 7055000 | 2 |
| budgeted_hybrid/validation | 472600 | 2677100 | 3291500 | 2 |
| cached_packed_source_anf/confirmatory | 349600 | 4033500 | 5820400 | 0 |
| cached_packed_source_anf/test | 530550 | 2771400 | 3887900 | 0 |
| cached_packed_source_anf/train | 396400 | 3279000 | 4699800 | 0 |
| cached_packed_source_anf/validation | 470650 | 2602000 | 2633700 | 0 |
| packed_source_anf/confirmatory | 382450 | 4115300 | 5641300 | 0 |
| packed_source_anf/test | 544050 | 2779300 | 3804000 | 0 |
| packed_source_anf/train | 406350 | 3264700 | 4736500 | 0 |
| packed_source_anf/validation | 537850 | 2459700 | 2533100 | 0 |
| set_source_anf/confirmatory | 466400 | 61379200 | 160294400 | 0 |
| set_source_anf/test | 326300 | 2617200 | 3407600 | 0 |
| set_source_anf/train | 319450 | 3415000 | 6167600 | 0 |
| set_source_anf/validation | 400000 | 3393700 | 3863500 | 0 |
| truth_vector_anf/confirmatory | 572350 | 7404900 | 8319800 | 0 |
| truth_vector_anf/test | 696850 | 6029500 | 6430700 | 0 |
| truth_vector_anf/train | 522950 | 6308400 | 7205800 | 0 |
| truth_vector_anf/validation | 612000 | 2183000 | 2264400 | 0 |

All paths are exact. Source proposals are accepted only at the retained exact boundary; budget refusal switches to truth-vector ANF.

Criteria: `{"cached_packed_core": true, "exact": true, "fallback": true, "median_speed": true, "p95_tail": false, "packed_core": true, "production_promotion": false, "safety": true, "source_hybrid": false, "telemetry": true}`
