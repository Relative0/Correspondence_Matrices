# Gate A successor repair prompt: timing stability only

Continue from the Gate A v4 NO-GO package dated 23 September 2026. Do not run the confirmatory campaign, do not inspect any confirmatory result, and do not alter or clean `C:\Users\brian\Documents\CM_Computation`.

The source, compiler boundary, endpoint adapters, generated corpora, schedules, schema, analyzer, natural intake, and native tools are already qualified. Preserve them exactly unless a prospective timing-policy revision requires a numbered Protocol v5. The only active blocker is the v4 repeatability gate.

Four completed exploratory pilots retained the same 100 primary cases, 11 repetitions, one fresh process per observation, one timed API call, MAD/median limit 0.05 for every case/arm, and timer-overhead limit 0.01. Timer overhead passed in every run. Repeatability failed in every run:

- `pilot-v4-wsl-20260923-01`: 17 of 200 controls failed;
- `pilot-v4-wsl-20260923-03`: 56 of 200 failed after native-filesystem staging;
- `pilot-v4-wsl-20260923-04`: 14 of 200 failed with CPU 0 affinity and nice -20;
- `pilot-v4-wsl-20260923-05`: 20 of 200 failed with CPU 11 affinity and nice -20.

Use no relative arm speed or favorable formula outcome to choose the repair. Select controls only for stability and reproducibility.

1. First try a stable bare-metal Linux or otherwise controlled host where the CPU model, kernel, power policy, affinity, priority, background-workload exclusion, Python/NumPy versions, and timer are all freezeable. Keep the v4 single-call estimand and the 0.05/0.01 limits unchanged. Run a new full 100-case `pilot-*` identity. A pass requires all 200 case/arm controls to pass.
2. If no available host passes, do not relax the 0.05 limit and do not promote a partial pass. Draft Protocol v5 prospectively. Define a robust timing unit that keeps arm-specific preparation charged, reconstructs inputs and resets workload caches independently, avoids warm-cache inner-loop substitution, and yields a stable per-observation statistic. Justify the estimand change before collecting a new pilot. Update the manuscript, schema, runner, analyzer, adversarial tests, schedules if affected, and contract matrix.
3. Retain every attempted pilot and setup failure by hash. Keep all pilot identities distinct from confirmatory identities.
4. After one full pilot passes, bind that exact environment and control policy. Reconfirm commit `0ab8ffd0c23ffa71ee951d375b1c170ffdcc084b`, the 187-file clean closure, every external repair hash, all corpora and schedules, native CUDD and ABC/Yosys identities, the memory metric, schema, analyzer, and five empty append-only result files.
5. Rerun 147 focused source tests, all 95 tests in the 17 boundary categories, the v4/v5 adversarial suite, 333,794 finite checks, 1,000-case CUDD equivalence, and 142-output ABC CEC. Keep the recovered audit's 1,083,999 assertions separate.
6. Issue a new Gate A report and a new freeze/run identity. Supply a Frozen Execution Prompt only if every gate passes. Do not reuse `gate-a-v4-candidate-20260923-02-stability-no-go`.

The natural population remains pairability-unobserved. Do not run the pair compiler on it or alter the 142-output selection until a valid successor freeze exists.
