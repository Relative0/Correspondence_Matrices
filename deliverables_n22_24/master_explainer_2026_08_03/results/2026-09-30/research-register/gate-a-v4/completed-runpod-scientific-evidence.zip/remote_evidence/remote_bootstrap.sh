#!/usr/bin/env bash
# External, non-frozen bootstrap for the one Gate A exploratory Runpod pilot.
set -Eeuo pipefail

RUN_ID="pilot-v4-runpod-20260924-03"
ROOT="/workspace/${RUN_ID}"
STAGED="${ROOT}/staged"
EVIDENCE="${ROOT}/evidence"
RETRIEVAL="${ROOT}/retrieval"
PACKAGE="${ROOT}/Gate_A_V4_NO_GO_Qualification_Package.zip"
EXPECTED_PACKAGE_SHA="93c556a4c15099c260919287e95809079bf8d5ff21b8117e4155fd0482a7306a"
EXPECTED_CORPUS_SHA="aa0cb2f1f4f665ee77ae0fa881a755eb1baa27971d870eec9e5680dc1049112b"

# The Docker entrypoint starts a setup-only status server while the one-time
# transfer is pending.  End it before any correctness or timing work begins.
if [ -n "${SETUP_SERVER_PID:-}" ]; then
  kill "$SETUP_SERVER_PID" 2>/dev/null || true
  sleep 1
fi

mkdir -p "$STAGED" "$EVIDENCE" "$RETRIEVAL"
if [ -x /workspace/runpodctl ]; then
  sha256sum /workspace/runpodctl > "$EVIDENCE/transfer_utility_sha256.txt"
  /workspace/runpodctl version > "$EVIDENCE/transfer_utility_version.txt" 2>&1 || true
fi
cp "$(dirname "$0")/Gate_A_V4_NO_GO_Qualification_Package.zip" "$PACKAGE"
cp "$0" "$EVIDENCE/remote_bootstrap.sh"
date -u +%Y-%m-%dT%H:%M:%SZ > "$EVIDENCE/started_utc.txt"

finish() {
  local status="$1"
  date -u +%Y-%m-%dT%H:%M:%SZ > "$EVIDENCE/ended_utc.txt"
  if [ -f /workspace/pilot-bootstrap.log ]; then
    cp /workspace/pilot-bootstrap.log "$EVIDENCE/remote_bootstrap_console.log"
  fi
  (cd "$EVIDENCE" && find . -type f -print0 | sort -z | xargs -0 sha256sum) > "$EVIDENCE/remote_evidence_sha256.txt"
  tar -C "$EVIDENCE" -czf "$RETRIEVAL/evidence.tar.gz" .
  sha256sum "$RETRIEVAL/evidence.tar.gz" > "$RETRIEVAL/evidence.tar.gz.sha256"
  python3 - "$status" "$RETRIEVAL/status.json" <<'PY'
import json, sys
from datetime import datetime, timezone
json.dump({"status": sys.argv[1], "run_id": "pilot-v4-runpod-20260924-03", "finished_utc": datetime.now(timezone.utc).isoformat()}, open(sys.argv[2], "w"), sort_keys=True)
PY
  cd "$RETRIEVAL"
  exec python3 -m http.server 8000 --bind 0.0.0.0
}

on_error() {
  local code="$?"
  printf 'exit_code=%s\nline=%s\ncommand=%s\n' "$code" "$1" "$2" > "$EVIDENCE/bootstrap_failure.txt"
  trap - ERR
  finish "bootstrap_or_pilot_failure"
}
trap 'on_error "$LINENO" "$BASH_COMMAND"' ERR

sha256sum "$PACKAGE" > "$EVIDENCE/package_sha256.txt"
test "$(awk '{print $1}' "$EVIDENCE/package_sha256.txt")" = "$EXPECTED_PACKAGE_SHA"
python3 - "$PACKAGE" "$STAGED" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as archive:
    archive.extractall(sys.argv[2])
PY

python3 - "$STAGED" "$EVIDENCE/staged_deliverable_verification.json" <<'PY'
import hashlib, json, sys
from pathlib import Path
root=Path(sys.argv[1]); manifest=json.loads((root/'outputs/GATE_A_V4_DELIVERABLE_SHA256.json').read_text())
entries=manifest.get('files') or manifest.get('artifacts') or [x for x in manifest.values() if isinstance(x,dict) and x.get('path') and x.get('sha256')]
failures=[]
for e in entries:
    rel=e.get('path') or e.get('file') or e.get('name'); expected=(e.get('sha256') or e.get('hash')).lower(); p=root/rel
    if not p.is_file(): failures.append({'path':rel,'failure':'missing'}); continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual != expected: failures.append({'path':rel,'expected':expected,'actual':actual})
result={'entries':len(entries),'failures':failures,'valid':not failures}
Path(sys.argv[2]).write_text(json.dumps(result,sort_keys=True)+'\n')
if failures: raise SystemExit('staged deliverable verification failed')
PY

mkdir -p "$ROOT/source"
python3 - "$STAGED/outputs/audited_source_snapshot.zip" "$ROOT/source" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as archive:
    archive.extractall(sys.argv[2])
PY
python3 - "$STAGED/outputs/evidence/source_files.json" "$ROOT/source" "$EVIDENCE/source_closure_verification.json" <<'PY'
import hashlib, json, sys
from pathlib import Path
entries=json.loads(Path(sys.argv[1]).read_text()); root=Path(sys.argv[2]); failures=[]
for e in entries:
    p=root/e['path']
    if not p.is_file(): failures.append({'path':e['path'],'failure':'missing'}); continue
    data=p.read_bytes(); digest=hashlib.sha256(data).hexdigest()
    blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    if digest != e['sha256'] or len(data) != e['bytes'] or blob != e['git_blob']:
        failures.append({'path':e['path'],'sha256':digest,'bytes':len(data),'git_blob':blob})
out={'files':len(entries),'failures':failures,'valid':not failures}
Path(sys.argv[3]).write_text(json.dumps(out,sort_keys=True)+'\n')
if failures: raise SystemExit('source closure verification failed')
PY

snapshot_environment() {
  local out="$1"
  {
    echo '== timestamp_utc =='; date -u --iso-8601=seconds
    echo '== os-release =='; cat /etc/os-release || true
    echo '== kernel =='; uname -a
    echo '== cgroup =='; stat -fc %T /sys/fs/cgroup || true; cat /proc/1/cgroup || true
    echo '== cpu =='; lscpu; lscpu -e=CPU,CORE,SOCKET,NODE,ONLINE || true
    echo '== numa =='; numactl -H || true
    echo '== cpuset_and_quota =='; grep -R . /sys/fs/cgroup/cpuset.cpus.effective /sys/fs/cgroup/cpu.max /sys/fs/cgroup/memory.max 2>/dev/null || true
    echo '== load =='; uptime; cat /proc/loadavg; cat /proc/pressure/cpu || true
    echo '== proc_stat =='; grep '^cpu ' /proc/stat
    echo '== clock =='; cat /sys/devices/system/clocksource/clocksource0/current_clocksource 2>/dev/null || true; cat /sys/devices/system/clocksource/clocksource0/available_clocksource 2>/dev/null || true
    echo '== frequency =='; grep -H . /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 2>/dev/null || true; grep -H . /sys/devices/system/cpu/cpu*/cpufreq/scaling_{min,max}_freq 2>/dev/null || true
    echo '== mounts =='; findmnt -T /workspace || true; df -T /workspace || true; cat /proc/self/mountinfo
    echo '== locale_timezone =='; locale; date '+%Z %z'; readlink -f /etc/localtime || true
    echo '== runtime =='; command -v docker && docker --version || true; command -v containerd && containerd --version || true
    echo '== frozen_worker_environment =='; env | grep -E '^(PYTHONHASHSEED|OMP_NUM_THREADS|MKL_NUM_THREADS|OPENBLAS_NUM_THREADS)=' || true
  } > "$out" 2>&1
}

snapshot_environment "$EVIDENCE/environment_pre.txt"

PYTHON=""
for candidate in python3.12 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then PYTHON="$(command -v "$candidate")"; break; fi
done
test -n "$PYTHON"
if ! "$PYTHON" -m venv "$ROOT/venv"; then
  {
    echo '== python venv bootstrap =='
    date -u --iso-8601=seconds
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv
  } > "$EVIDENCE/python_venv_bootstrap.txt" 2>&1
  "$PYTHON" -m venv "$ROOT/venv"
fi
VENV_PY="$ROOT/venv/bin/python"
"$VENV_PY" -m pip download --only-binary=:all: --no-deps --dest "$ROOT/wheels" numpy==2.3.2
sha256sum "$ROOT/wheels"/* > "$EVIDENCE/wheel_sha256.txt"
"$VENV_PY" -m pip install --no-index --find-links "$ROOT/wheels" numpy==2.3.2
"$VENV_PY" -m pip --version > "$EVIDENCE/pip_version.txt"
"$VENV_PY" -m pip freeze --all > "$EVIDENCE/pip_freeze.txt"
"$VENV_PY" - <<'PY' > "$EVIDENCE/python_numpy_configuration.txt"
import sys, numpy as np
print(sys.executable); print(sys.version); np.show_config()
PY
find "$ROOT/venv/lib" -path '*/site-packages/*.dist-info/RECORD' -type f -print0 | sort -z | xargs -0 sha256sum > "$EVIDENCE/installed_record_sha256.txt"

CPU="$("$VENV_PY" - <<'PY'
import os
allowed=sorted(os.sched_getaffinity(0))
groups={}
for cpu in allowed:
    try:
        core=open(f'/sys/devices/system/cpu/cpu{cpu}/topology/core_id').read().strip()
        package=open(f'/sys/devices/system/cpu/cpu{cpu}/topology/physical_package_id').read().strip()
        groups.setdefault((package,core),[]).append(cpu)
    except OSError: groups.setdefault(('unknown',str(cpu)),[]).append(cpu)
solo=[c for c in allowed if len(groups[next(k for k,v in groups.items() if c in v)])==1]
print((solo or allowed)[0])
PY
)"
PRIORITY=0
for candidate in -20 -15 -10 -5 0; do
  actual="$(nice -n "$candidate" sh -c 'nice' 2>/dev/null || true)"
  if [ "$actual" = "$candidate" ]; then PRIORITY="$candidate"; break; fi
done
printf 'selected_cpu=%s\nrequested_nice=%s\n' "$CPU" "$PRIORITY" > "$EVIDENCE/affinity_priority_selection.txt"

python3 - "$STAGED/outputs/v4_freeze/PRIMARY_CORPUS_V4.json" "$ROOT/smoke_request.json" <<'PY'
import json, sys
corpus=json.load(open(sys.argv[1]))
json.dump({'case':corpus['cases'][0], 'arm_id':'cm_pure', 'record_kind':'correctness', 'collect_diagnostics':False}, open(sys.argv[2],'w'), separators=(',',':'))
PY
env PYTHONPATH="$ROOT/source" PYTHONHASHSEED=20260923 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  taskset -c "$CPU" nice -n "$PRIORITY" "$VENV_PY" "$STAGED/outputs/v4_freeze/runner_v4.py" --worker \
  < "$ROOT/smoke_request.json" > "$EVIDENCE/smoke_record.json"
python3 - "$EVIDENCE/smoke_record.json" "$CPU" <<'PY'
import json, sys
r=json.load(open(sys.argv[1])); cpu=int(sys.argv[2])
assert r['correctness_status']=='pass', r
assert r['worker_affinity']==[cpu], r
assert r['elapsed_total_ns'] is None, r
PY

PILOT_JSON="$EVIDENCE/EXPLORATORY_PILOT_V4_RUNPOD_01.json"
env PYTHONPATH="$ROOT/source" PYTHONHASHSEED=20260923 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
  taskset -c "$CPU" nice -n "$PRIORITY" "$VENV_PY" "$STAGED/outputs/v4_freeze/pilot_v4.py" \
  "$STAGED/outputs/v4_freeze/PRIMARY_CORPUS_V4.json" "$PILOT_JSON" \
  --run-id "$RUN_ID" --repetitions 11 --python "$VENV_PY" > "$EVIDENCE/pilot_stdout.json"
sha256sum "$PILOT_JSON" > "$EVIDENCE/pilot_sha256.txt"
python3 - "$PILOT_JSON" "$EVIDENCE/pilot_control_summary_runpod.json" "$EXPECTED_CORPUS_SHA" <<'PY'
import json, sys
r=json.load(open(sys.argv[1])); expected=sys.argv[3]
assert r['schema']=='cm_pair_exploratory_pilot_v4' and r['run_id'].startswith('pilot-') and 'confirm' not in r['run_id'].lower()
assert r['confirmatory'] is False and r['corpus_sha256']==expected and r['repetitions']==11 and len(r['rows'])==200
arms={}; timer_failures=0
for row in r['rows']:
    arm=arms.setdefault(row['arm_id'], {'passed':0,'failed':0,'maximum_mad_over_median':0.0})
    arm['passed' if row['control_pass'] else 'failed']+=1
    arm['maximum_mad_over_median']=max(arm['maximum_mad_over_median'],row['mad_over_median'])
    timer_failures += int(row['timer_overhead_fraction']>0.01)
summary={'run_id':r['run_id'],'confirmatory':False,'controls_total':len(r['rows']),'controls_passed':sum(x['control_pass'] for x in r['rows']),'controls_failed':sum(not x['control_pass'] for x in r['rows']),'by_arm':arms,'maximum_mad_over_median':max(x['mad_over_median'] for x in r['rows']),'timer_overhead_failures':timer_failures,'worker_affinity':r.get('worker_affinity'),'worker_nice':r.get('worker_nice'),'all_controls_pass':r['all_controls_pass']}
json.dump(summary,open(sys.argv[2],'w'),sort_keys=True)
PY

snapshot_environment "$EVIDENCE/environment_post.txt"
if python3 - "$EVIDENCE/pilot_control_summary_runpod.json" <<'PY'
import json, sys
raise SystemExit(0 if json.load(open(sys.argv[1]))['all_controls_pass'] else 1)
PY
then
  printf '%s\n' 'Exploratory repeatability gate passed; no confirmatory execution occurred. Further Gate A qualification was intentionally not automated in this bootstrap.' > "$EVIDENCE/decision.txt"
  finish "pilot_pass_pending_required_gate_a_qualification"
else
  printf '%s\n' 'Exploratory repeatability gate failed. Gate A remains NO-GO. No retries, confirmatory schedules, secondary schedules, natural pairability, or performance analysis were run.' > "$EVIDENCE/decision.txt"
  cp "$STAGED/outputs/REPAIR_PROMPT_TIMING_STABILITY_V4.md" "$EVIDENCE/next_repair_prompt.md"
  finish "pilot_failed_no_go"
fi
