"""Protocol v4 primary analysis with schema, manifest, and schedule validation.

No performance data are shipped with Gate A. Invalid, missing, duplicate, or
failed logical observations make the primary decision not evaluable.
"""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

from v4_freeze.row_schema_v4 import validate_row
from v4_freeze.v4_harness import canonical_json, sha256_file, sha256_json

SEED=2026092304
BOOTSTRAPS=20000
def estimate(d,c,mc,md,*,draws=BOOTSTRAPS):
    d,c,mc,md=map(lambda x:np.asarray(x,dtype=np.float64),(d,c,mc,md))
    if d.shape!=(100,30) or c.shape!=d.shape or mc.shape!=(100,15) or md.shape!=mc.shape:
        raise ValueError('Expected 100 cases x 30 times and 100 x 15 memory observations')
    if any(np.any(~np.isfinite(x)) or np.any(x<=0) for x in (d,c,mc,md)):
        raise ValueError('Observations must be positive and finite')
    ri=np.median(d,axis=1)/np.median(c,axis=1)
    mi=np.median(mc,axis=1)/np.median(md,axis=1)
    rng=np.random.Generator(np.random.PCG64(SEED));boot=np.empty(draws)
    for b in range(draws):
        case=rng.integers(0,100,size=100)
        rep=rng.integers(0,30,size=(100,30))
        cb=c[case[:,None],rep];db=d[case[:,None],rep]
        boot[b]=np.median(np.median(db,axis=1)/np.median(cb,axis=1))
    lo,hi=np.quantile(boot,[.025,.975],method='linear')
    r=float(np.median(ri));m=float(np.median(mi))
    return {'ratio':r,'ci95':[float(lo),float(hi)],'memory_ratio':m,
            'per_case_ratios':ri.tolist(),'per_case_memory_ratios':mi.tolist(),
            'utility_pass':bool(r>=1.20 and lo>1.0 and m<=1.10),
            'bootstrap_draws':draws,'seed':SEED}

def _verify_bound_file(binding, label):
    path=Path(binding['path'])
    if sha256_file(path)!=binding['sha256']:raise ValueError(f'{label} hash mismatch')
    return json.loads(path.read_text(encoding='utf-8'))

def _expected_schedule(schedule):
    expected={}
    for block in schedule['blocks']:
        rep=block['repetition_index']
        for case_pos,case in enumerate(block['case_order']):
            for arm_pos,arm in enumerate(block['arm_order'][case]):
                expected[(case,arm,rep)]=(2*case_pos+arm_pos,2*(100*rep+case_pos)+arm_pos)
    return expected

def _select_attempts(rows, kind):
    grouped={}
    for row in rows:
        validate_row(row)
        if row['record_kind']!=kind:raise ValueError('Wrong record kind')
        grouped.setdefault(row['logical_observation_id'],[]).append(row)
    selected=[]
    for logical,attempts in grouped.items():
        attempts.sort(key=lambda r:r['attempt_index'])
        if [r['attempt_index'] for r in attempts] not in ([0],[0,1]):raise ValueError('Invalid attempt sequence')
        if len(attempts)==2 and attempts[0]['disposition']!='infrastructure_failure':raise ValueError('Retry after non-infrastructure failure')
        selected.append(attempts[-1])
    return selected

def analyze(payload):
    cases=payload['primary_case_ids']
    if len(cases)!=100 or len(set(cases))!=100:raise ValueError('Exactly 100 unique frozen case IDs required')
    if payload.get('all_correctness_gates_passed') is not True:raise ValueError('Correctness gate not passed')
    if payload.get('freeze_manifest_verified') is not True:raise ValueError('Freeze manifest not verified')
    freeze=_verify_bound_file(payload['freeze_manifest_binding'],'freeze manifest')
    if freeze.get('status')!='FROZEN' or freeze.get('authorization_to_execute') is not True:raise ValueError('Manifest is not an authorized freeze')
    try: expected_memory_metric=freeze['environment']['memory_metric']
    except (KeyError,TypeError): raise ValueError('Freeze manifest lacks memory metric')
    time_schedule=_verify_bound_file(payload['time_schedule_binding'],'time schedule')
    memory_schedule=_verify_bound_file(payload['memory_schedule_binding'],'memory schedule')
    expected={'time':_expected_schedule(time_schedule),'memory':_expected_schedule(memory_schedule)}
    arrays={('time','direct_packed'):np.zeros((100,30)),('time','cm_pure'):np.zeros((100,30)),('memory','cm_pure'):np.zeros((100,15)),('memory','direct_packed'):np.zeros((100,15))}
    ids={x:i for i,x in enumerate(cases)};seen=set()
    for kind,raw_rows in [('time',payload['time_rows']),('memory',payload['memory_rows'])]:
        for row in _select_attempts(raw_rows,kind):
            arm=row['arm_id'];case=row['case_id'];rep=row['repetition_index'];key=(kind,case,arm,rep)
            if key in seen:raise ValueError('Duplicate logical observation')
            seen.add(key)
            if row['disposition']!='ok' or row['correctness_status']!='pass':raise ValueError('Incomplete/failed primary row; not evaluable')
            if row['cell_id']!='primary_B_1023_unshared_token_K1':raise ValueError('Unexpected primary cell')
            if row['ast_occurrences']!=1023 or row['unique_object_nodes']!=1023 or row['fixed_bindings']!={}:raise ValueError('Wrong primary input contract')
            if row['output_artifact']!='token' or row['reuse_count']!=1:raise ValueError('Wrong primary endpoint')
            if arm=='cm_pure' and (row['requested_strategy']!='pure_structural' or row['root_outcome']!='pure_structural'):raise ValueError('Wrong primary provenance')
            if arm not in ('cm_pure','direct_packed'):raise ValueError('Unexpected primary arm')
            try:order,schedule_index=expected[kind][(case,arm,rep)]
            except KeyError:raise ValueError('Row not present in frozen schedule')
            if row['order_in_block']!=order or row['schedule_index']!=schedule_index:raise ValueError('Schedule mismatch')
            if row['manifest_sha256']!=payload['freeze_manifest_binding']['sha256']:raise ValueError('Row freeze hash mismatch')
            if kind=='memory' and row['memory_metric']!=expected_memory_metric:raise ValueError('Memory metric differs from freeze')
            a=arrays[(kind,arm)]
            if isinstance(rep,bool) or not isinstance(rep,int) or not 0<=rep<a.shape[1]:raise ValueError('Invalid repetition index')
            val=row['elapsed_total_ns' if kind=='time' else 'peak_process_memory_bytes']
            if isinstance(val,bool) or not isinstance(val,int) or val<=0:raise ValueError('Invalid integer measurement')
            a[ids[case],rep]=val
    if len(seen)!=9000:raise ValueError('Missing or additional primary observations')
    result=estimate(arrays[('time','direct_packed')],arrays[('time','cm_pure')],arrays[('memory','cm_pure')],arrays[('memory','direct_packed')])
    result['decision']='utility_established' if result['utility_pass'] else 'utility_not_established'
    return result

if __name__=='__main__':
    try:
        with open(sys.argv[1],encoding='utf-8') as f:payload=json.load(f)
        print(json.dumps(analyze(payload),indent=2,allow_nan=False))
    except (ValueError,KeyError,IndexError) as exc:
        print(json.dumps({'decision':'not_evaluable','error':str(exc)}));sys.exit(2)
