"""Untimed native CUDD equivalence over every applicable generated case."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from corpus_v4 import SECONDARY_CELLS, _secondary_expr
from v4_harness import (
    artifact_digest, canonical_json, deserialize_identity_dag, native_robdd_artifact,
    run_arm, sha256_bytes, sha256_file,
)


def equal_artifact(left: Any, right: Any, artifact: str) -> bool:
    return bool(np.array_equal(left, right)) if artifact == "dense" else left == right


def qualify(directory: Path) -> dict[str, Any]:
    import dd
    import dd.cudd as cudd

    primary = json.loads((directory / "PRIMARY_CORPUS_V4.json").read_text(encoding="utf-8"))
    secondary = json.loads((directory / "SECONDARY_CELLS_V4.json").read_text(encoding="utf-8"))
    secondary_by_id = {cell["cell_id"]: cell for cell in secondary["cells"]}
    records: list[dict[str, Any]] = []

    for case in primary["cases"]:
        expr = deserialize_identity_dag(case["identity_dag"])
        reference, _ = run_arm(expr, arm_id="direct_packed", rows=case["row_layout"],
                               cols=case["column_layout"], fixed=case["fixed_bindings"],
                               artifact=case["output_artifact"])
        actual, metrics = native_robdd_artifact(
            deserialize_identity_dag(case["identity_dag"]), case["row_layout"],
            case["column_layout"], case["fixed_bindings"], case["output_artifact"])
        if not equal_artifact(actual, reference, case["output_artifact"]):
            raise AssertionError(f"primary ROBDD mismatch {case['case_id']}")
        records.append({
            "case_id": case["case_id"], "corpus": "primary", "artifact": case["output_artifact"],
            "correctness_digest": artifact_digest(actual, case["row_layout"], case["column_layout"],
                                                   case["fixed_bindings"], case["output_artifact"]),
            **metrics,
        })

    for cell_index, cell in enumerate(SECONDARY_CELLS):
        frozen = secondary_by_id[cell.cell_id]
        if "robdd" not in frozen["applicable_arms"]:
            continue
        for case_index in range(30):
            expr, rows, cols, fixed = _secondary_expr(cell, case_index)
            reference, _ = run_arm(expr, arm_id="direct_packed", rows=rows, cols=cols,
                                   fixed=fixed, artifact=cell.artifact)
            expr2, rows2, cols2, fixed2 = _secondary_expr(cell, case_index)
            actual, metrics = native_robdd_artifact(expr2, rows2, cols2, fixed2, cell.artifact)
            if not equal_artifact(actual, reference, cell.artifact):
                raise AssertionError(f"secondary ROBDD mismatch {cell.cell_id}:{case_index:02d}")
            records.append({
                "case_id": f"{cell.cell_id}:{case_index:02d}", "corpus": "secondary",
                "cell_id": cell.cell_id, "artifact": cell.artifact,
                "correctness_digest": artifact_digest(actual, rows, cols, fixed, cell.artifact),
                **metrics,
            })

    cudd_path = Path(cudd.__file__).resolve()
    result = {
        "schema": "cm_pair_native_robdd_qualification_v4",
        "performance_observations": 0,
        "backend": "dd.cudd", "dd_version": str(dd.__version__),
        "cudd_version": str(cudd.__version__), "cudd_module_path": str(cudd_path),
        "cudd_module_sha256": sha256_file(cudd_path),
        "variable_order_policy": "ambient rows, ambient columns, remaining xN in numeric order",
        "dynamic_reordering": False, "fresh_manager_per_case": True,
        "primary_cases": sum(r["corpus"] == "primary" for r in records),
        "secondary_cases": sum(r["corpus"] == "secondary" for r in records),
        "oracle_equal": len(records), "failures": 0, "records": records,
    }
    result["qualification_sha256"] = sha256_bytes(canonical_json(result))
    return result


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("directory")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    value = qualify(Path(args.directory))
    Path(args.output).write_bytes(canonical_json(value) + b"\n")
    print(json.dumps({key: value[key] for key in (
        "backend", "dd_version", "cudd_version", "primary_cases",
        "secondary_cases", "oracle_equal", "failures", "qualification_sha256")
    }, indent=2, sort_keys=True))
