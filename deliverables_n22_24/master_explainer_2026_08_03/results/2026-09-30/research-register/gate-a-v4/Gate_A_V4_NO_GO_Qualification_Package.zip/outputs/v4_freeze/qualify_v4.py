"""Untimed v4 qualification checks. This script never emits performance results."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

from corpus_v4 import validate_primary_manifest, validate_schedules, validate_secondary_schedules
from v4_harness import (
    artifact_digest, canonical_json, deserialize_identity_dag, peak_process_memory_bytes,
    reset_workload_caches, run_arm, sha256_bytes, sha256_file, stage_case,
)


def qualify(directory: Path) -> dict:
    primary=json.loads((directory/"PRIMARY_CORPUS_V4.json").read_text(encoding="utf-8"))
    secondary=json.loads((directory/"SECONDARY_CELLS_V4.json").read_text(encoding="utf-8"))
    time_schedule=json.loads((directory/"PRIMARY_TIME_SCHEDULE_V4.json").read_text(encoding="utf-8"))
    memory_schedule=json.loads((directory/"PRIMARY_MEMORY_SCHEDULE_V4.json").read_text(encoding="utf-8"))
    secondary_time=json.loads((directory/"SECONDARY_TIME_SCHEDULE_V4.json").read_text(encoding="utf-8"))
    secondary_memory=json.loads((directory/"SECONDARY_MEMORY_SCHEDULE_V4.json").read_text(encoding="utf-8"))
    validate_primary_manifest(primary)
    case_ids=[case["case_id"] for case in primary["cases"]]
    validate_schedules(time_schedule,memory_schedule,case_ids)
    validate_secondary_schedules(secondary_time,secondary_memory,secondary)
    outcomes=Counter();rows=[]
    for case in primary["cases"]:
        expr_cm,meta_cm=stage_case(case);reset_workload_caches()
        token,metrics=run_arm(expr_cm,arm_id="cm_pure",rows=case["row_layout"],cols=case["column_layout"],
                              fixed=case["fixed_bindings"],artifact="token",diagnostics=True)
        expr_direct,meta_direct=stage_case(case);reset_workload_caches()
        direct,_=run_arm(expr_direct,arm_id="direct_packed",rows=case["row_layout"],cols=case["column_layout"],
                         fixed=case["fixed_bindings"],artifact="token")
        cm_digest=artifact_digest(token,case["row_layout"],case["column_layout"],case["fixed_bindings"],"token")
        direct_digest=artifact_digest(direct,case["row_layout"],case["column_layout"],case["fixed_bindings"],"token")
        if token!=direct or cm_digest!=direct_digest: raise AssertionError(f"oracle mismatch {case['case_id']}")
        if metrics["root_outcome"]!="pure_structural": raise AssertionError(f"non-S primary {case['case_id']}")
        if meta_cm!=meta_direct: raise AssertionError("arm staging mismatch")
        outcomes[metrics["root_outcome"]]+=1
        rows.append({"case_id":case["case_id"],"case_sha256":case["case_sha256"],"token":token,
                     "correctness_digest":cm_digest,"root_outcome":metrics["root_outcome"],
                     "pair_attempts":metrics["pair_attempts"],"pair_collapses":metrics["pair_collapses"],
                     "discarded_pair_constructions":metrics["discarded_pair_constructions"],
                     "retained_pair_constructions":metrics["retained_pair_constructions"]})
    peak,metric=peak_process_memory_bytes()
    result={"schema":"cm_pair_v4_untimed_qualification","performance_observations":0,
            "primary_cases":len(rows),"primary_oracle_equal":len(rows),"outcomes":dict(outcomes),
            "secondary_cells":secondary["finite_cell_count"],"secondary_cases":secondary["case_count"],
            "time_schedule_counterbalanced":True,"memory_schedule_counterbalanced":True,
            "secondary_schedules_counterbalanced":True,
            "cache_reset_asserted":True,"memory_adapter_metric":metric,"memory_adapter_positive":peak>0,
            "rows":rows,"input_hashes":{name:sha256_file(directory/name) for name in (
                "PRIMARY_CORPUS_V4.json","SECONDARY_CELLS_V4.json","PRIMARY_TIME_SCHEDULE_V4.json","PRIMARY_MEMORY_SCHEDULE_V4.json",
                "SECONDARY_TIME_SCHEDULE_V4.json","SECONDARY_MEMORY_SCHEDULE_V4.json")}}
    result["qualification_sha256"]=sha256_bytes(canonical_json(result))
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("directory");parser.add_argument("--output")
    args=parser.parse_args();result=qualify(Path(args.directory));data=canonical_json(result)+b"\n"
    if args.output:Path(args.output).write_bytes(data)
    else:print(data.decode(),end="")
