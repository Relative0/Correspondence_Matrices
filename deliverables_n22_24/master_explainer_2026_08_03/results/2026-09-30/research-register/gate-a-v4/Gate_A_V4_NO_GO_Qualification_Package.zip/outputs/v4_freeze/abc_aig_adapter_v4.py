"""Frozen native ABC endpoint for the natural-corpus structural control.

The adapter consumes a one-output, combinational binary AIG prepared from the
prospectively selected natural output.  Its delivered artifact is a binary AIG,
so this arm is descriptive-only and is never mixed into the primary token or
dense endpoint estimands.  Semantic qualification is performed by ABC CEC.
"""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
from typing import Any, Sequence

from v4_harness import sha256_file


def _run(argv: Sequence[str], *, timeout: int, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[bytes]:
    completed = subprocess.run(
        list(argv), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        timeout=timeout, env=env, check=False,
    )
    if completed.returncode:
        message = completed.stdout.decode("utf-8", "replace")[-4000:]
        raise RuntimeError(f"native tool exited {completed.returncode}: {message}")
    return completed


def split_aag(path: str | Path) -> dict[str, Any]:
    """Read the exact ASCII AIGER subset emitted by the frozen Yosys command."""
    source = Path(path)
    lines = source.read_text(encoding="ascii").splitlines()
    header = lines[0].split()
    if len(header) != 6 or header[0] != "aag":
        raise ValueError("ASCII AIGER 1.9 aag required")
    maximum, inputs, latches, outputs, ands = map(int, header[1:])
    cursor = 1
    input_lines = lines[cursor:cursor + inputs]; cursor += inputs
    latch_lines = lines[cursor:cursor + latches]; cursor += latches
    output_lines = lines[cursor:cursor + outputs]; cursor += outputs
    and_lines = lines[cursor:cursor + ands]
    if len(input_lines) != inputs or len(latch_lines) != latches or len(output_lines) != outputs or len(and_lines) != ands:
        raise ValueError("truncated AAG")
    return {
        "M": maximum, "I": inputs, "L": latches, "O": outputs, "A": ands,
        "inputs": input_lines, "latches": latch_lines,
        "outputs": output_lines, "ands": and_lines,
    }


def write_one_output_combinational_aag(source: str | Path, output_index: int, destination: str | Path) -> Path:
    """Treat current latch values as inputs, matching the compiler translation."""
    sections = split_aag(source)
    if not 0 <= output_index < sections["O"]:
        raise IndexError(output_index)
    latch_literals = [line.split()[0] for line in sections["latches"]]
    lines = [
        f"aag {sections['M']} {sections['I'] + sections['L']} 0 1 {sections['A']}",
        *sections["inputs"], *latch_literals,
        sections["outputs"][output_index], *sections["ands"],
    ]
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(lines) + "\n", encoding="ascii", newline="\n")
    return target


def tool_environment(tool_root: str | Path) -> dict[str, str]:
    root = Path(tool_root)
    env = os.environ.copy()
    library = root / "usr" / "lib" / "x86_64-linux-gnu"
    data = root / "usr" / "share" / "yosys"
    env["LD_LIBRARY_PATH"] = str(library)
    env["YOSYS_DATDIR"] = str(data)
    return env


def convert_with_yosys(aag: str | Path, raw_aig: str | Path, *, yosys: str | Path,
                       tool_root: str | Path, timeout: int = 60) -> dict[str, Any]:
    script = f"read_aiger {Path(aag)}; write_aiger -symbols {Path(raw_aig)}"
    _run([str(yosys), "-q", "-Q", "-p", script], timeout=timeout,
         env=tool_environment(tool_root))
    return {"path": str(raw_aig), "bytes": Path(raw_aig).stat().st_size,
            "sha256": sha256_file(raw_aig), "command": f'yosys -q -Q -p "{script}"'}


def execute_abc(raw_aig: str | Path, optimized_aig: str | Path, *, abc: str | Path,
                tool_root: str | Path, timeout: int = 60) -> dict[str, Any]:
    """Create the native AIG artifact. This function contains no hidden CEC."""
    script = f"read_aiger {Path(raw_aig)}; strash; write_aiger -s {Path(optimized_aig)}"
    _run([str(abc), "-q", script], timeout=timeout, env=tool_environment(tool_root))
    return {"path": str(optimized_aig), "bytes": Path(optimized_aig).stat().st_size,
            "sha256": sha256_file(optimized_aig),
            "command": f'yosys-abc -q "{script}"'}


def qualify_equivalence(raw_aig: str | Path, optimized_aig: str | Path, *, abc: str | Path,
                        tool_root: str | Path, timeout: int = 60) -> dict[str, Any]:
    script = f"cec {Path(raw_aig)} {Path(optimized_aig)}"
    completed = _run([str(abc), "-c", script], timeout=timeout,
                     env=tool_environment(tool_root))
    output = completed.stdout.decode("utf-8", "replace")
    passed = "equivalent" in output.lower() and "not equivalent" not in output.lower()
    if not passed:
        raise AssertionError(f"ABC CEC did not establish equivalence: {output[-2000:]}")
    return {"passed": True, "method": "ABC cec", "command": f'yosys-abc -c "{script}"'}

