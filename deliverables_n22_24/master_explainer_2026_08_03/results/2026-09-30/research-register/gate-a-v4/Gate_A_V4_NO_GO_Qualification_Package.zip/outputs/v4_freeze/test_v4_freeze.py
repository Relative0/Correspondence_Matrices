from __future__ import annotations

import copy
import json
from pathlib import Path

import numpy as np
import pytest

from cm_exprlib import And, Or, Var, Xor
from bitset_backend import build_bitset_env, eval_expr_bitset

from corpus_v4 import generate_primary, generate_primary_schedules, validate_primary_manifest, validate_schedules
from row_schema_v4 import REQUIRED_FIELDS, validate_row
from v4_harness import (
    AppendOnlyWriter, PairWorkProbe, artifact_digest, canonical_json, deserialize_identity_dag,
    direct_packed, expression_stats, peak_process_memory_bytes, reset_workload_caches,
    run_arm, serialize_identity_dag, sha256_bytes, sha256_file, sha256_json, structural_prefix,
)
from runner_v4 import launch_one
from abc_aig_adapter_v4 import split_aag, write_one_output_combinational_aag


def _case(expr, artifact="token"):
    dag=serialize_identity_dag(expr)
    return {"case_id":"T","identity_dag":dag,"identity_dag_sha256":sha256_json(dag),
            "structural_syntax_sha256":sha256_bytes(structural_prefix(expr).encode("ascii")),
            "row_layout":["x0"],"column_layout":["x1"],"fixed_bindings":{},
            "output_artifact":artifact,"reuse_count":1}


def test_primary_corpus_exact_contract():
    manifest=generate_primary();validate_primary_manifest(manifest)
    assert [c["root_operator"] for c in manifest["cases"]][::20]==["AND","OR","XOR","IMP","EQV"]
    assert all(c["primitive_count"]==240 and c["swapped_primitive_positions"]==120 and c["signed_literal_positions"]==64 for c in manifest["cases"])


def test_fresh_reconstruction_preserves_sharing_not_identity():
    shared=And(Var(0),Var(1));expr=Or(shared,shared);dag=serialize_identity_dag(expr)
    a=deserialize_identity_dag(dag);b=deserialize_identity_dag(dag)
    assert a is not b and a.a is a.b and b.a is b.b and a.a is not b.a
    assert expression_stats(a)["ast_occurrences"]==7 and expression_stats(a)["unique_object_nodes"]==4


def test_fixed_first_ambient_adapter_counterexample():
    expr=And(Var(0),Var(1));raw=eval_expr_bitset(expr,build_bitset_env(["x0","x1"]),fixed={"x0":1})
    adapted=direct_packed(expr,["x0"],["x1"],{"x0":1})
    assert raw==8 and adapted==10 and raw!=adapted


def test_cache_reset_assertions_and_correctness_digest():
    expr=And(Var(0),Var(1));direct_packed(expr,["x0"],["x1"],{})
    _before,after=reset_workload_caches()
    assert after["bitset_env"]["size"]==0
    cm,metrics=run_arm(expr,arm_id="cm_pure",rows=["x0"],cols=["x1"],fixed={},artifact="token",diagnostics=True)
    direct,_=run_arm(deserialize_identity_dag(serialize_identity_dag(expr)),arm_id="direct_packed",rows=["x0"],cols=["x1"],fixed={},artifact="token")
    assert cm==direct==8 and metrics["root_outcome"]=="pure_structural"
    assert artifact_digest(cm,["x0"],["x1"],{},"token")==artifact_digest(direct,["x0"],["x1"],{},"token")


def test_prepared_generic_and_ordinary_dense_adapters_equal():
    expr=Or(And(Var(0),Var(1)),Xor(Var(2),Var(2)));rows=["x0","x2"];cols=["x1"]
    expected,_=run_arm(expr,arm_id="direct_packed",rows=rows,cols=cols,fixed={"x2":1},artifact="dense")
    for arm in ("prepared_cse","generic_local","ordinary_cm"):
        actual,_=run_arm(deserialize_identity_dag(serialize_identity_dag(expr)),arm_id=arm,rows=rows,cols=cols,fixed={"x2":1},artifact="dense")
        assert np.array_equal(actual,expected) and actual.flags.owndata and actual.flags.writeable


def test_attempted_and_discarded_pair_constructions():
    expr=Or(And(Var(0),Var(1)),Var(2))
    with pytest.raises(LookupError,match="NoPair"):
        run_arm(expr,arm_id="cm_pure",rows=["x0","x2"],cols=["x1"],fixed={},artifact="token",diagnostics=True)


def test_no_pair_probe_counts_actual_discard(monkeypatch):
    expr=Or(And(Var(0),Var(1)),Var(2))
    with PairWorkProbe() as probe:
        compiled,metrics=__import__("cm_build_pair").compile_expr_to_cm_pair_token(expr,["x0","x2"],["x1"],{},strategy="pure_structural")
    assert compiled is None and probe.pair_constructions==1 and metrics["pair_collapses"]==1


def test_memory_adapter_boundary():
    value,metric=peak_process_memory_bytes()
    assert type(value) is int and value>0
    assert metric==("PeakWorkingSetSize" if __import__("os").name=="nt" else "ru_maxrss")


def test_aig_endpoint_combinationalizes_latches_without_selecting_outputs(tmp_path):
    source=tmp_path/"source.aag"
    source.write_text("aag 3 1 1 2 1\n2\n4 6\n4\n6\n6 2 4\n",encoding="ascii")
    target=write_one_output_combinational_aag(source,1,tmp_path/"o1.aag")
    parsed=split_aag(target)
    assert (parsed["I"],parsed["L"],parsed["O"],parsed["A"])==(2,0,1,1)
    assert parsed["inputs"]==["2","4"] and parsed["outputs"]==["6"]


def test_append_only_failure_retention(tmp_path):
    path=tmp_path/"rows.jsonl";writer=AppendOnlyWriter(path)
    a={"logical_observation_id":"x","attempt_index":0,"disposition":"infrastructure_failure"}
    b={"logical_observation_id":"x","attempt_index":1,"disposition":"ok"}
    ha=writer.append(a);hb=writer.append(b);lines=[json.loads(x) for x in path.read_text().splitlines()]
    assert len(lines)==2 and lines[0]["row_sha256"]==ha and lines[1]["previous_row_sha256"]==ha and hb!=ha


def test_fresh_process_runner_emits_strict_retained_row(tmp_path):
    case=_case(And(Var(0),Var(1)));case.update(expression_stats(And(Var(0),Var(1))))
    case.update({"case_sha256":sha256_json(case),"cell_id":"smoke","stratum":"A_exact_positive",
                 "generator_seed":1,"sharing_class":"unshared","equal_distinct_subtree_count":0})
    h="0"*64
    request={"case":case,"arm_id":"direct_packed","record_kind":"correctness","run_id":"smoke-v4",
             "logical_observation_id":"smoke:direct","environment_id":"test","schedule_index":0,
             "order_in_block":0,"repetition_index":0,"corpus_id":"smoke","timeout_seconds":60,
             "hashes":{"manifest_sha256":h,"protocol_sha256":h,"source_manifest_sha256":h,
                       "analysis_sha256":h,"corpus_manifest_sha256":h,"endpoint_adapter_sha256":h,
                       "oracle_source_sha256":h,"memory_adapter_sha256":h,
                       "arm_source_sha256":{"direct_packed":h}}}
    rows=launch_one(request,output=tmp_path/"runner.jsonl")
    assert len(rows)==1 and rows[0]["disposition"]=="ok" and rows[0]["fresh_process"] is True
    assert rows[0]["correctness_status"]=="pass" and rows[0]["correctness_digest"]==rows[0]["oracle_digest"]
    assert len((tmp_path/"runner.jsonl").read_text().splitlines())==1


def _full_row(case,arm,rep,kind,order,schedule_index):
    h="0"*64
    row={name:None for name in REQUIRED_FIELDS}
    row.update({
        "schema_version":"cm_pair_gate_v4","protocol_version":"4","run_id":"synthetic","manifest_sha256":h,
        "protocol_sha256":h,"source_manifest_sha256":h,"analysis_sha256":h,"row_id":f"{kind}:{case}:{arm}:{rep}",
        "logical_observation_id":f"{kind}:{case}:{arm}:{rep}","attempt_index":0,"previous_row_sha256":h,
        "record_kind":kind,"timestamp_utc":"2026-09-23T00:00:00+00:00","process_id":1,"environment_id":"synthetic",
        "schedule_index":schedule_index,"order_in_block":order,"case_id":case,"case_sha256":h,"identity_dag_sha256":h,
        "structural_syntax_sha256":h,"corpus_id":"primary","corpus_manifest_sha256":h,"source_output_id":None,
        "cell_id":"primary_B_1023_unshared_token_K1","stratum":"B_signed_permuted","generator_seed":2026092301,
        "sharing_class":"unshared","natural_source_revision":None,"natural_license":None,"original_file":None,
        "original_content_sha256":None,"extraction_manifest_sha256":None,"translation_sha256":None,
        "original_support_count":2,"syntactic_unfixed_count":2,"ast_occurrences":1023,"unique_object_nodes":1023,
        "ast_height":11,"equal_distinct_subtree_count":0,"row_layout":["x0"],"column_layout":["x1"],
        "variable_order":["x0","x1"],"fixed_bindings":{},"arm_id":arm,"arm_source_sha256":h,
        "endpoint_adapter_sha256":h,"requested_strategy":"pure_structural" if arm=="cm_pure" else None,
        "effective_strategy":"pure_structural" if arm=="cm_pure" else None,
        "root_outcome":"pure_structural" if arm=="cm_pure" else None,"provenance":"S" if arm=="cm_pure" else None,
        "token_disposition":"pair","fallback_executed":False,"disposition":"ok","error_type":None,"error_message":None,
        "correctness_status":"pass","output_artifact":"token","output_order":"bit 2*r+c; display 11,10,01,00",
        "output_shape":[],"output_dtype":"uint4","n_out":2,"output_elements":4,"output_payload_bytes":1,
        "output_information_bits":4,"token_value":8,"output_owns_data":None,"output_writeable":None,
        "prepared_representation_bytes":28,"result_object_bytes":28,"correctness_digest":h,"oracle_digest":h,
        "oracle_source_sha256":h,"semantic_equivalence_method":"exhaustive","output_budget_bytes":65536,
        "output_budget_vars":16,"output_budget_estimate_bytes":1,"temporary_estimate_bytes":1,"output_budget_status":"ok",
        "compiler_calls":1 if arm=="cm_pure" else None,"negation_nodes_scanned":0 if arm=="cm_pure" else None,
        "primitive_pair_tokens":1 if arm=="cm_pure" else None,"signed_operand_alignments":0 if arm=="cm_pure" else None,
        "token_negations":0 if arm=="cm_pure" else None,"token_fusions":0 if arm=="cm_pure" else None,
        "direct_pair_retabulations":0 if arm=="cm_pure" else None,"pair_attempts":1 if arm=="cm_pure" else None,
        "pair_collapses":1 if arm=="cm_pure" else None,"support_discovery_passes":None,"support_unique_visits":None,
        "scalar_evaluations":None,"scalar_occurrence_visits":None,"discarded_pair_constructions":None,
        "retained_pair_constructions":None,"retabulation_only_mode":0,"legacy_strategy_alias":0,
        "cache_regime":"post_import_cold","cache_before":{},"cache_after":{},"import_policy_id":"common-v4",
        "cache_reset_policy_id":"reset-v4","fresh_process":True,"warmup_process_id":None,"repetition_index":rep,
        "reuse_count":1,"query_schedule_sha256":None,"inner_iterations":1,
        "elapsed_total_ns":120 if arm=="direct_packed" else 100,"preparation_ns":None,"execution_ns":None,
        "query_ns":None,"conversion_ns":None,"materialization_ns":None,"pair_attempt_ns":None,"fallback_ns":None,
        "peak_process_memory_bytes":110 if arm=="cm_pure" else 100,"memory_metric":"PeakWorkingSetSize" if kind=="memory" else None,
        "memory_scope":"absolute_process_including_imports_and_staging" if kind=="memory" else None,"memory_adapter_sha256":h,
        "preparation_included":True,"sharing_policy":"preserve_identity_dag","result_reuse_policy":"K1",
        "timeout_seconds":60,"exclusion_reason":None,
    })
    if kind=="time": row["peak_process_memory_bytes"]=None
    else: row["elapsed_total_ns"]=None
    row["row_sha256"]=sha256_json({k:v for k,v in row.items() if k!="row_sha256"})
    return row


@pytest.fixture(scope="module")
def synthetic_payload(tmp_path_factory):
    from primary_analysis import analyze
    root=tmp_path_factory.mktemp("analysis")
    cases=[f"P{i:03d}" for i in range(100)]
    time,memory=generate_primary_schedules(cases)
    (root/"time.json").write_bytes(canonical_json(time));(root/"memory.json").write_bytes(canonical_json(memory))
    freeze={"status":"FROZEN","authorization_to_execute":True,
            "environment":{"memory_metric":"PeakWorkingSetSize"}};(root/"freeze.json").write_bytes(canonical_json(freeze))
    rows={"time":[],"memory":[]}
    for kind,schedule in (("time",time),("memory",memory)):
        for block in schedule["blocks"]:
            rep=block["repetition_index"]
            for pos,case in enumerate(block["case_order"]):
                for arm_pos,arm in enumerate(block["arm_order"][case]):
                    rows[kind].append(_full_row(case,arm,rep,kind,2*pos+arm_pos,2*(100*rep+pos)+arm_pos))
    payload={"primary_case_ids":cases,"all_correctness_gates_passed":True,"freeze_manifest_verified":True,
             "freeze_manifest_binding":{"path":str(root/"freeze.json"),"sha256":sha256_file(root/"freeze.json")},
             "time_schedule_binding":{"path":str(root/"time.json"),"sha256":sha256_file(root/"time.json")},
             "memory_schedule_binding":{"path":str(root/"memory.json"),"sha256":sha256_file(root/"memory.json")},
             "time_rows":rows["time"],"memory_rows":rows["memory"]}
    # Bind all rows to the freeze file's actual hash.
    for row in payload["time_rows"]+payload["memory_rows"]:
        row["manifest_sha256"]=payload["freeze_manifest_binding"]["sha256"]
        row["row_sha256"]=sha256_json({k:v for k,v in row.items() if k!="row_sha256"})
    return payload


def test_analysis_valid_pairing_and_threshold_equalities(synthetic_payload):
    from primary_analysis import analyze,estimate
    result=analyze(synthetic_payload)
    assert result["ratio"]==pytest.approx(1.2) and result["memory_ratio"]==pytest.approx(1.1)
    assert result["utility_pass"] is True
    ones=np.ones((100,30));mem=np.ones((100,15))
    equality=estimate(ones,ones,mem,mem,draws=100)
    assert equality["ratio"]==1.0 and equality["ci95"][0]==1.0 and equality["utility_pass"] is False


@pytest.mark.parametrize("mutation",["missing","duplicate","provenance","failure","pairing","memory"])
def test_analysis_adversarial_rows(synthetic_payload,mutation):
    from primary_analysis import analyze
    payload=copy.deepcopy(synthetic_payload)
    if mutation=="missing": payload["time_rows"].pop()
    elif mutation=="duplicate": payload["time_rows"].append(copy.deepcopy(payload["time_rows"][0]))
    elif mutation=="provenance": payload["time_rows"][0]["root_outcome"]="hybrid_pair"
    elif mutation=="failure":
        payload["time_rows"][0].update(disposition="exception",error_type="RuntimeError",error_message="synthetic")
    elif mutation=="pairing": payload["time_rows"][0]["order_in_block"]+=1
    else: payload["memory_rows"][0]["memory_metric"]="baseline_subtracted"
    for row in payload["time_rows"]+payload["memory_rows"]:
        row["row_sha256"]=sha256_json({k:v for k,v in row.items() if k!="row_sha256"})
    with pytest.raises(ValueError): analyze(payload)


def test_schema_rejects_missing_unknown_and_invalid_natural_provenance(synthetic_payload):
    row=copy.deepcopy(synthetic_payload["time_rows"][0]);row.pop("case_id")
    with pytest.raises(ValueError,match="missing fields"):validate_row(row)
    row=copy.deepcopy(synthetic_payload["time_rows"][0]);row["surprise"]=1
    with pytest.raises(ValueError,match="unknown fields"):validate_row(row)
    row=copy.deepcopy(synthetic_payload["time_rows"][0]);row["stratum"]="G_natural";row["row_sha256"]=sha256_json({k:v for k,v in row.items() if k!="row_sha256"})
    with pytest.raises(ValueError,match="natural provenance"):validate_row(row)


def test_schedule_validation():
    ids=[f"P{i:03d}" for i in range(100)];time,memory=generate_primary_schedules(ids)
    validate_schedules(time,memory,ids)
