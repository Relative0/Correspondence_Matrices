"""Build and validate the non-authorizing Protocol v4 freeze candidate."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from v4_harness import canonical_json, sha256_bytes, sha256_file, sha256_json


EMPTY_SHA="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"


def binding(root:Path,relative:str)->dict[str,Any]:
    path=root/relative
    return {"path":relative.replace("\\","/"),"bytes":path.stat().st_size,"sha256":sha256_file(path)}


def build(root:Path)->dict[str,Any]:
    vf="outputs/v4_freeze/"
    harness_files=["outputs/primary_analysis.py","outputs/gate_a_regressions.py","outputs/finite_core_check.py"]
    harness_files += [str(p.relative_to(root)).replace("\\","/") for p in sorted((root/vf).glob("*.py"))]
    results=[]
    for name in ("correctness.jsonl","diagnostics.jsonl","intake.jsonl","memory.jsonl","time.jsonl"):
        item=binding(root,f"outputs/empty_result_templates/{name}")
        if item["bytes"]!=0 or item["sha256"]!=EMPTY_SHA:raise ValueError(f"nonempty registered result {name}")
        item.update({"append_only":True,"first_row_predecessor":"0"*64});results.append(item)
    blockers=[
        {"id":"V4-B1","gate":"exploratory repeatability",
         "evidence":"Four completed non-confirmatory pilots failed the rule MAD/median <=0.05 for every primary case/arm; timer overhead passed in all four.",
         "repair":"Prospectively revise the timing control or move to a measurably stable host, retain the 0.05 threshold, and pass a new pilot-* run over the frozen 100-case corpus."},
        {"id":"V4-B2","gate":"final environment identity",
         "evidence":"CPU 0 and CPU 11 affinity at nice -20 remained unstable; Balanced host power policy was recorded and not changed.",
         "repair":"After V4-B1 passes, bind the exact host, power policy, affinity, priority, runtime staging, package closure, and memory adapter under a new freeze identity."},
    ]
    manifest={
        "schema":"cm_pair_confirmatory_freeze_v4","status":"NO_GO_PRE_FREEZE_CANDIDATE",
        "candidate_id":"gate-a-v4-candidate-20260923-02-stability-no-go","authorization_to_execute":False,
        "successor_identity_rule":"Any later pilot-qualified confirmatory freeze receives a new run/freeze identity; this candidate ID cannot be reused.",
        "gate_a_verdict":"NO_GO","repository":"https://github.com/Relative0/Correspondence_Matrices",
        "source":{"identity":binding(root,vf+"FINAL_SOURCE_IDENTITY_V4.json"),
                  "closure_manifest":binding(root,"outputs/evidence/source_files.json"),
                  "live_commit":"0ab8ffd0c23ffa71ee951d375b1c170ffdcc084b","isolated_clean":True,
                  "production_repairs":[],"user_dirty_checkout_untouched":True},
        "repairs":{"policy":"All repairs are external harness/protocol/manuscript working-copy files; production source is unchanged.",
                   "files":[binding(root,path) for path in harness_files]},
        "protocol":{"version":4,"working_copy":binding(root,"outputs/EVALUATION_PROTOCOL_V4_WORKING_COPY.md"),
                    "previous_v3_sha256":"54039d0c2ce26a8e9f81dbd6eb60cba6fa093335d1d049afbf6f8269182cdc1f"},
        "manuscript":{"working_tex":binding(root,"outputs/Operator_Level_CM_Compiler_Gate_A_Working_Copy.tex"),
                      "working_pdf":binding(root,"outputs/Operator_Level_CM_Compiler_Gate_A_Working_Copy.pdf"),
                      "contract_matrix":binding(root,vf+"CONTRACT_MATRIX_V4_FINAL.csv"),
                      "companion_pdf_sha256":"ca4c64497e29c40e7398746ef57550f5915e5ce7b5be480cc579dc13601bb4ca",
                      "companion_tex_sha256":"86f2b8cb901c0af3f1a9c0a726f26aa65091d137d33bda21aa157c0985b6fb48",
                      "companion_changed":False,"recovered_audit":binding(root,"outputs/evidence/CM_Compiler_Deep_Audit_2026-09-22.md")},
        "corpora":{"primary":binding(root,vf+"PRIMARY_CORPUS_V4.json"),"secondary":binding(root,vf+"SECONDARY_CELLS_V4.json"),
                   "natural":binding(root,vf+"NATURAL_CORPUS_PROVENANCE_V4.json"),"natural_licenses":binding(root,vf+"NATURAL_LICENSES_V4.md"),
                   "primary_case_count":100,"secondary_cell_count":30,"secondary_case_count":900,"natural_selected_output_count":142,
                   "translated_output_count":142,"abc_qualified_output_count":142,
                   "pairability_observed":False,"selection_precedes_pairability":True,"performance_feedback_used":False},
        "schedules":{"primary_time":binding(root,vf+"PRIMARY_TIME_SCHEDULE_V4.json"),
                     "primary_memory":binding(root,vf+"PRIMARY_MEMORY_SCHEDULE_V4.json"),
                     "secondary_time":binding(root,vf+"SECONDARY_TIME_SCHEDULE_V4.json"),
                     "secondary_memory":binding(root,vf+"SECONDARY_MEMORY_SCHEDULE_V4.json"),
                     "counterbalance_validated":True,"single_call_primary":True},
        "environment":{"candidate":binding(root,vf+"ENVIRONMENT_CANDIDATE_V4.json"),
                       "dependencies":binding(root,vf+"DEPENDENCIES_V4.txt"),
                       "native_toolchain":binding(root,vf+"NATIVE_TOOLCHAIN_V4.json"),
                       "native_tools_untimed_qualified":True,"finalized":False,
                       "worker_environment":{"PYTHONHASHSEED":"20260923","OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1"}},
        "schema":{"normative":binding(root,"outputs/MEASUREMENT_SCHEMA_V4.md"),
                  "machine":binding(root,vf+"RAW_ROW_SCHEMA_V4.json"),
                  "validator":binding(root,vf+"row_schema_v4.py")},
        "analysis":{"source":binding(root,"outputs/primary_analysis.py"),"bootstrap_draws":20000,
                    "seed":2026092304,"quantile_method":"linear",
                    "success_rule":"all gates; R>=1.20; CI lower>1.00; M<=1.10",
                    "synthetic_tests":binding(root,vf+"V4_ADVERSARIAL_SUITE.log")},
        "correctness":{"primary_untimed":binding(root,vf+"PRIMARY_CORRECTNESS_V4.json"),
                       "native_robdd":binding(root,vf+"NATIVE_ROBDD_QUALIFICATION_V4.json"),
                       "native_aig":binding(root,vf+"NATIVE_AIG_QUALIFICATION_V4.json"),
                       "execution_record":binding(root,vf+"VALIDATION_EXECUTION_RECORD_V4.json"),
                       "focused_suite":binding(root,vf+"FOCUSED_SUITE_V4.log"),
                       "boundary_suite":binding(root,vf+"BOUNDARY_17_CATEGORIES_V4.log"),
                       "finite_core":binding(root,vf+"FINITE_CORE_V4.log"),
                       "counts":{"focused_tests":147,"boundary_tests":95,"v4_adversarial_tests":20,
                                 "finite_checks":333794,"primary_oracle_equal":100,
                                 "native_robdd_oracle_equal":1000,"native_aig_oracle_equal":142,"failures":0},
                       "recovered_audit_reference_assertions":1083999,
                       "reference_assertions_counted_separately":True},
        "commands":{"correctness":"python outputs/v4_freeze/qualify_v4.py outputs/v4_freeze --output outputs/v4_freeze/PRIMARY_CORRECTNESS_V4.json",
                    "focused":"python -m pytest work/source/tests/test_cm_pair_alignment.py work/source/tests/test_cm_optimizations.py work/source/tests/test_output_budget.py work/source/tests/test_bitset_backend.py work/source/tests/test_bitset_cse.py -q -p no:cacheprovider",
                    "boundary":"python -m pytest outputs/gate_a_regressions.py -q -p no:cacheprovider",
                    "v4_adversarial":"work/native_tools/py312/bin/python -m pytest outputs/v4_freeze/test_v4_freeze.py -q -p no:cacheprovider --basetemp=work/pytest_v4_wsl_final",
                    "finite":"work/native_tools/py312/bin/python outputs/finite_core_check.py",
                    "native_robdd":"work/native_tools/py312/bin/python outputs/v4_freeze/native_robdd_qualify_v4.py outputs/v4_freeze --output outputs/v4_freeze/NATIVE_ROBDD_QUALIFICATION_V4.json",
                    "native_aig":"work/native_tools/py312/bin/python outputs/v4_freeze/native_aig_qualify_v4.py <workspace> <natural-manifest> <output>",
                    "pilot_repair":"Run a new pilot-* identity only after a prospective timing/environment repair; retain MAD/median <=0.05 and timer overhead <=1%.",
                    "confirmatory":"DISABLED_NO_GO"},
        "pilot":{"status":"FAILED_STABILITY_GATE","confirmatory":False,
                 "summary":binding(root,vf+"PILOT_CONTROL_SUMMARY_V4.json"),
                 "source":binding(root,vf+"pilot_v4.py")},
        "results":results,"blockers":blockers,"frozen_execution_prompt_created":False,
        "repair_prompt_required":True,
        "repair_prompt":binding(root,"outputs/REPAIR_PROMPT_TIMING_STABILITY_V4.md"),
    }
    manifest["candidate_manifest_sha256"]=sha256_json(manifest)
    return manifest


def validate(root:Path,manifest:dict[str,Any])->dict[str,Any]:
    failures=[]
    def check(value:Any)->None:
        if isinstance(value,dict):
            if set(("path","bytes","sha256"))<=set(value):
                path=root/value["path"]
                if not path.exists() or path.stat().st_size!=value["bytes"] or sha256_file(path)!=value["sha256"]:
                    failures.append(value["path"])
            for child in value.values():check(child)
        elif isinstance(value,list):
            for child in value:check(child)
    unsigned=dict(manifest);digest=unsigned.pop("candidate_manifest_sha256")
    if sha256_json(unsigned)!=digest:failures.append("candidate_manifest_sha256")
    check(manifest)
    if manifest["authorization_to_execute"] is not False or manifest["status"]!="NO_GO_PRE_FREEZE_CANDIDATE":failures.append("authorization/status")
    if not manifest["blockers"]:failures.append("blockers")
    return {"schema":"cm_pair_candidate_manifest_validation_v4","valid_candidate":not failures,
            "authorized_freeze":False,"failures":failures,"checked_bindings":"all recursively bound path/size/SHA-256 triples",
            "confirmatory_performance_inspected":False}


if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("workspace");p.add_argument("manifest");p.add_argument("validation");a=p.parse_args()
    root=Path(a.workspace).resolve();manifest=build(root);Path(a.manifest).write_bytes(canonical_json(manifest)+b"\n")
    validation=validate(root,manifest);Path(a.validation).write_bytes(canonical_json(validation)+b"\n")
    print(json.dumps({"manifest_sha256":sha256_file(a.manifest),**validation},indent=2,sort_keys=True))
