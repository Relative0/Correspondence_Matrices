"""Build the prospective natural-corpus intake manifest without pairability."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from v4_harness import canonical_json, sha256_bytes, sha256_file, sha256_json


YOSYS_BENCH_COMMIT="52ff6fa991f2ab509618d8aaad02f307aac78848"
UPSTREAM_COMMIT="32a2b86b0b1fee22f975bf15a64432b60540ac0e"
EXPECTED={
    "yosys/LICENSE.txt":"44d054188ebd92dbbd86093849ae6779e937bd7e719269b05e2a459690740293",
    "yosys/cam/README.md":"e234aa98ef327d4d77e04ce8b83b705f8ea47ce19b6a3891015a27c0d32d2dc4",
    "yosys/cam/cam_bram_top.v":"ac0b0c9eb96182ae533a3ba61373f2ae195c7b6a9c9195c8d10ccaa1393b064f",
    "yosys/cam/cam_srl_top.v":"2797bc102bd38031e7b521e3abfaf5cc103ffcf8c8f233d8a4932a5ca1ed68de",
    "yosys/cam/generate.py":"0a9ed37e2285d81d86bdb3b6b0b1928e6b19bad52b0c00ee92e4a91ccecf5d6b",
    "upstream/COPYING":"44c3a342489bdf0f32a9f54cd7db63eadbca415937ae71745c776ae17629fcc7",
    "upstream/rtl/cam_srl.v":"2850cd095f892663e45fa36e853367b473906e595cc937af245e0bdf2721930e",
    "upstream/rtl/cam_bram.v":"182db191ce8877cfa0cc64246486007c47f07a2caf78cc0ed39cdd210a4d1c67",
    "upstream/rtl/priority_encoder.v":"2ed57706618fa2e7cd756763f7dcb49c981c0d0505ca46b83a7ec5d18288beeb",
    "upstream/rtl/ram_dp.v":"bed3e10087194c9d29f0841246cfc3bceef5cab2fe3052c60563aeebe75db0ef",
}


def output_ids(top:str)->list[str]:
    result=[f"{top}.write_busy"]
    result += [f"{top}.match_many[{i}]" for i in range(32)]
    result += [f"{top}.match_single[{i}]" for i in range(32)]
    result += [f"{top}.match_addr[{i}]" for i in range(5)]
    result += [f"{top}.match"]
    return result


def build(workspace:Path,translator:Path)->dict[str,Any]:
    y=workspace/"work/natural_yosys_bench";u=workspace/"work/natural_verilog_cam"
    actual={
        "yosys/LICENSE.txt":sha256_file(y/"LICENSE.txt"),
        "yosys/cam/README.md":sha256_file(y/"verilog/benchmarks_large/cam/README.md"),
        "yosys/cam/cam_bram_top.v":sha256_file(y/"verilog/benchmarks_large/cam/cam_bram_top.v"),
        "yosys/cam/cam_srl_top.v":sha256_file(y/"verilog/benchmarks_large/cam/cam_srl_top.v"),
        "yosys/cam/generate.py":sha256_file(y/"verilog/benchmarks_large/cam/generate.py"),
        "upstream/COPYING":sha256_file(u/"COPYING"),
        "upstream/rtl/cam_srl.v":sha256_file(u/"rtl/cam_srl.v"),
        "upstream/rtl/cam_bram.v":sha256_file(u/"rtl/cam_bram.v"),
        "upstream/rtl/priority_encoder.v":sha256_file(u/"rtl/priority_encoder.v"),
        "upstream/rtl/ram_dp.v":sha256_file(u/"rtl/ram_dp.v"),
    }
    if actual!=EXPECTED:raise ValueError("natural source hash mismatch")
    selected=[]
    for top,wrapper,deps in (
        ("cam_srl_top","cam_srl_top.v",["cam_srl.v","priority_encoder.v"]),
        ("cam_bram_top","cam_bram_top.v",["cam_bram.v","priority_encoder.v","ram_dp.v"]),
    ):
        for output in output_ids(top):
            selected.append({"source_output_id":output,"top":top,"wrapper":wrapper,
                             "dependencies":deps,"status":"selected_before_translation",
                             "pairability":"UNOBSERVED","translated_dag_sha256":"PENDING_NATIVE_TOOLCHAIN"})
    commands={
        "cam_srl_top":"yosys -Q -p \"read_verilog -I staged staged/cam_srl_top.v; hierarchy -check -top cam_srl_top; proc; flatten; memory_map; opt; techmap; opt_clean; aigmap; write_aiger -ascii -symbols -zinit cam_srl_top.aag\"",
        "cam_bram_top":"yosys -Q -p \"read_verilog -I staged staged/cam_bram_top.v; hierarchy -check -top cam_bram_top; proc; flatten; memory_map; opt; techmap; opt_clean; aigmap; write_aiger -ascii -symbols -zinit cam_bram_top.aag\"",
    }
    manifest={
        "schema":"cm_pair_natural_corpus_v4","status":"PROVENANCE_AND_SELECTION_FROZEN_TRANSLATION_BLOCKED",
        "selection_timestamp_utc":"2026-09-23T00:00:00Z","pair_compiler_executed":False,"performance_observed":False,
        "source_projects":[
            {"repository":"https://github.com/YosysHQ/yosys-bench","revision":YOSYS_BENCH_COMMIT,"license":"ISC collection; selected wrappers carry MIT headers"},
            {"repository":"https://github.com/alexforencich/verilog-cam","revision":UPSTREAM_COMMIT,"license":"MIT"}],
        "original_file_hashes":actual,
        "selection_rule":"At default DATA_WIDTH=64 and ADDR_WIDTH=5, retain every declared output bit of both CAM top modules: write_busy, match_many[0:31], match_single[0:31], match_addr[0:4], and match. Selection is independent of translation success, size, pairability, token, latency, and memory.",
        "selected_output_count":len(selected),"selected_outputs":selected,
        "staging_map":{
            "cam_srl_top.v":"yosys-bench/verilog/benchmarks_large/cam/cam_srl_top.v",
            "cam_bram_top.v":"yosys-bench/verilog/benchmarks_large/cam/cam_bram_top.v",
            "cam_srl.vh":"verilog-cam/rtl/cam_srl.v","cam_bram.vh":"verilog-cam/rtl/cam_bram.v",
            "priority_encoder.vh":"verilog-cam/rtl/priority_encoder.v","ram_dp.vh":"verilog-cam/rtl/ram_dp.v"},
        "extraction_commands":commands,
        "translation_rules":"ASCII AIGER parser aag_to_cm_ast_v1.py; primary inputs and latch outputs become variables; AND nodes preserve AIG sharing; complemented literals become Not; constant 0 becomes one additional fixed-false variable and constant 1 its Not; no simplification; every selected output retained, with parser/tool failures recorded in intake.",
        "translator_sha256":sha256_file(translator),
        "abc_applicable_subset":"All selected outputs whose exact frozen Yosys command emits valid ASCII AIGER. Applicability depends only on parser/dialect/tool success and is fixed before pairability.",
        "prospective_exclusions":["source parse failure","unsupported AIGER dialect","translation failure","60-second timeout","output-budget refusal"],
        "blocker":"Frozen Yosys/ABC executables are unavailable, so extraction has not run and translated DAG hashes cannot yet be populated."}
    manifest["manifest_sha256"]=sha256_json(manifest)
    return manifest


if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("workspace");p.add_argument("translator");p.add_argument("output")
    a=p.parse_args();value=build(Path(a.workspace),Path(a.translator));Path(a.output).write_bytes(canonical_json(value)+b"\n")

