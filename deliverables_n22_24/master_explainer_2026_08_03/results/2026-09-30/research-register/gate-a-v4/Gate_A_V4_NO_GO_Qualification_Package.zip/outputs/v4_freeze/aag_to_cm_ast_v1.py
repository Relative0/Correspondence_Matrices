"""Prospective ASCII AIGER-to-Expr translator used by the natural-corpus freeze.

It preserves AND DAG sharing. Primary inputs and latch outputs are variables.
Literal 0 is one additional fixed-false variable; literal 1 is its negation.
No simplification or pairability query occurs during translation.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from cm_exprlib import And, Expr, Not, Var
from v4_harness import serialize_identity_dag, sha256_bytes, sha256_json


def parse_aag(path: str | Path) -> dict[str, Any]:
    raw=Path(path).read_bytes();lines=raw.decode("ascii").splitlines()
    header=lines[0].split()
    if len(header)!=6 or header[0]!="aag":raise ValueError("ASCII AIGER 1.9 aag required")
    maximum,inputs,latches,outputs,ands=map(int,header[1:])
    cursor=1
    input_literals=[int(lines[cursor+i].split()[0]) for i in range(inputs)];cursor+=inputs
    latch_lines=[list(map(int,lines[cursor+i].split()[:2])) for i in range(latches)];cursor+=latches
    output_literals=[int(lines[cursor+i].split()[0]) for i in range(outputs)];cursor+=outputs
    gates=[list(map(int,lines[cursor+i].split()[:3])) for i in range(ands)]
    var_for_literal={lit:Var(i) for i,lit in enumerate(input_literals)}
    for i,(current,_next) in enumerate(latch_lines):var_for_literal[current]=Var(inputs+i)
    fixed_false_index=inputs+latches
    positive:dict[int,Expr]={0:Var(fixed_false_index),**var_for_literal}
    negative:dict[int,Expr]={1:Not(positive[0])}
    def resolve(literal:int)->Expr:
        if literal&1:
            if literal not in negative:negative[literal]=Not(resolve(literal-1))
            return negative[literal]
        try:return positive[literal]
        except KeyError:raise ValueError(f"undefined AIG literal {literal}")
    for lhs,rhs0,rhs1 in gates:
        if lhs&1 or lhs in positive:raise ValueError("invalid/redefined AIG AND literal")
        positive[lhs]=And(resolve(rhs0),resolve(rhs1))
    translated=[]
    for index,literal in enumerate(output_literals):
        dag=serialize_identity_dag(resolve(literal))
        translated.append({"output_index":index,"aig_literal":literal,"identity_dag":dag,
                           "identity_dag_sha256":sha256_json(dag)})
    return {"format":"cm_natural_translation_v1","original_content_sha256":sha256_bytes(raw),
            "aiger_header":{"M":maximum,"I":inputs,"L":latches,"O":outputs,"A":ands},
            "fixed_bindings":{f"x{fixed_false_index}":0},"outputs":translated}

