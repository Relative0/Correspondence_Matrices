"""Freeze untimed natural AIGER translations and all intake dispositions.

This module never calls the pair compiler and never observes performance.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from aag_to_cm_ast_v1 import parse_aag
from natural_freeze import build as build_prospective
from v4_harness import canonical_json, sha256_file, sha256_json


FINAL_YOSYS = (
    'yosys -q -Q -p "read_verilog -I staged staged/{top}.v; '
    'hierarchy -check -top {top}; proc; flatten; memory; opt; techmap; '
    'opt_clean; setundef -zero; dffunmap; aigmap; '
    'write_aiger -ascii -symbols -zinit {top}.aag; '
    'write_aiger -symbols -zinit {top}.raw.aig"'
)
FINAL_ABC = (
    'yosys-abc -q "read_aiger {top}.raw.aig; strash; print_stats; '
    'write_aiger -s {top}.abc.aig"'
)


def binding(workspace: Path, path: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(workspace).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def output_symbols(path: Path, count: int) -> list[str]:
    symbols: dict[int, str] = {}
    pattern = re.compile(r"^o(\d+) (.+)$")
    for line in path.read_text(encoding="ascii").splitlines():
        match = pattern.match(line)
        if match:
            symbols[int(match.group(1))] = match.group(2)
    if set(symbols) != set(range(count)):
        raise ValueError(f"incomplete output symbol table for {path.name}")
    return [symbols[i] for i in range(count)]


def build(workspace: Path, output: Path) -> dict[str, Any]:
    vf = workspace / "outputs" / "v4_freeze"
    translation_root = vf / "natural_translations"
    translation_root.mkdir(parents=True, exist_ok=True)
    natural_work = workspace / "work" / "natural_translation"
    manifest = build_prospective(workspace, vf / "aag_to_cm_ast_v1.py")
    manifest.pop("manifest_sha256", None)

    tool_root = workspace / "work" / "native_tools" / "yosys_root" / "usr" / "bin"
    package_root = workspace / "work" / "native_tools" / "debs"
    manifest["toolchain"] = {
        "environment": "Ubuntu-24.04 under WSL2; all non-system artifacts stored in work/native_tools",
        "yosys_version": "Yosys 0.33 (git sha1 2584903a060)",
        "abc_version": "UC Berkeley, ABC 1.01 (compiled Apr 1 2024 04:53:45)",
        "binaries": {
            "yosys": binding(workspace, tool_root / "yosys"),
            "yosys-abc": binding(workspace, tool_root / "yosys-abc"),
        },
        "packages": {
            name: binding(workspace, package_root / name)
            for name in (
                "yosys_0.33-5build2_amd64.deb",
                "yosys-abc_0.33-5build2_amd64.deb",
                "libtcl8.6_8.6.14+dfsg-1build1_amd64.deb",
            )
        },
    }

    attempts = [
        {
            "top": "cam_srl_top", "revision": "original-v4", "status": "failed",
            "command": manifest["extraction_commands"]["cam_srl_top"],
            "failure": "Unsupported cell type: $_DFFE_PP_",
            "log": binding(workspace, natural_work / "cam_srl_top.yosys.log"),
        },
        {
            "top": "cam_srl_top", "revision": "v4.1", "status": "failed",
            "command": manifest["extraction_commands"]["cam_srl_top"].replace("aigmap", "dffunmap; opt; aigmap"),
            "failure": "Unsupported cell type: $_DFFE_PP_ (opt reintroduced enabled flip-flops)",
            "log": binding(workspace, natural_work / "cam_srl_top.yosys.v4_1.log"),
        },
        {
            "top": "cam_srl_top", "revision": "v4.2", "status": "failed",
            "command": manifest["extraction_commands"]["cam_srl_top"].replace("opt_clean; aigmap", "opt_clean; dffunmap; aigmap"),
            "failure": "Design contains x or z bits",
            "log": binding(workspace, natural_work / "cam_srl_top.yosys.v4_2.log"),
        },
        {
            "top": "cam_bram_top", "revision": "v4.3", "status": "failed",
            "command": manifest["extraction_commands"]["cam_bram_top"].replace("opt_clean; aigmap", "opt_clean; setundef -zero; dffunmap; aigmap"),
            "failure": "Found unmapped memories in module cam_bram_top",
            "log": binding(workspace, natural_work / "cam_bram_top.yosys.v4_3.log"),
        },
        {
            "top": "both", "revision": "abc-ascii", "status": "failed",
            "command": 'yosys-abc -q "read_aiger <top>.aag; strash; print_stats; write_aiger -s <top>.aig"',
            "failure": "Wrong input file format (sequential ASCII AIGER)",
            "log": binding(workspace, natural_work / "abc.v4.log"),
        },
    ]

    translations: dict[str, Any] = {}
    by_id = {item["source_output_id"]: item for item in manifest["selected_outputs"]}
    for top in ("cam_srl_top", "cam_bram_top"):
        aag = natural_work / f"{top}.aag"
        parsed = parse_aag(aag)
        symbols = output_symbols(aag, parsed["aiger_header"]["O"])
        if len(symbols) != 71:
            raise ValueError(f"unexpected output count for {top}")
        bundle = {
            **parsed,
            "top": top,
            "output_symbols": symbols,
            "extraction_command": FINAL_YOSYS.format(top=top),
            "abc_command": FINAL_ABC.format(top=top),
        }
        bundle_path = translation_root / f"{top}.translation.json"
        bundle_path.write_bytes(canonical_json(bundle) + b"\n")
        bundle_binding = binding(workspace, bundle_path)
        translations[top] = {
            "aag": binding(workspace, aag),
            "raw_aig": binding(workspace, natural_work / f"{top}.raw.aig"),
            "abc_aig": binding(workspace, natural_work / f"{top}.abc.aig"),
            "translation_bundle": bundle_binding,
            "aiger_header": parsed["aiger_header"],
            "fixed_bindings": parsed["fixed_bindings"],
            "output_count": len(symbols),
        }
        for index, (symbol, translated) in enumerate(zip(symbols, parsed["outputs"])):
            source_id = f"{top}.{symbol}"
            if source_id not in by_id:
                raise ValueError(f"unselected translated output {source_id}")
            item = by_id[source_id]
            item.update({
                "status": "translated_untimed",
                "aiger_output_index": index,
                "aiger_literal": translated["aig_literal"],
                "translated_dag_sha256": translated["identity_dag_sha256"],
                "translation_bundle_sha256": bundle_binding["sha256"],
                "pairability": "UNOBSERVED",
            })
        attempts.append({
            "top": top, "revision": "v4-final", "status": "translated_untimed",
            "command": FINAL_YOSYS.format(top=top),
            "log": binding(workspace, natural_work / "yosys.final.log"),
            "aag_sha256": translations[top]["aag"]["sha256"],
        })
        attempts.append({
            "top": top, "revision": "abc-binary-final", "status": "qualified_untimed",
            "command": FINAL_ABC.format(top=top),
            "log": binding(workspace, natural_work / "abc.final.log"),
            "abc_aig_sha256": translations[top]["abc_aig"]["sha256"],
        })

    if any(item["status"] != "translated_untimed" for item in manifest["selected_outputs"]):
        raise AssertionError("not every prospectively selected output translated")
    manifest.update({
        "status": "TRANSLATIONS_FROZEN_PAIRABILITY_UNOBSERVED",
        "extraction_commands": {top: FINAL_YOSYS.format(top=top) for top in translations},
        "abc_commands": {top: FINAL_ABC.format(top=top) for top in translations},
        "translation_bundles": translations,
        "intake_attempts": attempts,
        "translated_output_count": len(manifest["selected_outputs"]),
        "abc_applicable_output_count": len(manifest["selected_outputs"]),
        "blocker": None,
        "pair_compiler_executed": False,
        "performance_observed": False,
    })
    manifest["manifest_sha256"] = sha256_json(manifest)
    output.write_bytes(canonical_json(manifest) + b"\n")
    return manifest


if __name__ == "__main__":
    import argparse
    import json

    parser = argparse.ArgumentParser()
    parser.add_argument("workspace")
    parser.add_argument("output")
    args = parser.parse_args()
    value = build(Path(args.workspace).resolve(), Path(args.output).resolve())
    print(json.dumps({
        "status": value["status"],
        "selected": value["selected_output_count"],
        "translated": value["translated_output_count"],
        "abc_applicable": value["abc_applicable_output_count"],
        "manifest_sha256": value["manifest_sha256"],
    }, indent=2, sort_keys=True))
