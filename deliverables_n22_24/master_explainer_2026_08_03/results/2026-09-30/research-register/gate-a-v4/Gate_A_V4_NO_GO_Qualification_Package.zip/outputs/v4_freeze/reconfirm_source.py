"""Reconfirm the isolated source closure against one clean Git commit."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess

from v4_harness import canonical_json, sha256_bytes, sha256_file, sha256_json


def command_bytes(args:list[str],cwd:Path)->bytes:
    return subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout


def build(workspace:Path,output:Path)->dict:
    live=workspace/"work/live";snapshot=workspace/"work/source"
    old=json.loads((workspace/"outputs/evidence/source_files.json").read_text(encoding="utf-8"))
    commit=command_bytes(["git","rev-parse","HEAD"],live).decode().strip()
    if commit!="0ab8ffd0c23ffa71ee951d375b1c170ffdcc084b":raise ValueError("live commit changed")
    status=command_bytes(["git","status","--porcelain=v2"],live)
    if status:raise ValueError("isolated live repository is dirty")
    tree={}
    for line in command_bytes(["git","ls-tree","-r",commit],live).decode("utf-8").splitlines():
        left,path=line.split("\t",1);tree[path]=left.split()[2]
    verified=[]
    for expected in old:
        path=expected["path"]
        data=(snapshot/path).read_bytes()
        if sha256_bytes(data)!=expected["sha256"] or len(data)!=expected["bytes"]:
            raise ValueError(f"snapshot mismatch {path}")
        blob_sha1=hashlib.sha1(f"blob {len(data)}\0".encode("ascii")+data).hexdigest()
        if tree.get(path)!=expected["git_blob"] or blob_sha1!=expected["git_blob"]:
            raise ValueError(f"snapshot differs from Git blob {path}")
        verified.append(expected)
    manifest_bytes=canonical_json(verified)
    dirty=Path("C:/Users/brian/Documents/CM_Computation")
    safe=["git","-c",f"safe.directory={dirty.as_posix()}","-C",str(dirty)]
    dirty_commit=subprocess.run(safe+["rev-parse","HEAD"],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout.decode().strip()
    dirty_status=subprocess.run(safe+["status","--porcelain=v2"],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    dirty_lines=dirty_status.decode("utf-8").splitlines()
    result={"schema":"cm_pair_final_source_identity_v4","repository":"https://github.com/Relative0/Correspondence_Matrices",
            "commit":commit,"isolated_live_clean":True,"snapshot_location":"work/source",
            "snapshot_file_count":len(verified),"snapshot_files_sha256":sha256_bytes(manifest_bytes),
            "production_source_repairs":[],"production_source_changed":False,
            "policy":"Every closure byte equals the Git blob at the recorded commit; all v4 repairs are external harness files.",
            "user_dirty_checkout":"C:/Users/brian/Documents/CM_Computation",
            "user_dirty_checkout_commit":dirty_commit,"user_dirty_checkout_status_sha256":sha256_bytes(dirty_status),
            "user_dirty_checkout_status_count":len(dirty_lines),"user_dirty_checkout_status_lines":dirty_lines,
            "user_dirty_checkout_action":"read identity only; never cleaned, reset, restored, staged, or edited"}
    result["identity_sha256"]=sha256_json(result)
    output.write_bytes(canonical_json(result)+b"\n")
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("workspace");p.add_argument("output");a=p.parse_args()
    print(json.dumps(build(Path(a.workspace),Path(a.output)),indent=2,sort_keys=True))
