"""Untimed qualification of every prospectively selected natural AIG output."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from abc_aig_adapter_v4 import (
    convert_with_yosys, execute_abc, qualify_equivalence,
    write_one_output_combinational_aag,
)
from v4_harness import canonical_json, sha256_file, sha256_json


def binding(workspace: Path, path: Path) -> dict[str, Any]:
    return {"path": path.relative_to(workspace).as_posix(), "bytes": path.stat().st_size,
            "sha256": sha256_file(path)}


def qualify(workspace: Path, manifest_path: Path, output: Path) -> dict[str, Any]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("pair_compiler_executed") is not False or manifest.get("performance_observed") is not False:
        raise ValueError("natural intake contamination barrier is not intact")
    selected = manifest["selected_outputs"]
    if len(selected) != 142 or any(item.get("pairability") != "UNOBSERVED" for item in selected):
        raise ValueError("expected 142 prospectively selected, pairability-unobserved outputs")

    tool_root = workspace / "work" / "native_tools" / "yosys_root"
    yosys = tool_root / "usr" / "bin" / "yosys"
    abc = tool_root / "usr" / "bin" / "yosys-abc"
    natural_root = workspace / "work" / "natural_translation"
    artifact_root = natural_root / "per_output"
    records: list[dict[str, Any]] = []
    by_top: dict[str, int] = {}
    for item in selected:
        top = item["top"]
        index = int(item["aiger_output_index"])
        stem = f"{top}.o{index:03d}"
        aag = artifact_root / f"{stem}.aag"
        raw = artifact_root / f"{stem}.raw.aig"
        optimized = artifact_root / f"{stem}.abc.aig"
        write_one_output_combinational_aag(natural_root / f"{top}.aag", index, aag)
        raw_record = convert_with_yosys(aag, raw, yosys=yosys, tool_root=tool_root)
        optimized_record = execute_abc(raw, optimized, abc=abc, tool_root=tool_root)
        equivalence = qualify_equivalence(raw, optimized, abc=abc, tool_root=tool_root)
        records.append({
            "source_output_id": item["source_output_id"], "top": top,
            "output_index": index, "translated_dag_sha256": item["translated_dag_sha256"],
            "combinational_aag": binding(workspace, aag),
            "raw_aig": {**binding(workspace, raw), "command": raw_record["command"]},
            "abc_aig": {**binding(workspace, optimized), "command": optimized_record["command"]},
            "equivalence": equivalence,
        })
        by_top[top] = by_top.get(top, 0) + 1

    result = {
        "schema": "cm_pair_native_aig_qualification_v4",
        "status": "QUALIFIED_UNTIMED",
        "endpoint": "one-output combinational binary AIG; natural descriptive control only",
        "latch_policy": "current latch values become independent inputs, matching AAG-to-CM translation",
        "applicability_rule": manifest["abc_applicable_subset"],
        "natural_manifest_sha256": sha256_file(manifest_path),
        "adapter_sha256": sha256_file(Path(__file__).with_name("abc_aig_adapter_v4.py")),
        "yosys": manifest["toolchain"]["binaries"]["yosys"],
        "abc": manifest["toolchain"]["binaries"]["yosys-abc"],
        "selected_outputs": len(selected), "qualified_outputs": len(records),
        "failures": 0, "by_top": by_top,
        "performance_observed": False, "pair_compiler_executed": False,
        "records": records,
    }
    result["qualification_sha256"] = sha256_json(result)
    output.write_bytes(canonical_json(result) + b"\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("workspace")
    parser.add_argument("manifest")
    parser.add_argument("output")
    args = parser.parse_args()
    value = qualify(Path(args.workspace).resolve(), Path(args.manifest).resolve(), Path(args.output).resolve())
    print(json.dumps({key: value[key] for key in (
        "status", "selected_outputs", "qualified_outputs", "failures",
        "performance_observed", "pair_compiler_executed", "qualification_sha256")
    }, indent=2, sort_keys=True))
