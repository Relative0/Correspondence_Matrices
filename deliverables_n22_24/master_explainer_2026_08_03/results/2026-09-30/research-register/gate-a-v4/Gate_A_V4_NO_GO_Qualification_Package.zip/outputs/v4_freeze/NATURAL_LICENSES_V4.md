# Natural corpus license record v4

Selection was frozen before translation or any pairability pass.

## Yosys-bench collection

Repository: `https://github.com/YosysHQ/yosys-bench`, commit
`52ff6fa991f2ab509618d8aaad02f307aac78848`.

The collection-level `LICENSE.txt` is ISC, SHA-256
`44d054188ebd92dbbd86093849ae6779e937bd7e719269b05e2a459690740293`.
The two selected wrapper files contain the MIT notice of Alex Forencich; their
hashes are in `NATURAL_CORPUS_PROVENANCE_V4.json`.

ISC notice: Copyright (c) 2018, Symbiotic EDA GmbH. Permission to use, copy,
modify, and/or distribute this software for any purpose with or without fee is
granted, provided that the copyright notice and permission notice appear in all
copies. The software is provided as-is without warranty; the author disclaims
liability for damages arising from its use.

## Verilog CAM upstream

Repository: `https://github.com/alexforencich/verilog-cam`, commit
`32a2b86b0b1fee22f975bf15a64432b60540ac0e`.

The upstream `COPYING` file is MIT, SHA-256
`44c3a342489bdf0f32a9f54cd7db63eadbca415937ae71745c776ae17629fcc7`.
It grants permission to use, copy, modify, merge, publish, distribute,
sublicense, and sell copies, provided the copyright and permission notice are
included. The software is provided as-is without warranty or liability.

The selected sources are therefore distributable with their notices retained.
This record does not substitute for the full license texts in the immutable
source snapshots.

