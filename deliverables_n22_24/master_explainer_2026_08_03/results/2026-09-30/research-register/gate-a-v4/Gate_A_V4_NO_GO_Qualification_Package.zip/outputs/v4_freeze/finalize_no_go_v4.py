"""Build final native, environment, pilot, and validation records for Gate A.

This module reads only qualification artifacts. It never opens confirmatory
result rows or executes a performance campaign.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from v4_harness import canonical_json, sha256_file, sha256_json


def binding(workspace: Path, path: Path) -> dict[str, Any]:
    return {"path": path.relative_to(workspace).as_posix(), "bytes": path.stat().st_size,
            "sha256": sha256_file(path)}


def write_json(path: Path, value: dict[str, Any]) -> None:
    value["record_sha256"] = sha256_json(value)
    path.write_bytes(canonical_json(value) + b"\n")


def summarize_pilot(workspace: Path, path: Path) -> dict[str, Any]:
    pilot = json.loads(path.read_text(encoding="utf-8"))
    rows = pilot["rows"]
    failed = [row for row in rows if not row["control_pass"]]
    return {
        "artifact": binding(workspace, path), "run_id": pilot["run_id"],
        "confirmatory": pilot["confirmatory"], "repetitions": pilot["repetitions"],
        "corpus_sha256": pilot["corpus_sha256"],
        "worker_affinity": pilot.get("worker_affinity"), "worker_nice": pilot.get("worker_nice"),
        "controls_total": len(rows), "controls_passed": len(rows) - len(failed),
        "controls_failed": len(failed),
        "cm_pure_failed": sum(row["arm_id"] == "cm_pure" for row in failed),
        "direct_packed_failed": sum(row["arm_id"] == "direct_packed" for row in failed),
        "timer_overhead_failed": sum(row["timer_overhead_fraction"] > 0.01 for row in rows),
        "variability_failed": sum(row["mad_over_median"] > 0.05 for row in rows),
        "maximum_mad_over_median": max(row["mad_over_median"] for row in rows),
        "all_controls_pass": pilot["all_controls_pass"],
    }


def build(workspace: Path) -> None:
    vf = workspace / "outputs" / "v4_freeze"
    pilot_paths = [vf / f"EXPLORATORY_PILOT_V4_WSL_{index:02d}.json" for index in (1, 3, 4, 5)]
    pilots = [summarize_pilot(workspace, path) for path in pilot_paths]
    pilot_record = {
        "schema": "cm_pair_pilot_control_summary_v4", "status": "FAILED_STABILITY_GATE",
        "thresholds": {"mad_over_median_max": 0.05, "timer_overhead_fraction_max": 0.01},
        "selection_policy": "environment controls only; no corpus or formula selected from performance",
        "attempts": pilots,
        "retained_setup_failures": [{
            "run_id": "pilot-v4-wsl-20260923-02", "measurements_started": False,
            "failure": "WSL cleared /tmp staging before launch; no output artifact was created",
        }],
        "qualified": False, "confirmatory_performance_inspected": False,
    }
    write_json(vf / "PILOT_CONTROL_SUMMARY_V4.json", pilot_record)

    natural = json.loads((vf / "NATURAL_CORPUS_PROVENANCE_V4.json").read_text(encoding="utf-8"))
    native = {
        "schema": "cm_pair_native_toolchain_v4", "status": "QUALIFIED_UNTIMED",
        "robdd": {
            "backend": "dd.cudd", "dd_version": "0.6.0", "cudd_version": "3.0.0",
            "policy": "fresh manager; ambient row/column order then remaining xN numeric; dynamic reordering disabled",
            "adapter": binding(workspace, vf / "v4_harness.py"),
            "qualification": binding(workspace, vf / "NATIVE_ROBDD_QUALIFICATION_V4.json"),
            "qualified_cases": 1000, "failures": 0, "qualified": True,
        },
        "aig": {
            "yosys_version": natural["toolchain"]["yosys_version"],
            "abc_version": natural["toolchain"]["abc_version"],
            "binaries": natural["toolchain"]["binaries"], "packages": natural["toolchain"]["packages"],
            "adapter": binding(workspace, vf / "abc_aig_adapter_v4.py"),
            "qualification": binding(workspace, vf / "NATIVE_AIG_QUALIFICATION_V4.json"),
            "applicable_outputs": 142, "qualified_outputs": 142, "failures": 0,
            "endpoint": "one-output combinational binary AIG; descriptive natural control only",
            "qualified": True,
        },
        "applicable_subset_rule": natural["abc_applicable_subset"],
        "performance_observations": 0, "confirmatory_authorization": False,
        "remaining_blocker": "the predeclared exploratory repeatability gate failed",
    }
    write_json(vf / "NATIVE_TOOLCHAIN_V4.json", native)

    environment = {
        "schema": "cm_pair_environment_candidate_v4", "status": "NOT_QUALIFIED_STABILITY_FAILURE",
        "host": {"cpu": "AMD Ryzen 5 PRO 5650U with Radeon Graphics", "cores": 6,
                 "logical_cpus": 12, "host_power_policy": "Balanced",
                 "power_scheme_guid": "381b4222-f694-41f0-9685-ff5bb260df2e"},
        "guest": {"distribution": "Ubuntu 24.04.4 LTS", "kernel": "6.18.33.2-microsoft-standard-WSL2",
                  "architecture": "x86_64", "memory_total_kib": 16020108,
                  "swap_total_kib": 4194304, "clocksource": "hyperv_clocksource_tsc_page"},
        "python": {"version": "3.12.3", "compiler": "GCC 13.3.0",
                   "executable": binding(workspace, workspace / "work" / "native_tools" / "py312" / "bin" / "python")},
        "packages": {"numpy": "2.3.2", "dd": "0.6.0", "cudd": "3.0.0", "pytest": "8.4.2"},
        "timer": {"name": "time.perf_counter_ns", "implementation": "clock_gettime(CLOCK_MONOTONIC)",
                  "resolution_seconds": 1e-9},
        "memory_metric": "ru_maxrss", "memory_units": "bytes after Linux KiB-to-byte conversion",
        "worker_environment": {"PYTHONHASHSEED": "20260923", "OMP_NUM_THREADS": "1",
                               "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"},
        "candidate_controls": {"runtime_staging": "/home/brian/cm_pair_gate_a_v4_runtime",
                               "affinity_trials": [[0], [11]], "maximum_priority_trial_nice": -20},
        "pilot_summary": binding(workspace, vf / "PILOT_CONTROL_SUMMARY_V4.json"),
        "qualified": False, "authorization_to_execute": False,
        "reason": "No attempted final environment passed MAD/median <= 0.05 for all 200 case/arm controls.",
    }
    write_json(vf / "ENVIRONMENT_CANDIDATE_V4.json", environment)

    source = json.loads((vf / "FINAL_SOURCE_IDENTITY_V4.json").read_text(encoding="utf-8"))
    record = {
        "schema": "cm_pair_validation_execution_record_v4", "performance_observations": 0,
        "exploratory_pilot_observations": sum(200 * p["repetitions"] for p in pilots),
        "confirmatory_results_inspected": False,
        "final_source_identity": {"command": "$env:PYTHONPATH='work\\source;outputs\\v4_freeze'; python outputs\\v4_freeze\\reconfirm_source.py . outputs\\v4_freeze\\FINAL_SOURCE_IDENTITY_V4.json",
                                  "exit_code": 0, "commit": source["commit"], "snapshot_files": source["snapshot_file_count"],
                                  "isolated_clean": source["isolated_live_clean"], "dirty_checkout_touched": False},
        "successful_runs": [
            {"name": "focused_project_suite", "command": "work/native_tools/py312/bin/python -m pytest work/source/tests/test_cm_pair_alignment.py work/source/tests/test_cm_optimizations.py work/source/tests/test_output_budget.py work/source/tests/test_bitset_backend.py work/source/tests/test_bitset_cse.py -q -p no:cacheprovider", "passed": 147, "failed": 0, "log": binding(workspace, vf / "FOCUSED_SUITE_V4.log")},
            {"name": "seventeen_boundary_categories", "command": "work/native_tools/py312/bin/python -m pytest outputs/gate_a_regressions.py -q -p no:cacheprovider", "passed": 95, "failed": 0, "category_count": 17, "log": binding(workspace, vf / "BOUNDARY_17_CATEGORIES_V4.log")},
            {"name": "v4_adversarial_suite", "command": "work/native_tools/py312/bin/python -m pytest outputs/v4_freeze/test_v4_freeze.py -q -p no:cacheprovider --basetemp=work/pytest_v4_wsl_final", "passed": 20, "failed": 0, "log": binding(workspace, vf / "V4_ADVERSARIAL_SUITE.log")},
            {"name": "finite_core", "command": "work/native_tools/py312/bin/python outputs/finite_core_check.py", "checks": 333794, "failures": 0, "log": binding(workspace, vf / "FINITE_CORE_V4.log")},
            {"name": "native_robdd", "command": "work/native_tools/py312/bin/python outputs/v4_freeze/native_robdd_qualify_v4.py outputs/v4_freeze --output outputs/v4_freeze/NATIVE_ROBDD_QUALIFICATION_V4.json", "oracle_equal": 1000, "failures": 0},
            {"name": "native_aig", "command": "work/native_tools/py312/bin/python outputs/v4_freeze/native_aig_qualify_v4.py <workspace> <natural-manifest> <output>", "oracle_equal": 142, "failures": 0},
            {"name": "primary_and_secondary_generation", "command": "work/native_tools/py312/bin/python outputs/v4_freeze/corpus_v4.py outputs/v4_freeze", "primary_cases": 100, "secondary_cells": 30, "secondary_cases": 900},
            {"name": "untimed_primary_qualification", "command": "work/native_tools/py312/bin/python outputs/v4_freeze/qualify_v4.py outputs/v4_freeze --output outputs/v4_freeze/PRIMARY_CORRECTNESS_V4.json", "primary_oracle_equal": 100, "failures": 0},
        ],
        "retained_setup_failures": [
            {"classification": "environment", "failure": "reconfirm_source initial launch lacked work/source on PYTHONPATH; rerun succeeded"},
            {"classification": "environment", "failure": "focused WSL suite initially lacked requests; repository-declared requests dependency was installed and rerun succeeded"},
            {"classification": "environment", "failure": "full requirements install could not build optional pyeda because Python.h was absent; focused scope did not import pyeda"},
            {"classification": "reporting_wrapper", "failure": "post-test shell status variables were expanded by the host shell; all four retained logs independently show success"},
            {"classification": "pilot_setup", "failure": "pilot 02 /tmp staging was cleared before launch; zero measurements"},
        ],
        "exploratory_pilots": binding(workspace, vf / "PILOT_CONTROL_SUMMARY_V4.json"),
        "recovered_audit_reference": {"assertions": 1083999, "counted_separately": True,
                                      "artifact": binding(workspace, workspace / "outputs" / "evidence" / "CM_Compiler_Deep_Audit_2026-09-22.md")},
    }
    write_json(vf / "VALIDATION_EXECUTION_RECORD_V4.json", record)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(); parser.add_argument("workspace")
    args = parser.parse_args(); build(Path(args.workspace).resolve())
