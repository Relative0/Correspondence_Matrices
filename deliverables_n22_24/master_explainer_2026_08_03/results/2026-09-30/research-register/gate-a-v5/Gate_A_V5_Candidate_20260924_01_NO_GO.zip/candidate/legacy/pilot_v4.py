"""Explicitly exploratory repeatability/timer-overhead pilot.

This program refuses to use a confirmatory run identifier. Its output is a
measurement-control qualification artifact, never confirmatory evidence.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

from v4_harness import canonical_json, sha256_file


def _timer_overhead_ns(draws:int=10000)->float:
    values=[]
    for _ in range(draws):
        a=time.perf_counter_ns();b=time.perf_counter_ns();values.append(b-a)
    return float(statistics.median(values))


def _worker(case:dict,arm:str,python:str,timeout:int)->dict:
    request={"case":case,"arm_id":arm,"record_kind":"time","collect_diagnostics":False}
    env=os.environ.copy();env.update({"PYTHONHASHSEED":"20260923","OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1"})
    completed=subprocess.run([python,str(Path(__file__).with_name("runner_v4.py")),"--worker"],
        input=canonical_json(request),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,env=env,check=False)
    if completed.returncode:raise RuntimeError(completed.stderr.decode("utf-8","replace")[:500])
    row=json.loads(completed.stdout)
    if row["disposition"]!="ok":raise RuntimeError(f"pilot arm failure: {row['disposition']} {row['error_message']}")
    return {"elapsed_ns":int(row["elapsed_total_ns"]),
            "affinity":row.get("worker_affinity"),"nice":row.get("worker_nice")}


def run(corpus_path:Path,output:Path,run_id:str,repetitions:int,python:str)->dict:
    if not run_id.startswith("pilot-") or "confirm" in run_id.lower():raise ValueError("exploratory run_id must start pilot- and cannot contain confirm")
    if repetitions<5:raise ValueError("at least five pilot repetitions required")
    corpus=json.loads(corpus_path.read_text(encoding="utf-8"));overhead=_timer_overhead_ns();rows=[];passed=True
    observed_affinity=None;observed_nice=None
    for case in corpus["cases"]:
        for arm in ("cm_pure","direct_packed"):
            observations=[_worker(case,arm,python,60) for _ in range(repetitions)]
            values=[item["elapsed_ns"] for item in observations]
            controls={(tuple(item["affinity"]) if item["affinity"] is not None else None,item["nice"]) for item in observations}
            if len(controls)!=1:raise RuntimeError(f"worker scheduling controls changed: {controls}")
            affinity,nice=next(iter(controls));affinity=list(affinity) if affinity is not None else None
            if observed_affinity is None:observed_affinity,observed_nice=affinity,nice
            if affinity!=observed_affinity or nice!=observed_nice:raise RuntimeError("cross-case scheduling controls changed")
            median=float(statistics.median(values));mad=float(statistics.median(abs(x-median) for x in values));ratio=mad/median
            control=ratio<=0.05 and overhead/median<=0.01;passed=passed and control
            rows.append({"case_id":case["case_id"],"arm_id":arm,"observations_ns":values,
                         "median_ns":median,"mad_ns":mad,"mad_over_median":ratio,
                         "timer_overhead_fraction":overhead/median,"control_pass":control})
    result={"schema":"cm_pair_exploratory_pilot_v4","run_id":run_id,"confirmatory":False,
            "corpus_sha256":sha256_file(corpus_path),"repetitions":repetitions,
            "timer_call_overhead_ns":overhead,"all_controls_pass":passed,"rows":rows}
    result["worker_affinity"]=observed_affinity;result["worker_nice"]=observed_nice
    output.write_bytes(canonical_json(result)+b"\n");return result


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("corpus");p.add_argument("output");p.add_argument("--run-id",required=True)
    p.add_argument("--repetitions",type=int,default=11);p.add_argument("--python",default=sys.executable);a=p.parse_args()
    result=run(Path(a.corpus),Path(a.output),a.run_id,a.repetitions,a.python)
    print(json.dumps({k:v for k,v in result.items() if k!="rows"},indent=2,sort_keys=True))
