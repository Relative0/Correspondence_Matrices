"""Generate schedule data only; no worker execution or population translation."""
from v5_common import *

def pilot_schedule(case_ids):
    ids = sorted(case_ids)
    rows = []
    for rep in range(PILOT_REPS):
        order = sorted(ids, key=lambda c: sha256_json([2026092405, rep, c]))
        for case in order:
            for member in range(MEMBERS):
                arms = ARMS if (rep + ids.index(case) + member) % 2 == 0 else ARMS[::-1]
                for arm in arms:
                    rows.append({'schedule_index': len(rows), 'case_id': case, 'arm_id': arm,
                                 'repetition_index': rep, 'member_index': member})
    return {'schema': 'v5_schedule', 'kind': 'pilot', 'members': MEMBERS, 'rows': rows}

def expand_schedule(old, kind):
    # Preserve every original outer block, case order, and arm order.
    if 'blocks' not in old and 'cells' not in old:
        raise ValueError('Unrecognized inherited schedule')
    return {'schema': 'v5_schedule_expansion', 'kind': kind, 'members': 9 if kind == 'time' else 1,
            'outer_schedule': old, 'member_order': 'ascending',
            'arm_order': 'original for even members; reversed for odd members',
            'execution_authorized': False}

def iter_expanded(schedule):
    index = 0
    outer = schedule['outer_schedule']
    blocks = outer['blocks'] if 'blocks' in outer else [b for c in outer['cells'] for b in c['blocks']]
    for block in blocks:
        # Secondary v4 schedules use explicit cell blocks; preserve metadata.
        for case in block['case_order']:
            for member in range(schedule['members']):
                arms = block['arm_order'][case]
                for arm in (arms if member % 2 == 0 else arms[::-1]):
                    yield {'schedule_index': index, 'case_id': case, 'arm_id': arm,
                           'repetition_index': block['repetition_index'], 'member_index': member}
                    index += 1

if __name__ == '__main__':
    write_json(ROOT / 'data' / 'PILOT_SCHEDULE_V5.json', pilot_schedule(load_corpus()))
    for scope in ('PRIMARY', 'SECONDARY'):
        for kind in ('TIME', 'MEMORY'):
            old = json.loads((ROOT / 'data' / f'{scope}_{kind}_SCHEDULE_V4.json').read_text())
            write_json(ROOT / 'data' / f'{scope}_{kind}_SCHEDULE_V5.json', expand_schedule(old, kind.lower()))
