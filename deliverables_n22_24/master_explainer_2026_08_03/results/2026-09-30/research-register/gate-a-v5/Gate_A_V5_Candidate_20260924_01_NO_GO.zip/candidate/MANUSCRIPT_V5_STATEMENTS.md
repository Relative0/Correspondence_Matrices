# Manuscript status

MANUSCRIPT_V5_WORKING_COPY.tex is a new working source; the v4 TEX/PDF and companion foundations paper are unchanged. MANUSCRIPT_V4_TO_V5.patch makes the prospective edits reviewable. The v5 working source replaces the primary timing unit, explains the 19,800-worker pilot and 54,000-worker future time schedule, retains 15 independent memory repetitions and the primary effect thresholds, adds the Runpod control failure, and keeps Gate A NO-GO. Historical v4 correctness/native qualification counts are explicitly retained history, not claims about a new host.

This task supplies manuscript source and statements, not a newly typeset PDF. PDF layout is therefore not newly qualified. A later publication build can typeset and inspect the successor source; it is not a prerequisite for executing an independently approved exploratory control pilot, but final manuscript/protocol agreement remains a Gate A criterion.
