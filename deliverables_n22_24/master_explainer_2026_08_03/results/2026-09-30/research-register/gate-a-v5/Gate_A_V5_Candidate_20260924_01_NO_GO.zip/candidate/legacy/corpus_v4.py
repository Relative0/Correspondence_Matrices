"""Deterministic Protocol v4 corpus and schedule construction.

Generation is prospective and does not call compiler arms or observe performance.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np

from cm_exprlib import And, Eqv, Expr, Imp, Not, Or, Var, Xor
from v4_harness import (
    canonical_json, deserialize_identity_dag, expression_stats, serialize_identity_dag,
    sha256_bytes, sha256_json, structural_prefix,
)


PRIMARY_SEED = 2026092301
TIME_SEED = 2026092302
MEMORY_SEED = 2026092303
OPS = (And, Or, Xor, Imp, Eqv)
OP_NAMES = {And: "AND", Or: "OR", Xor: "XOR", Imp: "IMP", Eqv: "EQV"}
ROOT_OPS = (And, Or, Xor, Imp, Eqv)
PRIMARY_CELL = "primary_B_1023_unshared_token_K1"


def _case_record(case_id: str, expr: Expr, *, rows: list[str], cols: list[str],
                 fixed: dict[str, int], artifact: str, reuse: int,
                 metadata: dict[str, Any]) -> dict[str, Any]:
    dag = serialize_identity_dag(expr)
    syntax = structural_prefix(expr)
    record = {
        "case_id": case_id,
        "identity_dag": dag,
        "identity_dag_sha256": sha256_json(dag),
        "structural_syntax_sha256": sha256_bytes(syntax.encode("ascii")),
        "row_layout": rows, "column_layout": cols, "fixed_bindings": fixed,
        "output_artifact": artifact, "reuse_count": reuse,
        **expression_stats(expr), **metadata,
    }
    record["case_sha256"] = sha256_json(record)
    return record


def generate_primary() -> dict[str, Any]:
    rng = np.random.Generator(np.random.PCG64(PRIMARY_SEED))
    cases: list[dict[str, Any]] = []
    syntax_seen: set[str] = set(); collisions: list[dict[str, Any]] = []
    case_index = 0
    while len(cases) < 100:
        primitive_ops = [OPS[int(rng.integers(0, len(OPS)))] for _ in range(240)]
        swaps = set(int(v) for v in rng.choice(240, size=120, replace=False))
        signed_positions = set(int(v) for v in rng.choice(480, size=64, replace=False))
        primitives: list[Expr] = []
        for pos, op in enumerate(primitive_ops):
            left: Expr = Var(0); right: Expr = Var(1)
            if 2 * pos in signed_positions: left = Not(left)
            if 2 * pos + 1 in signed_positions: right = Not(right)
            if pos in swaps: left, right = right, left
            primitives.append(op(left, right))
        root_op = ROOT_OPS[min(len(cases) // 20, 4)]
        def combine(items: list[Expr], *, root: bool = False) -> Expr:
            if len(items) == 1: return items[0]
            mid = len(items) // 2
            a = combine(items[:mid]); b = combine(items[mid:])
            op = root_op if root else OPS[int(rng.integers(0, len(OPS)))]
            return op(a, b)
        expr = combine(primitives, root=True)
        syntax = structural_prefix(expr)
        digest = sha256_bytes(syntax.encode("ascii"))
        if digest in syntax_seen:
            collisions.append({"candidate_index": case_index, "structural_syntax_sha256": digest})
            case_index += 1; continue
        syntax_seen.add(digest)
        rec = _case_record(
            f"P{len(cases):03d}", expr, rows=["x0"], cols=["x1"], fixed={},
            artifact="token", reuse=1,
            metadata={"cell_id": PRIMARY_CELL, "stratum": "B_signed_permuted",
                      "generator_seed": PRIMARY_SEED, "sharing_class": "unshared",
                      "root_operator": OP_NAMES[root_op], "primitive_count": 240,
                      "swapped_primitive_positions": 120, "signed_literal_positions": 64},
        )
        if rec["ast_occurrences"] != 1023 or rec["unique_object_nodes"] != 1023:
            raise AssertionError("primary N/U contract violated")
        if rec["ast_height"] > 11: raise AssertionError("primary height contract violated")
        cases.append(rec); case_index += 1
    manifest = {
        "schema": "cm_pair_primary_corpus_v4", "seed": PRIMARY_SEED,
        "numpy_version": np.__version__, "bit_generator": "PCG64",
        "cell_id": PRIMARY_CELL, "case_count": len(cases), "collisions": collisions,
        "generation_feedback_prohibited": ["pairability", "latency", "memory", "token_value"],
        "cases": cases,
    }
    manifest["manifest_sha256"] = sha256_json(manifest)
    return manifest


def _balanced(leaves: list[Expr], rng: np.random.Generator) -> Expr:
    if len(leaves) == 1: return leaves[0]
    mid = len(leaves) // 2
    return OPS[int(rng.integers(0, 5))](_balanced(leaves[:mid], rng), _balanced(leaves[mid:], rng))


def _skewed(leaves: list[Expr], rng: np.random.Generator) -> Expr:
    expr = leaves[0]
    for leaf in leaves[1:]: expr = OPS[int(rng.integers(0, 5))](expr, leaf)
    return expr


def _copy_unshared(expr: Expr) -> Expr:
    if isinstance(expr, Var): return Var(expr.i)
    if isinstance(expr, Not): return Not(_copy_unshared(expr.a))
    return type(expr)(_copy_unshared(expr.a), _copy_unshared(expr.b))


def _hash_cons(expr: Expr) -> Expr:
    memo: dict[str, Expr] = {}
    def rec(node: Expr) -> Expr:
        if isinstance(node, Var): candidate: Expr = Var(node.i)
        elif isinstance(node, Not): candidate = Not(rec(node.a))
        else: candidate = type(node)(rec(node.a), rec(node.b))
        key = structural_prefix(candidate)
        return memo.setdefault(key, candidate)
    return rec(expr)


@dataclass(frozen=True)
class SecondaryCell:
    cell_id: str; stratum: str; size: int; shape: str; artifact: str; reuse: int
    sharing: str = "unshared"; fixed_mode: str = "none"; axes: int = 2
    applicable_arms: tuple[str, ...] = (
        "cm_pure", "cm_hybrid", "cm_tabulate", "direct_packed",
        "prepared_cse", "generic_local", "robdd",
    )


# Exact finite list. It is deliberately a designed list, not an implicit cross-product.
SECONDARY_CELLS = (
    SecondaryCell("A_bal15_token_K1", "A_exact_positive", 15, "balanced", "token", 1),
    SecondaryCell("A_bal63_token_K10", "A_exact_positive", 63, "balanced", "token", 10),
    SecondaryCell("A_bal255_token_K100", "A_exact_positive", 255, "balanced", "token", 100),
    SecondaryCell("A_bal1023_token_K1000", "A_exact_positive", 1023, "balanced", "token", 1000),
    SecondaryCell("A_bal4095_token_K1", "A_exact_positive", 4095, "balanced", "token", 1),
    SecondaryCell("B_bal15_signed", "B_signed_permuted", 15, "balanced", "token", 1),
    SecondaryCell("B_bal63_signed", "B_signed_permuted", 63, "balanced", "token", 10),
    SecondaryCell("B_bal255_signed", "B_signed_permuted", 255, "balanced", "token", 100),
    SecondaryCell("B_bal1023_signed", "B_signed_permuted", 1023, "balanced", "token", 1000),
    SecondaryCell("B_bal4095_signed", "B_signed_permuted", 4095, "balanced", "token", 1),
    SecondaryCell("C_bal63_mixed", "C_mixed_tabulated_child", 63, "balanced", "token", 1),
    SecondaryCell("C_bal255_mixed", "C_mixed_tabulated_child", 255, "balanced", "token", 10),
    SecondaryCell("D_bal63_root", "D_root_tabulation", 63, "balanced", "token", 1),
    SecondaryCell("D_bal255_root", "D_root_tabulation", 255, "balanced", "token", 10),
    SecondaryCell("E_shared63_scalar", "E_multiple_pairs", 63, "balanced", "scalar", 100,
                  "identity_shared", fixed_mode="both_fixed", axes=0),
    SecondaryCell("E_distinct63_packed", "E_multiple_pairs", 63, "balanced", "packed", 100, "equal_distinct"),
    SecondaryCell("E_unshared255_packed", "E_multiple_pairs", 255, "balanced", "packed", 1000),
    SecondaryCell("F_skew15_dense", "F_compound_boundary", 15, "skewed", "dense", 1, axes=4),
    SecondaryCell("F_skew63_dense", "F_compound_boundary", 63, "skewed", "dense", 1, axes=8),
    SecondaryCell("F_skew255_dense", "F_compound_boundary", 255, "skewed", "dense", 1, axes=16),
    SecondaryCell("F_fixed_false", "F_compound_boundary", 63, "balanced", "dense", 1, fixed_mode="false", axes=3),
    SecondaryCell("F_fixed_true", "F_compound_boundary", 63, "balanced", "dense", 1, fixed_mode="true", axes=3),
    SecondaryCell("F_fixed_only", "F_compound_boundary", 15, "balanced", "scalar", 1, fixed_mode="fixed_only", axes=0),
    SecondaryCell("F_fixed_canonical", "F_compound_boundary", 63, "balanced", "dense", 1, fixed_mode="canonical", axes=2),
    SecondaryCell("F_syntactic_cancel", "F_compound_boundary", 63, "balanced", "dense", 1, fixed_mode="cancel", axes=3),
    SecondaryCell("F_multi_pair", "F_compound_boundary", 63, "balanced", "packed", 10, fixed_mode="multi_pair", axes=4),
    SecondaryCell("A_shared255_token", "A_exact_positive", 255, "balanced", "token", 1, "identity_shared"),
    SecondaryCell("A_distinct255_token", "A_exact_positive", 255, "balanced", "token", 1, "equal_distinct"),
    SecondaryCell("B_skew63_signed", "B_signed_permuted", 63, "skewed", "token", 1),
    SecondaryCell("B_skew255_signed", "B_signed_permuted", 255, "skewed", "token", 1),
)


def _secondary_expr(cell: SecondaryCell, case_index: int) -> tuple[Expr, list[str], list[str], dict[str, int]]:
    rng = np.random.Generator(np.random.PCG64(2026092400 + 1000 * list(SECONDARY_CELLS).index(cell) + case_index))
    unary = 2 if "signed" in cell.cell_id else 0
    base_size = cell.size - unary
    if base_size < 1 or base_size % 2 != 1: raise AssertionError("invalid exact-size plan")
    leaf_count = (base_size + 1) // 2
    leaves: list[Expr] = []
    for idx in range(leaf_count):
        if cell.stratum == "D_root_tabulation": var = 0 if idx < leaf_count // 2 else 1
        elif cell.stratum == "C_mixed_tabulated_child" and idx < 2: var = 0
        elif cell.fixed_mode in {"false", "true", "cancel"} and idx % 7 == 0: var = 2
        elif cell.fixed_mode == "fixed_only": var = 2
        elif cell.fixed_mode == "multi_pair": var = idx % 4
        else: var = idx % 2
        leaves.append(Var(var))
    if unary:
        leaves[0] = Not(leaves[0]); leaves[-1] = Not(leaves[-1])
    maker = _balanced if cell.shape == "balanced" else _skewed
    expr = maker(leaves, rng)
    # C begins with a same-axis x0/x0 child, which needs local retabulation once
    # combined with x1. D keeps the two top-level halves on different single
    # variables, so only whole-root retabulation can produce a pair. Both retain N.
    if cell.sharing == "identity_shared": expr = _hash_cons(expr)
    elif cell.sharing in {"equal_distinct", "unshared"}: expr = _copy_unshared(expr)
    if cell.fixed_mode == "fixed_only": rows: list[str] = []; cols: list[str] = []; fixed = {"x2": case_index & 1}
    elif cell.fixed_mode == "both_fixed":
        rows = []; cols = []; fixed = {"x0": case_index & 1, "x1": (case_index >> 1) & 1}
    elif cell.fixed_mode == "canonical": rows = ["x0"]; cols = ["x1"]; fixed = {"x0": case_index & 1}
    else:
        names = [f"x{i}" for i in range(cell.axes)]
        split = (len(names) + 1) // 2; rows = names[:split]; cols = names[split:]
        fixed = ({"x2": 0} if cell.fixed_mode == "false" else
                 {"x2": 1} if cell.fixed_mode == "true" else {})
    return expr, rows, cols, fixed


def generate_secondary_manifest() -> dict[str, Any]:
    cells: list[dict[str, Any]] = []
    all_case_hashes: list[str] = []
    for cell in SECONDARY_CELLS:
        cases: list[dict[str, Any]] = []; syntax: set[str] = set()
        for case_index in range(30):
            expr, rows, cols, fixed = _secondary_expr(cell, case_index)
            rec = _case_record(
                f"{cell.cell_id}:{case_index:02d}", expr, rows=rows, cols=cols, fixed=fixed,
                artifact=cell.artifact, reuse=cell.reuse,
                metadata={"cell_id": cell.cell_id, "stratum": cell.stratum,
                          "generator_seed": 2026092400 + 1000 * list(SECONDARY_CELLS).index(cell) + case_index,
                          "sharing_class": cell.sharing},
            )
            if rec["ast_occurrences"] != cell.size:
                raise AssertionError(f"secondary exact size violated for {cell.cell_id}")
            if rec["structural_syntax_sha256"] in syntax: raise AssertionError("secondary duplicate syntax")
            syntax.add(rec["structural_syntax_sha256"])
            cases.append({key: rec[key] for key in (
                "case_id", "case_sha256", "identity_dag_sha256", "structural_syntax_sha256",
                "ast_occurrences", "unique_object_nodes", "ast_height", "equal_distinct_subtree_count")})
            all_case_hashes.append(rec["case_sha256"])
        applicable = list(cell.applicable_arms)
        if cell.artifact == "dense":
            applicable.append("ordinary_cm")
        all_arms = {
            "cm_pure", "cm_hybrid", "cm_tabulate", "direct_packed",
            "prepared_cse", "ordinary_cm", "generic_local", "robdd", "abc_aig",
        }
        cells.append({**cell.__dict__, "applicable_arms": applicable,
                      "not_applicable_arms": sorted(all_arms - set(applicable)),
                      "case_count": 30, "time_repetitions": 30, "memory_repetitions": 15,
                      "cases": cases})
    manifest = {"schema": "cm_pair_secondary_cells_v4", "finite_cell_count": len(cells),
                "case_count": len(cells) * 30, "cells": cells,
                "all_case_hashes_sha256": sha256_json(all_case_hashes)}
    manifest["manifest_sha256"] = sha256_json(manifest)
    return manifest


def generate_primary_schedules(case_ids: list[str]) -> tuple[dict[str, Any], dict[str, Any]]:
    if len(case_ids) != 100 or len(set(case_ids)) != 100: raise ValueError("100 unique case IDs required")
    rng = np.random.Generator(np.random.PCG64(TIME_SEED))
    first_cm: dict[str, list[bool]] = {}
    for case_id in case_ids:
        pattern = np.array([True] * 15 + [False] * 15, dtype=bool); rng.shuffle(pattern)
        first_cm[case_id] = [bool(x) for x in pattern]
    blocks = []
    for rep in range(30):
        order = [case_ids[int(i)] for i in rng.permutation(100)]
        blocks.append({"repetition_index": rep, "case_order": order,
                       "arm_order": {cid: (["cm_pure", "direct_packed"] if first_cm[cid][rep]
                                           else ["direct_packed", "cm_pure"]) for cid in order}})
    time_manifest = {"schema": "cm_pair_primary_time_schedule_v4", "seed": TIME_SEED,
                     "bit_generator": "PCG64", "blocks": blocks}
    time_manifest["schedule_sha256"] = sha256_json(time_manifest)
    rng = np.random.Generator(np.random.PCG64(MEMORY_SEED))
    case_bias = set(case_ids[int(i)] for i in rng.choice(100, size=50, replace=False))
    memory_blocks = []
    for rep in range(15):
        order = [case_ids[int(i)] for i in rng.permutation(100)]
        arm_order = {}
        for cid in order:
            cm_first = (rep < 8) if cid in case_bias else (rep >= 8)
            arm_order[cid] = ["cm_pure", "direct_packed"] if cm_first else ["direct_packed", "cm_pure"]
        memory_blocks.append({"repetition_index": rep, "case_order": order, "arm_order": arm_order})
    memory_manifest = {"schema": "cm_pair_primary_memory_schedule_v4", "seed": MEMORY_SEED,
                       "bit_generator": "PCG64", "blocks": memory_blocks}
    memory_manifest["schedule_sha256"] = sha256_json(memory_manifest)
    return time_manifest, memory_manifest


def validate_primary_manifest(manifest: dict[str, Any]) -> None:
    cases = manifest["cases"]
    if len(cases) != 100 or len({c["case_id"] for c in cases}) != 100: raise ValueError("primary count/IDs")
    if len({c["structural_syntax_sha256"] for c in cases}) != 100: raise ValueError("primary duplicate syntax")
    for case in cases:
        if case["cell_id"] != PRIMARY_CELL or case["ast_occurrences"] != 1023 or case["unique_object_nodes"] != 1023:
            raise ValueError("primary shape contract")
        if case["ast_height"] > 11 or case["fixed_bindings"] or case["output_artifact"] != "token" or case["reuse_count"] != 1:
            raise ValueError("primary endpoint contract")
        if sha256_json(case["identity_dag"]) != case["identity_dag_sha256"]: raise ValueError("case DAG hash")


def validate_schedules(time_manifest: dict[str, Any], memory_manifest: dict[str, Any], case_ids: list[str]) -> None:
    for schedule, reps in ((time_manifest, 30), (memory_manifest, 15)):
        if len(schedule["blocks"]) != reps: raise ValueError("wrong schedule repetition count")
        for rep, block in enumerate(schedule["blocks"]):
            if block["repetition_index"] != rep or set(block["case_order"]) != set(case_ids):
                raise ValueError("invalid case schedule")
            for cid in case_ids:
                if sorted(block["arm_order"][cid]) != ["cm_pure", "direct_packed"]: raise ValueError("invalid arm order")
    for cid in case_ids:
        count = sum(block["arm_order"][cid][0] == "cm_pure" for block in time_manifest["blocks"])
        if count != 15: raise ValueError("time schedule not exactly counterbalanced")
    memory_first = sum(block["arm_order"][cid][0] == "cm_pure" for block in memory_manifest["blocks"] for cid in case_ids)
    if memory_first != 750: raise ValueError("memory schedule not globally counterbalanced")


def generate_secondary_schedules(secondary: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    def make(seed: int, repetitions: int, schema: str) -> dict[str, Any]:
        rng=np.random.Generator(np.random.PCG64(seed));cells=[]
        for cell in secondary["cells"]:
            case_ids=[case["case_id"] for case in cell["cases"]]
            arms=list(cell["applicable_arms"]);offset=int(rng.integers(0,len(arms)));blocks=[]
            starts=np.array([(offset+slot)%len(arms) for slot in range(repetitions*len(case_ids))],dtype=np.int64)
            rng.shuffle(starts);slot=0
            for rep in range(repetitions):
                order=[case_ids[int(i)] for i in rng.permutation(len(case_ids))]
                arm_order={}
                for case_id in order:
                    start=int(starts[slot]);slot+=1
                    arm_order[case_id]=arms[start:]+arms[:start]
                blocks.append({"repetition_index":rep,"case_order":order,"arm_order":arm_order})
            first_counts={arm:sum(block["arm_order"][cid][0]==arm for block in blocks for cid in case_ids) for arm in arms}
            cells.append({"cell_id":cell["cell_id"],"arms":arms,"blocks":blocks,"first_arm_counts":first_counts})
        result={"schema":schema,"seed":seed,"bit_generator":"PCG64","cells":cells}
        result["schedule_sha256"]=sha256_json(result);return result
    return (make(TIME_SEED,30,"cm_pair_secondary_time_schedule_v4"),
            make(MEMORY_SEED,15,"cm_pair_secondary_memory_schedule_v4"))


def validate_secondary_schedules(time_manifest:dict[str,Any],memory_manifest:dict[str,Any],secondary:dict[str,Any])->None:
    by_id={cell["cell_id"]:cell for cell in secondary["cells"]}
    for schedule,reps in ((time_manifest,30),(memory_manifest,15)):
        if set(cell["cell_id"] for cell in schedule["cells"])!=set(by_id):raise ValueError("secondary cell schedule mismatch")
        for scheduled in schedule["cells"]:
            source=by_id[scheduled["cell_id"]];ids=[case["case_id"] for case in source["cases"]];arms=source["applicable_arms"]
            if len(scheduled["blocks"])!=reps:raise ValueError("secondary repetition count")
            for rep,block in enumerate(scheduled["blocks"]):
                if block["repetition_index"]!=rep or set(block["case_order"])!=set(ids):raise ValueError("secondary case order")
                if any(sorted(block["arm_order"][cid])!=sorted(arms) for cid in ids):raise ValueError("secondary arm order")
            counts=list(scheduled["first_arm_counts"].values())
            if sum(counts)!=reps*len(ids) or max(counts)-min(counts)>1:raise ValueError("secondary arm balance")


def write_artifacts(directory: str | Path) -> dict[str, str]:
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    primary = generate_primary(); validate_primary_manifest(primary)
    secondary = generate_secondary_manifest()
    case_ids = [case["case_id"] for case in primary["cases"]]
    time_schedule, memory_schedule = generate_primary_schedules(case_ids)
    validate_schedules(time_schedule, memory_schedule, case_ids)
    secondary_time,secondary_memory=generate_secondary_schedules(secondary)
    validate_secondary_schedules(secondary_time,secondary_memory,secondary)
    values = {"PRIMARY_CORPUS_V4.json": primary, "SECONDARY_CELLS_V4.json": secondary,
              "PRIMARY_TIME_SCHEDULE_V4.json": time_schedule,
              "PRIMARY_MEMORY_SCHEDULE_V4.json": memory_schedule,
              "SECONDARY_TIME_SCHEDULE_V4.json":secondary_time,
              "SECONDARY_MEMORY_SCHEDULE_V4.json":secondary_memory}
    hashes = {}
    for name, value in values.items():
        path = directory / name; path.write_bytes(canonical_json(value) + b"\n")
        hashes[name] = sha256_bytes(path.read_bytes())
    return hashes


if __name__ == "__main__":
    import sys
    print(json.dumps(write_artifacts(sys.argv[1]), indent=2, sort_keys=True))
