"""Untimed Gate A contract regressions. Set PYTHONPATH to audited source."""
from itertools import product
import numpy as np
import pytest
import cm_build_pair as pair
from cm_exprlib import Var, Not, And, Or, Xor, Imp, Eqv
from bitset_backend import build_bitset_env, eval_expr_bitset, bitset_to_bool_array
from cm_token import cm_token_value
from cmbench.output_budget import OutputBudget, OutputBudgetExceeded

OPS=(And,Or,Xor,Imp,Eqv)
R,C,Z=Var(0),Var(1),Var(2)
ROWS=['x0']; COLS=['x1']

def scalar(e, env, fixed):
    if isinstance(e,Var): return int(bool(fixed.get(f'x{e.i}',env.get(f'x{e.i}'))))
    if isinstance(e,Not): return 1-scalar(e.a,env,fixed)
    a,b=scalar(e.a,env,fixed),scalar(e.b,env,fixed)
    return {And:lambda:a&b,Or:lambda:a|b,Xor:lambda:a^b,Imp:lambda:(1-a)|b,Eqv:lambda:1-(a^b)}[type(e)]()

def oracle_dense(e,rows,cols,fixed):
    names=rows+cols
    return np.array([scalar(e,dict(zip(names,vs)),fixed) for vs in product((0,1),repeat=len(names))],dtype=bool).reshape(1<<len(rows),1<<len(cols))

def direct_ambient(e,rows,cols,fixed):
    # Explicit adapter: ambient axes remain; fixed values override their masks.
    env=dict(build_bitset_env(rows+cols)); full=(1<<(1<<len(env)))-1
    for name in env:
        if name in fixed: env[name]=full if bool(fixed[name]) else 0
    bits=eval_expr_bitset(e,env,fixed=fixed)
    return bitset_to_bool_array(bits,len(env)).astype(bool).reshape(1<<len(rows),1<<len(cols)).copy()

def token(e,strategy='hybrid',fixed=None,rows=None,cols=None):
    return pair.compile_expr_to_cm_pair_token(e,ROWS if rows is None else rows,COLS if cols is None else cols, fixed or {},strategy=strategy)

def T(): return Xor(And(Var(0),Var(1)),Var(0))
def S(): return Imp(Var(0),Var(1))
def H(): return Not(T())

@pytest.mark.parametrize('rows,cols', [(['x0'],['x0']),(['x0','x0'],['x1']),(['x0'],['x1','x1'])])
@pytest.mark.parametrize('dense',[False,True])
def test_invalid_layouts_raise(rows,cols,dense):
    with pytest.raises(ValueError):
        if dense: pair.compile_expr_to_cm_pair(And(R,C),rows,cols,{})
        else: token(And(R,C),rows=rows,cols=cols)

def test_syntactic_cancellation_is_not_essential_support():
    p,m=token(Xor(Xor(R,R),C)); assert p.token==10 and m['root_outcome']=='full_retabulation'
    p,m=token(Xor(And(R,C),Xor(Z,Z)),rows=['x0','x2']); assert p is None
    assert m['primitive_pair_tokens']==1 and m['root_outcome']=='ordinary_fallback'

@pytest.mark.parametrize('strategy',['pure_structural','hybrid','retabulate'])
@pytest.mark.parametrize('e,fixed',[(And(R,C),{'x2':1}),(And(And(R,C),Z),{'x2':0}),(And(And(R,C),Z),{'x2':1}),(Xor(Z,Z),{'x2':1}),(And(R,C),{'x0':1}),(And(R,C),{'x1':0}),(And(R,C),{'x0':1,'x1':1}),(Or(And(R,C),Z),{'x2':1})])
def test_fixed_and_ambient_axes(e,fixed,strategy):
    rows=['x0','x2'];cols=['x1']; expected=oracle_dense(e,rows,cols,fixed)
    dense,metrics=pair.compile_expr_to_cm_pair(e,rows,cols,fixed,pair_strategy=strategy)
    assert dense.shape==(4,2) and dense.nbytes==8
    assert dense.flags.owndata and dense.flags.writeable
    assert np.array_equal(dense,expected)
    assert np.array_equal(direct_ambient(e,rows,cols,fixed),expected)

def test_raw_packed_overlap_counterexample_requires_adapter():
    e=And(R,C);fixed={'x0':1};env=build_bitset_env(['x0','x1'])
    raw=eval_expr_bitset(e,env,fixed=fixed)
    assert raw==8 # env takes precedence, unlike fixed-first dense CM.
    assert not np.array_equal(bitset_to_bool_array(raw,2).reshape(2,2),oracle_dense(e,ROWS,COLS,fixed))
    assert np.array_equal(direct_ambient(e,ROWS,COLS,fixed),oracle_dense(e,ROWS,COLS,fixed))

@pytest.mark.parametrize('strategy',['pure_structural','hybrid','retabulate'])
def test_fixed_only_and_canonical_fixed_no_pair(strategy):
    for e,f in [(Z,{'x2':1}),(Xor(Z,Z),{'x2':0}),(And(R,C),{'x0':1}),(And(R,C),{'x1':0})]:
        p,m=token(e,strategy,f);assert p is None and m['root_outcome']=='ordinary_fallback'
    m,_=pair.compile_expr_to_cm_pair(Z,[],[],{'x2':1},pair_strategy=strategy)
    assert m.shape==(1,1) and m.nbytes==1 and bool(m[0,0])

def test_token_signals_fallback_and_discards_successful_child(monkeypatch):
    e=Or(And(R,C),Z)
    def forbidden(*a,**k):raise AssertionError('Token API executed ordinary compiler')
    monkeypatch.setattr(pair,'compile_expr_to_cm',forbidden)
    p,m=token(e,rows=['x0','x2']); assert p is None
    assert m['primitive_pair_tokens']==1 and m['pair_collapses']==1
    assert m['compiler_calls']==3 and m['root_outcome']=='ordinary_fallback'

def test_dense_executes_original_root_once(monkeypatch):
    e=Or(And(R,C),Z);seen=[]; original=pair.compile_expr_to_cm
    def traced(expr,*a,**k):seen.append(expr);return original(expr,*a,**k)
    monkeypatch.setattr(pair,'compile_expr_to_cm',traced)
    m,stats=pair.compile_expr_to_cm_pair(e,['x0','x2'],COLS,{})
    assert len(seen)==1 and seen[0] is e
    assert stats['primitive_pair_tokens']==1 and stats['root_outcome']=='ordinary_fallback'
    assert np.array_equal(m,oracle_dense(e,['x0','x2'],COLS,{}))

@pytest.mark.parametrize('make,outcome',[(S,'pure_structural'),(T,'full_retabulation'),(H,'hybrid_pair')])
def test_requested_hybrid_separate_from_observed(make,outcome):
    p,m=token(make(),'hybrid'); assert p is not None and m['root_outcome']==outcome
    for r,c in product((0,1),repeat=2):assert cm_token_value(p.token,r,c)==scalar(make(),{'x0':r,'x1':c},{})

@pytest.mark.parametrize('left,right',list(product((S,T,H),repeat=2)))
@pytest.mark.parametrize('op',OPS)
def test_all_nine_provenance_fusions(left,right,op):
    e=op(left(),right());p,m=token(e)
    assert m['root_outcome']==('pure_structural' if left is S and right is S else 'hybrid_pair')
    for r,c in product((0,1),repeat=2):assert cm_token_value(p.token,r,c)==scalar(e,{'x0':r,'x1':c},{})

@pytest.mark.parametrize('make,outcome',[(S,'pure_structural'),(T,'hybrid_pair'),(H,'hybrid_pair')])
def test_negation_provenance(make,outcome):
    p,m=token(Not(make()));assert m['root_outcome']==outcome

def test_pure_never_calls_tabulation(monkeypatch):
    def forbidden(*a,**kw):raise AssertionError('pure retabulation')
    monkeypatch.setattr(pair,'_token_from_expr_two_vars',forbidden)
    for e in [S(),T(),H(),Or(S(),T()),Or(S(),S())]:
        _,m=token(e,'pure_structural');assert m['direct_pair_retabulations']==0

def test_all_tokens_true_first_to_dense_owned():
    for t in range(16):
        m=pair._token_to_matrix(t)
        for r,c in product((0,1),repeat=2):assert m[r,c]==((t>>(2*r+c))&1)
        assert m.flags.owndata and m.flags.writeable

def test_public_dense_ownership_independent_calls():
    a,_=pair.compile_expr_to_cm_pair(And(R,C),ROWS,COLS,{})
    b,_=pair.compile_expr_to_cm_pair(And(R,C),ROWS,COLS,{})
    assert a.flags.owndata and a.flags.writeable and not np.shares_memory(a,b)
    a[:]=False;assert b[1,1]

def test_identity_dag_versus_equal_distinct_instrumentation():
    s=S();shared=Or(s,s);distinct=Or(S(),S())
    _,a=token(shared,'pure_structural');_,b=token(distinct,'pure_structural')
    assert a['ast_occurrences']==b['ast_occurrences']==7
    assert a['unique_object_nodes']==4 and b['unique_object_nodes']==7
    assert a['compiler_calls']==b['compiler_calls']==3
    assert a['nodes_total']==b['nodes_total']==3 # audited live meaning, unlike local dirty copy
    assert a['primitive_pair_tokens']==b['primitive_pair_tokens']==2

def test_budget_uses_ambient_axes_before_pair_attempt(monkeypatch):
    def forbidden(*a,**kw):raise AssertionError('pair attempted before budget refusal')
    monkeypatch.setattr(pair,'compile_expr_to_cm_pair_token',forbidden)
    with pytest.raises(OutputBudgetExceeded):
        pair.compile_expr_to_cm_pair(And(R,C),['x0','x2'],COLS,{'x2':1},output_budget=OutputBudget(max_output_bytes=7))

def test_fixed_extra_semantic_constant_still_tabulated():
    p,m=token(Or(And(R,C),Z),fixed={'x2':1})
    assert p.token==15 and m['root_outcome']=='full_retabulation'

def test_same_token_same_query_endpoint():
    p,_=token(S());b=eval_expr_bitset(S(),build_bitset_env(ROWS+COLS))
    assert p.token==b
    assert [cm_token_value(p.token,r,c) for r,c in product((0,1),repeat=2)]==[cm_token_value(b,r,c) for r,c in product((0,1),repeat=2)]
