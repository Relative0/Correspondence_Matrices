# Gate A successor task: design Protocol v5 timing stability prospectively

Continue from the completed Gate A v4 NO-GO package and the retained Runpod pilot `pilot-v4-runpod-20260924-03`. Do not alter or clean `C:\Users\brian\Documents\CM_Computation`. Work from the audited package/snapshot and a new task directory.

Do not run or inspect any confirmatory result. Do not run a new performance pilot in the same task. Do not execute the primary 30-repetition schedule, 15-repetition memory schedule, secondary schedules, natural-corpus pairability, or the pair compiler on the natural population. Do not use relative arm speed, favorable cases, or formula outcomes to choose the repair.

## Controlling evidence

- Gate A package: `Gate_A_V4_NO_GO_Qualification_Package.zip`, SHA-256 `93c556a4c15099c260919287e95809079bf8d5ff21b8117e4155fd0482a7306a`.
- Qualified production commit: `0ab8ffd0c23ffa71ee951d375b1c170ffdcc084b`.
- Frozen primary corpus SHA-256: `aa0cb2f1f4f665ee77ae0fa881a755eb1baa27971d870eec9e5680dc1049112b`.
- Frozen v4 pilot/harness/runner SHA-256 values remain `22a1d96f9813330113335568cf4bf6d88c842ec5f3458bef5614e69f7e1529c6`, `8b5478d03df58d2a9e5928bd99f7709a9f6f0edde12e2614b0de12c1f74ee041`, and `e44a7312c106055a2983114b5ad645d45293d93728171ce694e231363a2b7e6a`.
- Runpod evidence directory: `outputs/pilot-v4-runpod-20260924-03`.
- Permitted Runpod control summary: 194/200 passed; 6 failed; `cm_pure` 96/100 with maximum MAD/median 0.23801345992583745; `direct_packed` 98/100 with maximum 0.2105232640339576; zero timer-overhead failures; CPU affinity `[0]`; nice `0`.
- The A40 container was correctly staged, its 68-entry deliverable manifest and 187-file source closure passed, and the untimed smoke/oracle check passed. The host nevertheless had unknown CPU dedication, exposed 96 logical CPUs against an advertised 9 vCPUs, used `schedutil`, and began with load 10.27/14.37/17.28.
- Prior complete exploratory v4 pilots also failed the unchanged all-200 rule: WSL identities failed 17, 56, 14, and 20 controls respectively. Preserve all identities and hashes separately.

## Required work

1. Draft numbered **Protocol v5** before collecting any new timing data. Explain why repeated single-call observations under the unchanged v4 policy have not met the all-200 repeatability rule across materially different environments and why another opportunistic host search would risk environment fishing.
2. Define a robust per-observation estimand that reduces timer/scheduler sensitivity without becoming a warm-cache inner-loop benchmark. Each observation must remain an independent fresh process; arm-specific preparation must remain charged; inputs must be reconstructed independently; workload caches must be reset independently; correctness/oracle equality must remain mandatory; and both arms must receive symmetric treatment.
3. Prospectively specify the aggregation unit, repetition structure, warm-up policy if any, cache policy, timer and overhead control, stability statistic, thresholds, invalid-observation handling, affinity/priority requirements, environment binding, and the exact rule for a full pass. Do not tune these choices against favorable arm results.
4. Update the measurement schema, pilot runner/harness, analyzer, schedules, protocol/manuscript statements, contract matrix, and adversarial tests as required. Preserve a migration record from v4 and do not overwrite v4 artifacts.
5. Prove the new implementation through untimed correctness, schema, cache-reset, fresh-process, arm-symmetry, overhead-accounting, and adversarial tests. Reconfirm the audited source identity and clean closure. Performance measurements are out of scope for this design task.
6. Build an immutable v5 candidate package with a new candidate/freeze identity and empty append-only result files. Issue a review report stating exactly what remains unqualified.
7. Only in a later, separately authorized task, run exactly one exploratory `pilot-v5-*` identity on a prospectively selected controlled host. A pass must satisfy the frozen v5 rule for every required case/arm control. A failure remains NO-GO and must not be repaired retrospectively.

Do not claim Gate A GO merely because the v5 design or tests pass. Gate A remains NO-GO until the frozen v5 exploratory stability gate and every other required Gate A criterion pass. Do not supply or execute a Frozen Execution Prompt before that point.
