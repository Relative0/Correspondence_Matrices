"""V5 aggregation with exact coverage; never compare arm speeds in pilot mode."""
from v5_common import *
import statistics
from fractions import Fraction
from schema_v5 import validate_row

def validate_dataset(rows, schedule, bindings, oracle_map, state, *, kind='time', cases=None):
    if len(rows) != len(schedule): raise ValueError('Missing/additional elementary observations')
    previous = ZERO; nonces = set(); groups = {}
    cases = cases or load_corpus()
    for row, expected in zip(rows, schedule):
        validate_row(row, previous=previous, expected=expected, bindings=bindings,
                     oracle=oracle_map[expected['case_id']], state=state, kind=kind)
        if row['case_sha256'] != cases[row['case_id']]['case_sha256']:
            raise ValueError('Case hash mismatch')
        if row['disposition'] != 'ok': raise ValueError('Failed elementary observation')
        nonce = row['worker']['worker_nonce']
        if nonce in nonces: raise ValueError('Reused elementary worker identity')
        nonces.add(nonce); previous = row['row_sha256']
        key = (row['case_id'], row['arm_id'], row['repetition_index'])
        groups.setdefault(key, []).append(row['worker']['elapsed_ns' if kind == 'time' else 'peak_memory_bytes'])
    required = MEMBERS if kind == 'time' else 1
    if any(len(v) != required for v in groups.values()): raise ValueError('Incomplete aggregation unit')
    return {k: statistics.median(v) for k,v in groups.items()}

def control(values):
    if len(values) != PILOT_REPS or any(not integer(v, 1) for v in values):
        raise ValueError('Expected 11 positive median-of-nine values')
    med = statistics.median(values)
    mad = statistics.median(abs(v-med) for v in values)
    # Exact threshold equality; no floating rounding at 0.05.
    return {'mad_over_median': float(Fraction(mad, med)), 'pass': 20*mad <= med}

def analyze_pilot(rows, schedule, bindings, oracle_map, state):
    result = {'schema': 'v5_pilot_review', 'gate_a': 'NO-GO', 'confirmatory': False,
              'all_controls_pass': False, 'required_controls': 200, 'controls': []}
    try:
        if len(schedule) != 19800: raise ValueError('Incomplete frozen pilot schedule')
        from schedules_v5 import pilot_schedule
        if schedule != pilot_schedule(load_corpus())['rows']:
            raise ValueError('Pilot schedule differs from prospective schedule')
        groups = validate_dataset(rows, schedule, bindings, oracle_map, state)
        for case in sorted(load_corpus()):
            for arm in ARMS:
                c = control([groups[(case,arm,r)] for r in range(PILOT_REPS)])
                result['controls'].append({'case_id': case, 'arm_id': arm, **c})
        result['all_controls_pass'] = all(c['pass'] for c in result['controls'])
        result['controls_passed'] = sum(c['pass'] for c in result['controls'])
        result['controls_failed'] = 200-result['controls_passed']
        result['decision'] = 'exploratory_stability_pass_only' if result['all_controls_pass'] else 'NO-GO'
    except (ValueError, KeyError, TypeError) as exc:
        result.update({'decision': 'NO-GO', 'error': str(exc)})
    return result

def estimate_synthetic_or_authorized(d,c,mc,md,*,draws=20000):
    """Pure estimator. Tests supply synthetic arrays only; no file loading here."""
    import numpy as np
    d,c,mc,md = map(lambda x: np.asarray(x,dtype=np.float64), (d,c,mc,md))
    if d.shape != (100,30) or c.shape != d.shape or mc.shape != (100,15) or md.shape != mc.shape:
        raise ValueError('Primary shape')
    if any(np.any(~np.isfinite(x)) or np.any(x<=0) for x in (d,c,mc,md)):
        raise ValueError('Invalid measurements')
    ri=np.median(d,axis=1)/np.median(c,axis=1); mi=np.median(mc,axis=1)/np.median(md,axis=1)
    rng=np.random.Generator(np.random.PCG64(2026092304)); boot=np.empty(draws)
    for b in range(draws):
        case=rng.integers(0,100,size=100); rep=rng.integers(0,30,size=(100,30))
        boot[b]=np.median(np.median(d[case[:,None],rep],axis=1)/np.median(c[case[:,None],rep],axis=1))
    lo,hi=np.quantile(boot,[.025,.975],method='linear'); r=float(np.median(ri)); m=float(np.median(mi))
    return {'ratio':r,'ci95':[float(lo),float(hi)],'memory_ratio':m,'per_case_ratios':ri.tolist(),
            'per_case_memory_ratios':mi.tolist(),'utility_pass':bool(r>=1.20 and lo>1.00 and m<=1.10),
            'bootstrap_draws':draws,'seed':2026092304,'unit':'median_of_nine_fresh_process_calls'}

def analyze_primary(time_rows, memory_rows, time_schedule, memory_schedule, bindings, oracle_map, state, freeze):
    # Candidate never meets this gate. A reviewed successor execution freeze is required.
    if freeze.get('status') != 'FROZEN' or freeze.get('gate_a') != 'GO' or freeze.get('authorization_to_execute') is not True:
        raise ValueError('Candidate NO-GO; confirmation not authorized')
    for k,v in bindings.items():
        if freeze.get('row_bindings',{}).get(k) != v: raise ValueError('Confirmation freeze binding')
    if freeze.get('memory_metric') != 'ru_maxrss': raise ValueError('Memory environment')
    from schedules_v5 import iter_expanded
    for kind, supplied in [('TIME',time_schedule),('MEMORY',memory_schedule)]:
        path=ROOT/'data'/f'PRIMARY_{kind}_SCHEDULE_V5.json'
        key='schedule_sha256' if kind=='TIME' else 'memory_schedule_sha256'
        expected_hash=bindings[key] if kind=='TIME' else freeze[key]
        if sha256_file(path)!=expected_hash or supplied!=list(iter_expanded(json.loads(path.read_text()))):
            raise ValueError('Confirmation schedule differs from candidate')
    tg=validate_dataset(time_rows,time_schedule,bindings,oracle_map,state)
    memory_bindings=dict(bindings);memory_bindings['schedule_sha256']=freeze['memory_schedule_sha256']
    mg=validate_dataset(memory_rows,memory_schedule,memory_bindings,oracle_map,state,kind='memory')
    ids=sorted(load_corpus())
    def array(groups, arm, count):
        return [[groups[(case,arm,r)] for r in range(count)] for case in ids]
    if len(tg)!=6000 or len(mg)!=3000: raise ValueError('Primary completeness')
    return estimate_synthetic_or_authorized(array(tg,ARMS[1],30),array(tg,ARMS[0],30),
                                            array(mg,ARMS[0],15),array(mg,ARMS[1],15))
