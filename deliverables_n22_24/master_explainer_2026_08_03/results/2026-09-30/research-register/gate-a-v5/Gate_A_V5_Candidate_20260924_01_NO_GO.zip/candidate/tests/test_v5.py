"""Synthetic timing only. Real API calls here are strictly untimed."""
import copy
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from v5_common import *
import pytest
import harness_v5 as h
from schema_v5 import validate_worker, validate_row, seal_row, Ledger
from schedules_v5 import pilot_schedule, iter_expanded
from analyzer_v5 import control, validate_dataset, analyze_pilot, analyze_primary, estimate_synthetic_or_authorized
from pilot_v5 import validate_binding

def forbidden():
    raise AssertionError('Performance clock forbidden in design qualification')

@pytest.fixture
def one():
    return next(iter(load_corpus().values()))

def fake_worker(arm='cm_pure', nonce=1):
    _, reset=h.adapter.reset_workload_caches()
    return {'worker_nonce':f'{nonce:032x}','pid':1234,'parent_pid':123,'mode':'time',
        'elapsed_ns':10000,'overhead_ns':100,'overhead_max_ns':200,'timer_resolution_ns':1,
        'peak_memory_bytes':None,'memory_metric':None,'cache_reset':reset,'cache_after':{},
        'correctness_digest':'a'*64,'oracle_digest':'a'*64,'direct_digest':'a'*64,
        'root_outcome':'pure_structural' if arm=='cm_pure' else None,
        'state_before':{'affinity':[0],'nice':0},'state_after':{'affinity':[0],'nice':0},
        'api_calls':1,'input_reconstructions':3,'preparation_included':True,'gc_enabled':True,'fresh_process':True}

def binding_fields():
    return {'run_id':'pilot-v5-SYNTHETIC','candidate_manifest_sha256':'b'*64,
            'environment_sha256':'c'*64,'corpus_sha256':CORPUS_HASH,'schedule_sha256':'d'*64,
            'oracle_manifest_sha256':'e'*64}

def synthetic_rows(schedule):
    cases=load_corpus(); previous=ZERO; rows=[]
    for slot in schedule:
        w=fake_worker(slot['arm_id'],slot['schedule_index']+1)
        # Four very large disruptions per group, same pattern in both arms.
        w['elapsed_ns']=1000000 if slot['member_index']<4 else 10000
        row=seal_row({'schema':'cm_pair_v5_elementary','candidate_id':CANDIDATE,**binding_fields(),**slot,
                      'case_sha256':cases[slot['case_id']]['case_sha256'],
                      'disposition':'ok','error':None,'worker':w},previous)
        rows.append(row);previous=row['row_sha256']
    return rows

def test_source_and_corpus_exact():
    assert verify_source()==187
    assert len(load_corpus())==100
    for name, expected in [('v4_harness.py','8b5478d03df58d2a9e5928bd99f7709a9f6f0edde12e2614b0de12c1f74ee041')]:
        assert sha256_file(ROOT/'legacy'/name)==expected

def test_primary_all_cases_untimed(monkeypatch):
    monkeypatch.setattr(h.time,'perf_counter_ns',forbidden)
    oracle=json.loads((ROOT/'data/ORACLE_V5.json').read_text())
    for case in load_corpus().values():
        for arm in ARMS:
            result=h.observe(case,arm,expected_digest=oracle[case['case_id']])
            validate_worker(result,kind='correctness',arm=arm,expected_oracle=oracle[case['case_id']])
            assert result['elapsed_ns'] is None

def test_fresh_subprocesses(one):
    from runner_v5 import launch
    results=[launch({'case_id':one['case_id'],'arm_id':arm,'mode':'correctness'}) for arm in ARMS for _ in range(2)]
    assert len({r['worker_nonce'] for r in results})==4
    assert all(r['pid']!=os.getpid() and r['parent_pid']==os.getpid() and r['elapsed_ns'] is None for r in results)
    assert len({r['correctness_digest'] for r in results})==1

def test_clock_boundary_and_symmetric_preparation(monkeypatch,one):
    for arm in ARMS:
        calls=[]; now=[0]; run=h.adapter.run_arm; stage=h.adapter.stage_case
        def tick():
            calls.append('clock');now[0]+=1;return now[0]
        def wrapped(*args,**kwargs):
            calls.append('arm');now[0]+=10000;return run(*args,**kwargs)
        def staging(*args,**kwargs):
            calls.append('stage');return stage(*args,**kwargs)
        with monkeypatch.context() as m:
            m.setattr(h.time,'perf_counter_ns',forbidden)
            m.setattr(h.adapter,'run_arm',wrapped);m.setattr(h.adapter,'stage_case',staging)
            result=h.observe(one,arm,mode='time',clock=tick)
        idx=calls.index('arm')
        assert calls[idx-1:idx+2]==['clock','arm','clock']
        assert calls.count('arm')==1 and calls.count('stage')==3
        assert result['elapsed_ns']==10001 and result['overhead_ns']==1
        validate_worker(result,kind='time',arm=arm)

def test_no_clock_in_memory(monkeypatch,one):
    monkeypatch.setattr(h.time,'perf_counter_ns',forbidden)
    monkeypatch.setattr(h.adapter,'peak_process_memory_bytes',lambda:(123456,'ru_maxrss'))
    result=h.observe(one,ARMS[0],mode='memory')
    validate_worker(result,kind='memory',arm=ARMS[0])

def test_independent_inputs_and_cache_reset(monkeypatch,one):
    seen=[]; stage=h.adapter.stage_case
    def wrapper(case):
        result=stage(case);seen.append(result[0]);return result
    monkeypatch.setattr(h.adapter,'stage_case',wrapper)
    h.observe(one,ARMS[0]);h.observe(one,ARMS[1])
    assert len(seen)==6 and len({id(e) for e in seen})==6

def test_oracle_disagreement(monkeypatch,one):
    monkeypatch.setattr(h,'scalar_oracle',lambda c:'f'*64)
    with pytest.raises(ValueError,match='Oracle'):h.observe(one,ARMS[0])

def test_case_digest_tamper(one):
    changed=copy.deepcopy(one);changed['identity_dag_sha256']='f'*64
    with pytest.raises(ValueError):h.observe(changed,ARMS[0])

@pytest.mark.parametrize('field,value',[('elapsed_ns',0),('elapsed_ns',True),('elapsed_ns',float('nan')),
    ('overhead_ns',101),('timer_resolution_ns',101),('overhead_max_ns',99),('api_calls',2),
    ('input_reconstructions',2),('fresh_process',False),('preparation_included',False),('gc_enabled',False),
    ('oracle_digest','f'*64),('direct_digest','f'*64),('root_outcome','hybrid_pair'),
    ('cache_reset',{}),('state_after',{'affinity':[1],'nice':0}),('mode','memory'),('worker_nonce','q'*32)])
def test_adversarial_worker_fields(field,value):
    w=fake_worker();w[field]=value
    with pytest.raises(ValueError):validate_worker(w,kind='time',arm=ARMS[0])

def test_unknown_and_missing_worker_fields():
    for mutation in ('missing','extra'):
        w=fake_worker()
        if mutation=='missing':w.pop('pid')
        else:w['extra']=1
        with pytest.raises(ValueError):validate_worker(w,kind='time',arm=ARMS[0])

def test_threshold_equalities():
    validate_worker(fake_worker(),kind='time',arm=ARMS[0]) # overhead exactly 1%
    assert control([95]*5+[100]+[105]*5)['pass']
    assert not control([94]*5+[100]+[106]*5)['pass']

def test_schedule_counts_pairing_balance():
    cases=load_corpus();s=pilot_schedule(cases)
    assert len(s['rows'])==19800
    assert s==json.loads((ROOT/'data/PILOT_SCHEDULE_V5.json').read_text())
    for a,b in zip(s['rows'][::2],s['rows'][1::2]):
        assert a['case_id']==b['case_id'] and a['member_index']==b['member_index'] and a['arm_id']!=b['arm_id']
    for name,count in [('PRIMARY_TIME',54000),('PRIMARY_MEMORY',3000)]:
        rows=list(iter_expanded(json.loads((ROOT/'data'/f'{name}_SCHEDULE_V5.json').read_text())))
        assert len(rows)==count
        if name=='PRIMARY_TIME':
            for case in cases:
                first=[r['arm_id'] for r in rows[::2] if r['case_id']==case]
                assert first.count(ARMS[0])==first.count(ARMS[1])==135

def test_secondary_expansions():
    for kind in ('TIME','MEMORY'):
        s=json.loads((ROOT/'data'/f'SECONDARY_{kind}_SCHEDULE_V5.json').read_text())
        expected=sum(len(b['arm_order'][c]) for cell in s['outer_schedule']['cells'] for b in cell['blocks'] for c in b['case_order'])*s['members']
        assert sum(1 for _ in iter_expanded(s))==expected
        assert s['execution_authorized'] is False

def test_full_synthetic_pilot_all200():
    schedule=pilot_schedule(load_corpus())['rows'];rows=synthetic_rows(schedule)
    result=analyze_pilot(rows,schedule,binding_fields(),{c:'a'*64 for c in load_corpus()},{'affinity':[0],'nice':0})
    assert result['all_controls_pass'] and result['controls_passed']==200 and result['gate_a']=='NO-GO'
    assert not any('ratio' in k or 'speed' in k for k in result)
    assert not analyze_pilot(rows[:-1],schedule,binding_fields(),{}, {})['all_controls_pass']

@pytest.mark.parametrize('mutation',['duplicate','missing','reorder','nonce','case','binding','chain','failure','unknown'])
def test_adversarial_dataset(mutation):
    schedule=pilot_schedule(load_corpus())['rows'][:18];rows=synthetic_rows(schedule)
    if mutation=='duplicate':rows.append(copy.deepcopy(rows[-1]))
    elif mutation=='missing':rows.pop()
    elif mutation=='reorder':rows[0],rows[1]=rows[1],rows[0]
    else:
        if mutation=='nonce':rows[1]['worker']['worker_nonce']=rows[0]['worker']['worker_nonce']
        if mutation=='case':rows[1]['case_sha256']='f'*64
        if mutation=='binding':rows[1]['environment_sha256']='f'*64
        if mutation=='chain':rows[1]['previous_sha256']='f'*64
        if mutation=='failure':rows[1].update(disposition='timeout',error='synthetic timeout',worker=None)
        if mutation=='unknown':rows[1]['unexpected']=True
        previous=ZERO
        for i,row in enumerate(rows):
            rows[i]=seal_row(row, 'f'*64 if mutation=='chain' and i==1 else previous);previous=rows[i]['row_sha256']
    with pytest.raises(ValueError):validate_dataset(rows,schedule,binding_fields(),{c:'a'*64 for c in load_corpus()},{'affinity':[0],'nice':0})

def test_append_only_chain(tmp_path):
    schedule=pilot_schedule(load_corpus())['rows'][:2];rows=synthetic_rows(schedule)
    path=tmp_path/'test.jsonl';writer=Ledger(path)
    first=writer.append(rows[0]);second=writer.append(rows[1]);writer.close()
    assert second['previous_sha256']==first['row_sha256']
    with pytest.raises((ValueError,FileExistsError)):Ledger(path)
    assert len(path.read_text().splitlines())==2

@pytest.mark.parametrize('runid',['confirm-v5-01','pilot-v4-01','pilot-v5-confirm-01','pilot-v5-01'])
def test_no_authorization_cannot_launch(runid):
    with pytest.raises(ValueError):validate_binding({'run_id':runid})

def test_confirmation_blocked():
    with pytest.raises(ValueError,match='NO-GO'):analyze_primary([],[],[],[],{}, {},{}, {'status':'CANDIDATE','gate_a':'NO-GO'})

def test_synthetic_primary_estimator_boundaries():
    import numpy as np
    c=np.ones((100,30))*100;mem=np.ones((100,15))*100
    assert estimate_synthetic_or_authorized(c*1.2,c,mem*1.1,mem,draws=40)['utility_pass']
    assert not estimate_synthetic_or_authorized(c,c,mem,mem,draws=40)['utility_pass']
    assert not estimate_synthetic_or_authorized(c*1.2,c,mem*1.11,mem,draws=40)['utility_pass']
    with pytest.raises(ValueError):estimate_synthetic_or_authorized(c*float('nan'),c,mem,mem,draws=2)

def test_every_cache_clear_called_each_arm(monkeypatch,one):
    names=['cm_compose','clear_cm_normalize_caches','clear_bitset_env_cache','clear_words_env_cache',
           'clear_cm_ir_compile_cache','clear_cm_ir_persistent_cache','clear_cm_ir_alignment_cache']
    counts={n:0 for n in names}
    for name in names[1:]:
        original=getattr(h.adapter,name)
        def wrapped(n=name, fn=original):
            counts[n]+=1;return fn()
        monkeypatch.setattr(h.adapter,name,wrapped)
    original=h.adapter.cm_compose.cache_clear
    def compose_clear():
        counts['cm_compose']+=1;return original()
    monkeypatch.setattr(h.adapter.cm_compose,'cache_clear',compose_clear)
    for arm in ARMS:h.observe(one,arm)
    assert all(n==2 for n in counts.values())

def host_fixture():
    records={'/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor':'performance\n',
        '/sys/fs/cgroup/cpu.max':'max 100000\n','/sys/fs/cgroup/cpuset.cpus.effective':'0-1\n',
        '/sys/devices/system/cpu/online':'0\n','/sys/devices/system/cpu/cpu0/topology/thread_siblings_list':'0-1\n'}
    return {'schema':'v5_host_binding','reviewed_before_measurement':True,'cpu':0,'nice':0,
        'exclusive_physical_core':True,'smt_sibling_offline':True,'no_cpu_quota':True,'no_competing_experiments':True,
        'image_digest':'a'*64,'dependency_lock_sha256':'b'*64,'dedication_evidence_sha256':'c'*64,
        'monitor_contract_sha256':'d'*64,'fingerprint':{'records':records}}

@pytest.mark.parametrize('mutation',['none','unknown_dedication','governor','sibling','quota','cpuset','priority','drift'])
def test_host_controls_fail_closed(monkeypatch,mutation):
    import environment_v5 as env
    binding=host_fixture();actual=copy.deepcopy(binding['fingerprint'])
    if mutation=='unknown_dedication':binding['exclusive_physical_core']=None
    if mutation=='priority':binding['nice']=-20
    changes={'governor':('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor','schedutil'),
             'sibling':('/sys/devices/system/cpu/online','0-1'),
             'quota':('/sys/fs/cgroup/cpu.max','900000 100000'),
             'cpuset':('/sys/fs/cgroup/cpuset.cpus.effective','1')}
    if mutation in changes:
        k,v=changes[mutation];actual['records'][k]=v;binding['fingerprint']=copy.deepcopy(actual)
    if mutation=='drift':actual['unexpected_change']=True
    monkeypatch.setattr(env,'fingerprint',lambda cpu:actual)
    if mutation=='none':assert env.verify_environment(binding)=={'affinity':[0],'nice':0}
    else:
        with pytest.raises(ValueError):env.verify_environment(binding)

def test_untimed_mode_production_clock_guard(one):
    # Direct worker entry cannot silently turn correctness into a timed run.
    from runner_v5 import worker
    with pytest.raises((ValueError,KeyError)):
        worker({'case_id':one['case_id'],'arm_id':ARMS[0],'mode':'time'})

def test_one_failed_control_prevents_full_pass():
    schedule=pilot_schedule(load_corpus())['rows'];rows=synthetic_rows(schedule);target=sorted(load_corpus())[0]
    previous=ZERO
    for i,row in enumerate(rows):
        if row['case_id']==target and row['arm_id']==ARMS[0]:
            rep=row['repetition_index'];row['worker']['elapsed_ns']=10000 if rep<5 else 20000 if rep==5 else 30000
        rows[i]=seal_row(row,previous);previous=rows[i]['row_sha256']
    result=analyze_pilot(rows,schedule,binding_fields(),{c:'a'*64 for c in load_corpus()},{'affinity':[0],'nice':0})
    assert result['controls_passed']==199 and result['controls_failed']==1 and not result['all_controls_pass']

def test_timeout_stops_without_retry(monkeypatch,tmp_path):
    import pilot_v5 as pilot
    import runner_v5 as runner
    import subprocess
    calls=[]
    monkeypatch.setattr(pilot,'validate_binding',lambda b:{'affinity':[0],'nice':0})
    monkeypatch.setattr(pilot,'verify_environment',lambda b:{'affinity':[0],'nice':0})
    monkeypatch.setattr(pilot,'throttle_snapshot',lambda:{'nr_throttled':0,'throttled_usec':0})
    def timeout(request):
        calls.append(request);raise subprocess.TimeoutExpired('synthetic-worker',60)
    monkeypatch.setattr(runner,'launch',timeout)
    out=tmp_path/'pilot-v5-SYNTHETIC';binding={**binding_fields(),'environment':{}}
    result=pilot.run(binding,out)
    assert len(calls)==1 and not result['all_controls_pass']
    rows=[json.loads(line) for line in (out/'pilot.jsonl').read_text().splitlines()]
    assert len(rows)==1 and rows[0]['disposition']=='timeout'
    with pytest.raises(FileExistsError):pilot.run(binding,out)

def test_nonmonotonic_injected_clock_rejected(one):
    values=iter([1,0])
    with pytest.raises((ValueError,StopIteration)):
        h.observe(one,ARMS[0],mode='time',clock=lambda:next(values))

def test_primary_schedule_tamper_rejected_before_data():
    bindings=binding_fields();freeze={'status':'FROZEN','gate_a':'GO','authorization_to_execute':True,
        'row_bindings':bindings,'memory_metric':'ru_maxrss','memory_schedule_sha256':'a'*64}
    with pytest.raises(ValueError,match='schedule'):
        analyze_primary([],[],[],[],bindings,{}, {},freeze)
