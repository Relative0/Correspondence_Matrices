"""Read-only integrity check, no timing or execution authorization."""
from v5_common import *

def verify():
    manifest_path=ROOT/'CANDIDATE_MANIFEST_V5.json'
    manifest=json.loads(manifest_path.read_text())
    if manifest['candidate_id']!=CANDIDATE or manifest['gate_a']!='NO-GO' or manifest['authorization_to_execute'] is not False:
        raise ValueError('Candidate status must remain non-authorizing')
    listed={e['path'] for e in manifest['files']}
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    if actual != listed | {'CANDIDATE_MANIFEST_V5.json'}:
        raise ValueError('Unmanifested/missing candidate files')
    for ent in manifest['files']:
        path=ROOT/ent['path']
        if path.stat().st_size!=ent['bytes'] or sha256_file(path)!=ent['sha256']:
            raise ValueError('Candidate integrity: '+ent['path'])
    for p in (ROOT/'results').glob('*.jsonl'):
        if p.stat().st_size:raise ValueError('Candidate ledgers must remain empty')
    return {'candidate_id':CANDIDATE,'manifest_sha256':sha256_file(manifest_path),
            'verified_files':len(listed),'source_files':verify_source(),'gate_a':'NO-GO',
            'authorized_freeze':False,'failures':[]}

if __name__=='__main__':
    print(json.dumps(verify(),indent=2))
