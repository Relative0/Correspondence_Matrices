"""Independent finite Boolean oracle versus audited CM kernels; no timing."""
import json
from itertools import product
from collections import Counter
from cm_token import cm_token_value,cm_transpose,cm_swap_rows,cm_swap_columns,cm_not,cm_align_signed_operands,cm_compose
from cm_exprlib import Var,Not,And,Or,Xor,Imp,Eqv
from cm_build_pair import compile_expr_to_cm_pair_token

counts=Counter()
def value(t,r,c):return (t>>(2*r+c))&1
def outer(op,a,b):
    return {'AND':lambda:a&b,'OR':lambda:a|b,'XOR':lambda:a^b,'IMP':lambda:int(not a or b),'EQV':lambda:int(a==b)}[op]()
def check(tag,a,b):
    counts[tag]+=1
    assert a==b,(tag,a,b)
assign=list(product((0,1),repeat=2));frames=list(product((False,True),repeat=3))
ops=('AND','OR','XOR','IMP','EQV')
for t in range(16):
    mat=[[value(t,r,c) for c in (1,0)] for r in (1,0)]
    for r,c in assign:
        check('selection',sum([r,1-r][i]*mat[i][j]*[c,1-c][j] for i,j in product(range(2),repeat=2))%2,value(t,r,c))
        check('query',cm_token_value(t,r,c),value(t,r,c))
        for f,args in [(cm_transpose,(c,r)),(cm_swap_rows,(1-r,c)),(cm_swap_columns,(r,1-c))]:check('transforms',value(f(t),r,c),value(t,*args))
        check('complement',value(cm_not(t),r,c),1-value(t,r,c))
    for sw,n1,n2 in frames:
        a=cm_align_signed_operands(t,swapped=sw,negate_first=n1,negate_second=n2)
        for r,c in assign:
            x,y=(c,r) if sw else (r,c)
            check('signed_alignment',value(a,r,c),value(t,x^n1,y^n2))
for t,u,op in product(range(16),range(16),ops):
    for r,c in assign:check('five_fusions',value(cm_compose(t,u,op),r,c),outer(op,value(t,r,c),value(u,r,c)))
for t,u,fr,fs,op in product(range(16),range(16),frames,frames,ops):
    a=cm_align_signed_operands(t,swapped=fr[0],negate_first=fr[1],negate_second=fr[2])
    b=cm_align_signed_operands(u,swapped=fs[0],negate_first=fs[1],negate_second=fs[2])
    fused=cm_compose(a,b,op)
    for r,c in assign:
        x,y=(c,r) if fr[0] else (r,c);v,w=(c,r) if fs[0] else (r,c)
        check('signed_fusions',value(fused,r,c),outer(op,value(t,x^fr[1],y^fr[2]),value(u,v^fs[1],w^fs[2])))
R,C=Var(0),Var(1)
def expr_for(t):
    terms=[And(R if r else Not(R),C if c else Not(C)) for r,c in assign if value(t,r,c)]
    if not terms:return Xor(And(R,C),And(R,C))
    e=terms[0]
    for z in terms[1:]:e=Or(e,z)
    return e
for t in range(16):
    e=expr_for(t)
    for strategy in ('pure_structural','hybrid','retabulate'):
        p,m=compile_expr_to_cm_pair_token(e,['x0'],['x1'],{},strategy=strategy)
        check('all_tokens_compilation',p.token,t)
        check('all_tokens_provenance',m['root_outcome'],'full_retabulation' if strategy=='retabulate' else 'pure_structural')
worked=Xor(Imp(R,Not(C)),Imp(Not(C),R))
for e,t in [(worked,9),(Not(worked),6)]:
    p,_=compile_expr_to_cm_pair_token(e,['x0'],['x1'],{},strategy='pure_structural');check('worked_implication',p.token,t)
print(json.dumps({'checks':dict(counts),'total':sum(counts.values()),'failures':0,'scope':'Finite exhaustive checks, not an unbounded proof or performance experiment'},indent=2))
