"""One subprocess per elementary call. No confirmatory campaign entry point."""
from v5_common import *
import argparse
import os
import subprocess
from harness_v5 import observe

def launch(request, *, executable=sys.executable):
    env = os.environ.copy(); env.update(ENV)
    completed = subprocess.run([executable, '-B', str(ROOT / 'runner_v5.py'), '--worker'],
        input=canonical_json(request), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=60, env=env, cwd=ROOT, check=False)
    if completed.returncode:
        raise RuntimeError(completed.stderr.decode('utf-8','replace')[-1000:])
    result = json.loads(completed.stdout)
    if result['parent_pid'] != os.getpid() or result['pid'] == os.getpid():
        raise ValueError('Worker process isolation failure')
    return result

def worker(request):
    mode = request.get('mode', 'correctness')
    if mode != 'correctness':
        if mode != 'time': raise ValueError('Candidate does not authorize memory/confirmation execution')
        from pilot_v5 import validate_binding
        binding = request['binding']
        validate_binding(binding)
        cpu = binding['environment']['cpu']
        os.sched_setaffinity(0, {cpu})
        if os.getpriority(os.PRIO_PROCESS, 0) != 0: raise ValueError('Wrong priority')
    case_id = request['case_id']; cases = load_corpus()
    if request['arm_id'] not in ARMS: raise ValueError('Primary arms only')
    oracle_map = json.loads((ROOT / 'data' / 'ORACLE_V5.json').read_text())
    result = observe(cases[case_id], request['arm_id'], mode=mode, expected_digest=oracle_map[case_id])
    if mode == 'time':
        from environment_v5 import verify_environment
        verify_environment(binding['environment'])
    return result

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--worker', action='store_true'); args = p.parse_args()
    if not args.worker: p.error('Worker only; no confirmatory launcher')
    sys.stdout.buffer.write(canonical_json(worker(json.loads(sys.stdin.buffer.read()))))
