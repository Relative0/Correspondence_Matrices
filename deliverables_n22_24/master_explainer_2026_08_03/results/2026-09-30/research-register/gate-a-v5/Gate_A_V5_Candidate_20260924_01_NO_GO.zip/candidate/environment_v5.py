"""Fail-closed Linux host binding. This task does not select or probe a pilot host."""
from v5_common import *
import os
import platform
import time
import numpy as np

def cpu_list(text):
    out=set()
    for part in text.strip().split(','):
        ends=part.split('-');a=int(ends[0]);b=int(ends[-1]);out.update(range(a,b+1))
    return out

def throttle_snapshot():
    # V5 deliberately requires cgroup v2, with the host review covering ancestors.
    data=dict(line.split() for line in Path('/sys/fs/cgroup/cpu.stat').read_text().splitlines())
    if 'nr_throttled' not in data or 'throttled_usec' not in data:
        raise ValueError('Missing cgroup v2 throttling evidence')
    return {k:int(data[k]) for k in ('nr_throttled','throttled_usec')}

def fingerprint(cpu):
    if sys.platform != 'linux': raise ValueError('Pilot requires qualified Linux host')
    paths = ['/proc/cpuinfo','/sys/devices/system/cpu/cpu%d/cpufreq/scaling_governor' % cpu,
             '/sys/devices/system/cpu/cpu%d/topology/thread_siblings_list' % cpu,
             '/sys/devices/system/cpu/online','/etc/os-release',
             '/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpuset.cpus.effective','/proc/meminfo']
    records = {}
    for path in paths:
        data = Path(path).read_text()
        # cpu MHz is dynamic; CPU identification is the stable fields only.
        if path == '/proc/cpuinfo':
            data = '\n'.join(line for line in data.splitlines() if line.split(':')[0].strip() in
                {'vendor_id','cpu family','model','model name','stepping','microcode','physical id','core id','siblings','cpu cores'})
        if path == '/proc/meminfo':
            data='\n'.join(line for line in data.splitlines() if line.startswith('MemTotal:'))
        records[path] = data
    info = time.get_clock_info('perf_counter')
    return {'system': platform.system(), 'release': platform.release(), 'machine': platform.machine(),
            'python': platform.python_version(), 'python_executable_sha256': sha256_file(sys.executable),
            'numpy': np.__version__, 'records': records, 'timer': {'implementation': info.implementation,
            'resolution': info.resolution,'monotonic': info.monotonic,'adjustable': info.adjustable},
            'recursion_limit': sys.getrecursionlimit()}

def verify_environment(binding):
    if binding.get('schema') != 'v5_host_binding' or binding.get('reviewed_before_measurement') is not True:
        raise ValueError('Host not prospectively reviewed')
    if not integer(binding.get('cpu')) or binding.get('nice') != 0:
        raise ValueError('Affinity/priority binding')
    for key in ('exclusive_physical_core','smt_sibling_offline','no_cpu_quota','no_competing_experiments'):
        if binding.get(key) is not True: raise ValueError('Missing host control: ' + key)
    for key in ('image_digest','dependency_lock_sha256','dedication_evidence_sha256','monitor_contract_sha256'):
        if not digest(binding.get(key)): raise ValueError('Unbound host evidence: ' + key)
    actual = fingerprint(binding['cpu'])
    if actual != binding.get('fingerprint'):
        raise ValueError('Host fingerprint mismatch')
    governor = actual['records'][f"/sys/devices/system/cpu/cpu{binding['cpu']}/cpufreq/scaling_governor"].strip()
    if governor != 'performance': raise ValueError('Unqualified governor')
    records=actual['records'];cpu=binding['cpu']
    if records['/sys/fs/cgroup/cpu.max'].split()[0]!='max': raise ValueError('CPU quota present')
    if cpu not in cpu_list(records['/sys/fs/cgroup/cpuset.cpus.effective']): raise ValueError('CPU outside cpuset')
    online=cpu_list(records['/sys/devices/system/cpu/online'])
    siblings=cpu_list(records[f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list'])
    if cpu not in online or (siblings-{cpu}) & online: raise ValueError('SMT sibling not offline')
    return {'affinity': [binding['cpu']], 'nice': 0}
