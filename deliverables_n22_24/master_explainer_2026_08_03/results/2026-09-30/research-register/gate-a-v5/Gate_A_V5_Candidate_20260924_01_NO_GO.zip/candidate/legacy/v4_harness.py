"""Source-qualified Protocol v4 adapters and append-only runner primitives.

This module contains no confirmatory results.  It is designed so that case
serialization is reconstructed before an arm is selected, timing encloses one
arm operation, and correctness/logging occur outside that boundary.
"""
from __future__ import annotations

import ctypes
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import time
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from bitset_backend import (
    PreparedFlatEvaluation,
    _bind_flat_program,
    bitset_env_cache_stats,
    bitset_to_bool_array,
    build_bitset_env,
    clear_bitset_env_cache,
    clear_words_env_cache,
    compile_expr_cse,
    eval_expr_bitset,
)
import cm_build_pair as pair_module
from cm_build_pair import compile_expr_to_cm_pair, compile_expr_to_cm_pair_token
from cm_build import compile_expr_to_cm
from cm_exprlib import And, Eqv, Expr, Imp, Not, Or, Var, Xor
from cm_ir import (
    clear_cm_ir_alignment_cache,
    clear_cm_ir_compile_cache,
    clear_cm_ir_persistent_cache,
    cm_ir_alignment_cache_stats,
    cm_ir_persistent_cache_stats,
)
from cm_normalize import clear_cm_normalize_caches, cm_normalize_cache_stats
from cm_token import cm_compose, cm_token_value
from cmbench.output_budget import (
    OutputBudget,
    OutputBudgetExceeded,
    decide_output_budget,
    estimate_explicit_output,
    require_output_budget,
)


SCHEMA_VERSION = "cm_pair_gate_v4"
PROTOCOL_VERSION = "4"
ZERO_SHA256 = "0" * 64
SHA256_HEX = set("0123456789abcdef")
COMMON_DENSE_BUDGET = OutputBudget(
    max_output_bytes=65536,
    max_temporary_bytes=None,
    max_output_vars=16,
    allow_reduced_output=False,
)
ARM_IDS = {
    "cm_pure", "cm_hybrid", "cm_tabulate", "direct_packed",
    "prepared_cse", "ordinary_cm", "generic_local", "robdd", "abc_aig",
}
DISPOSITIONS = {
    "ok", "no_pair", "invalid_request", "budget_refused", "timeout", "oom",
    "exception", "disagreement", "infrastructure_failure", "not_applicable",
}
RECORD_KINDS = {"time", "memory", "correctness", "diagnostic", "intake"}
CORRECTNESS = {"pass", "fail", "not_checked", "not_applicable"}
ARTIFACTS = {"token", "scalar", "packed", "dense"}


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_bytes(canonical_json(value))


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


NODE_TYPES = {"v": Var, "n": Not, "a": And, "o": Or, "x": Xor, "i": Imp, "e": Eqv}
TYPE_CODES = {Var: "v", Not: "n", And: "a", Or: "o", Xor: "x", Imp: "i", Eqv: "e"}


def serialize_identity_dag(expr: Expr) -> dict[str, Any]:
    """Serialize an Expr DAG while preserving sharing and equal-distinct nodes."""
    order: list[Expr] = []
    seen: set[int] = set()
    active: set[int] = set()
    stack: list[tuple[Expr, bool]] = [(expr, False)]
    while stack:
        node, done = stack.pop()
        key = id(node)
        if done:
            active.discard(key)
            if key not in seen:
                seen.add(key)
                order.append(node)
            continue
        if key in seen:
            continue
        if key in active:
            raise ValueError("cyclic expression")
        active.add(key)
        stack.append((node, True))
        if isinstance(node, Not):
            stack.append((node.a, False))
        elif isinstance(node, (And, Or, Xor, Imp, Eqv)):
            stack.append((node.b, False)); stack.append((node.a, False))
        elif not isinstance(node, Var):
            raise TypeError(type(node))
    index = {id(node): i for i, node in enumerate(order)}
    nodes: list[list[Any]] = []
    for node in order:
        code = TYPE_CODES[type(node)]
        if isinstance(node, Var):
            nodes.append([code, int(node.i)])
        elif isinstance(node, Not):
            nodes.append([code, index[id(node.a)]])
        else:
            nodes.append([code, index[id(node.a)], index[id(node.b)]])
    return {"format": "cm_expr_identity_dag_v1", "nodes": nodes, "root": index[id(expr)]}


def deserialize_identity_dag(payload: Mapping[str, Any]) -> Expr:
    """Construct fresh Expr objects. No source AST or attached caches are reused."""
    if set(payload) != {"format", "nodes", "root"} or payload["format"] != "cm_expr_identity_dag_v1":
        raise ValueError("invalid identity-DAG envelope")
    made: list[Expr] = []
    for idx, spec in enumerate(payload["nodes"]):
        if not isinstance(spec, list) or not spec:
            raise ValueError(f"invalid node {idx}")
        code = spec[0]
        if code == "v" and len(spec) == 2 and type(spec[1]) is int and spec[1] >= 0:
            node: Expr = Var(spec[1])
        elif code == "n" and len(spec) == 2 and type(spec[1]) is int and 0 <= spec[1] < idx:
            node = Not(made[spec[1]])
        elif code in {"a", "o", "x", "i", "e"} and len(spec) == 3:
            a, b = spec[1:]
            if not all(type(v) is int and 0 <= v < idx for v in (a, b)):
                raise ValueError(f"non-postorder edge at node {idx}")
            node = NODE_TYPES[code](made[a], made[b])
        else:
            raise ValueError(f"invalid node {idx}")
        made.append(node)
    root = payload["root"]
    if type(root) is not int or not 0 <= root < len(made):
        raise ValueError("invalid root")
    return made[root]


def structural_prefix(expr: Expr) -> str:
    if isinstance(expr, Var): return f"v{expr.i}"
    if isinstance(expr, Not): return f"n({structural_prefix(expr.a)})"
    return f"{TYPE_CODES[type(expr)]}({structural_prefix(expr.a)},{structural_prefix(expr.b)})"


def expression_stats(expr: Expr) -> dict[str, int]:
    _vars, occurrences, unique_nodes, height = pair_module._expr_stats(expr)
    equal_counts: dict[str, int] = {}
    seen: set[int] = set(); stack = [expr]
    while stack:
        node = stack.pop()
        if id(node) in seen: continue
        seen.add(id(node))
        digest = sha256_bytes(structural_prefix(node).encode("ascii"))
        equal_counts[digest] = equal_counts.get(digest, 0) + 1
        if isinstance(node, Not): stack.append(node.a)
        elif isinstance(node, (And, Or, Xor, Imp, Eqv)): stack.extend((node.a, node.b))
    return {
        "ast_occurrences": occurrences,
        "unique_object_nodes": unique_nodes,
        "ast_height": height,
        "equal_distinct_subtree_count": sum(v - 1 for v in equal_counts.values() if v > 1),
    }


def stage_case(case: Mapping[str, Any]) -> tuple[Expr, dict[str, Any]]:
    """Arm-independent input staging and immutable identity verification."""
    allowed = {"case_id", "identity_dag", "identity_dag_sha256", "structural_syntax_sha256",
               "row_layout", "column_layout", "fixed_bindings", "output_artifact", "reuse_count"}
    missing = allowed - set(case)
    if missing: raise ValueError(f"case missing fields: {sorted(missing)}")
    payload = case["identity_dag"]
    if sha256_json(payload) != case["identity_dag_sha256"]:
        raise ValueError("identity DAG hash mismatch")
    expr = deserialize_identity_dag(payload)
    if sha256_bytes(structural_prefix(expr).encode("ascii")) != case["structural_syntax_sha256"]:
        raise ValueError("structural syntax hash mismatch")
    meta = expression_stats(expr)
    meta.update({
        "case_id": case["case_id"],
        "case_sha256": sha256_json(case),
        "identity_dag_sha256": case["identity_dag_sha256"],
        "structural_syntax_sha256": case["structural_syntax_sha256"],
    })
    return expr, meta


def _ambient_env(rows: Sequence[str], cols: Sequence[str], fixed: Mapping[str, int]) -> dict[str, int]:
    names = tuple(rows) + tuple(cols)
    if len(set(rows)) != len(rows) or len(set(cols)) != len(cols) or set(rows) & set(cols):
        raise ValueError("row and column layouts must be disjoint and duplicate-free")
    env = dict(build_bitset_env(names))
    full = (1 << (1 << len(names))) - 1
    for name in names:
        if name in fixed:
            env[name] = full if int(bool(fixed[name])) else 0
    return env


def direct_packed(expr: Expr, rows: Sequence[str], cols: Sequence[str], fixed: Mapping[str, int]) -> int:
    """Fixed-first ambient direct adapter; all declared axes remain present."""
    env = _ambient_env(rows, cols, fixed)
    return int(eval_expr_bitset(expr, env, fixed=fixed))


def generic_local_bits(expr: Expr, rows: Sequence[str], cols: Sequence[str], fixed: Mapping[str, int]) -> int:
    """Independent scalar-tabulation local truth-function adapter."""
    names=tuple(rows)+tuple(cols)
    if len(names)>16:raise ValueError("generic local adapter limited by common 16-axis budget")
    def evaluate(node:Expr,assignment:Mapping[str,int],memo:dict[int,int])->int:
        key=id(node)
        if key in memo:return memo[key]
        if isinstance(node,Var):
            name=f"x{node.i}"
            if name in fixed:value=int(bool(fixed[name]))
            elif name in assignment:value=int(bool(assignment[name]))
            else:raise KeyError(f"missing live/fixed value for {name}")
        elif isinstance(node,Not):value=1-evaluate(node.a,assignment,memo)
        else:
            a=evaluate(node.a,assignment,memo);b=evaluate(node.b,assignment,memo)
            if isinstance(node,And):value=a&b
            elif isinstance(node,Or):value=a|b
            elif isinstance(node,Xor):value=a^b
            elif isinstance(node,Imp):value=(1-a)|b
            elif isinstance(node,Eqv):value=1-(a^b)
            else:raise TypeError(node)
        memo[key]=value;return value
    bits=0
    for index in range(1<<len(names)):
        assignment={name:(index>>(len(names)-1-position))&1 for position,name in enumerate(names)}
        bits|=evaluate(expr,assignment,{})<<index
    return bits


def bits_to_artifact(bits: int, rows: Sequence[str], cols: Sequence[str], artifact: str) -> Any:
    n = len(rows) + len(cols)
    if artifact == "token":
        if n != 2: raise ValueError("token endpoint requires exactly two ambient axes")
        return int(bits)
    if artifact == "scalar":
        if n != 0: raise ValueError("scalar endpoint requires no ambient axes")
        return int(bits & 1)
    if artifact == "packed":
        return int(bits).to_bytes(((1 << n) + 7) // 8, "little")
    if artifact == "dense":
        require_output_budget(decide_output_budget(
            COMMON_DENSE_BUDGET, estimate_explicit_output(n, "dense_bool"), artifact_name="dense endpoint"))
        return bitset_to_bool_array(int(bits), n).astype(bool).reshape(1 << len(rows), 1 << len(cols)).copy()
    raise ValueError(f"unknown artifact {artifact!r}")


def native_robdd_artifact(expr: Expr, rows: Sequence[str], cols: Sequence[str],
                          fixed: Mapping[str, int], artifact: str) -> tuple[Any, dict[str, Any]]:
    """Build one fresh native CUDD manager with fixed order and no reordering."""
    try:
        import dd
        import dd.cudd as cudd
    except Exception as exc:
        raise RuntimeError("native dd.cudd backend unavailable") from exc
    ambient = list(rows) + list(cols)
    if len(set(ambient)) != len(ambient):
        raise ValueError("duplicate or overlapping ambient axes")
    seen: set[int] = set(); variables: set[str] = set(); stack = [expr]
    while stack:
        node = stack.pop()
        if id(node) in seen: continue
        seen.add(id(node))
        if isinstance(node, Var): variables.add(f"x{node.i}")
        elif isinstance(node, Not): stack.append(node.a)
        elif isinstance(node, (And, Or, Xor, Imp, Eqv)): stack.extend((node.a, node.b))
        else: raise TypeError(node)
    variables.update(str(name) for name in fixed)
    variables.update(ambient)
    def variable_key(name: str) -> tuple[int, str]:
        return (int(name[1:]), name) if name.startswith("x") and name[1:].isdigit() else (sys.maxsize, name)
    order = ambient + sorted(variables - set(ambient), key=variable_key)
    manager = cudd.BDD()
    manager.declare(*order)
    try: manager.configure(reordering=False)
    except Exception: pass
    def build(node: Expr):
        if isinstance(node, Var): return manager.var(f"x{node.i}")
        if isinstance(node, Not): return ~build(node.a)
        a = build(node.a); b = build(node.b)
        if isinstance(node, And): return a & b
        if isinstance(node, Or): return a | b
        if isinstance(node, Xor): return manager.apply("xor", a, b)
        if isinstance(node, Imp): return (~a) | b
        if isinstance(node, Eqv): return ~manager.apply("xor", a, b)
        raise TypeError(node)
    root = build(expr)
    fixed_root = (manager.let({name: bool(value) for name, value in fixed.items()}, root)
                  if fixed else root)
    bits = 0
    for index in range(1 << len(ambient)):
        assignment = {
            name: bool((index >> (len(ambient) - 1 - position)) & 1)
            for position, name in enumerate(ambient) if name not in fixed
        }
        terminal = manager.let(assignment, fixed_root) if assignment else fixed_root
        if terminal == manager.true: bits |= 1 << index
        elif terminal != manager.false: raise AssertionError("ROBDD assignment did not reduce to a terminal")
    dag_size = getattr(fixed_root, "dag_size", None)
    if callable(dag_size): dag_size = dag_size()
    metrics = {
        "robdd_backend": "dd.cudd", "robdd_dd_version": str(dd.__version__),
        "robdd_cudd_version": str(cudd.__version__), "robdd_variable_order": order,
        "robdd_dynamic_reordering": False,
        "robdd_node_count": int(dag_size or len(manager)),
    }
    return bits_to_artifact(bits, rows, cols, artifact), metrics


def artifact_digest(artifact: Any, rows: Sequence[str], cols: Sequence[str],
                    fixed: Mapping[str, int], artifact_kind: str) -> str:
    shape = ([1 << len(rows), 1 << len(cols)] if artifact_kind == "dense" else [])
    dtype = "bool" if artifact_kind == "dense" else (
        "uint8-bytes" if artifact_kind == "packed" else "uint4" if artifact_kind == "token" else "bool")
    header = {"artifact": artifact_kind, "rows": list(rows), "cols": list(cols),
              "fixed": dict(sorted(fixed.items())), "shape": shape, "dtype": dtype,
              "order": "false-first lexicographic; row-major C order"}
    if artifact_kind == "dense": payload = np.asarray(artifact, dtype=np.uint8).tobytes(order="C")
    elif artifact_kind == "packed": payload = bytes(artifact)
    else: payload = bytes([int(artifact)])
    return sha256_bytes(canonical_json(header) + b"\n" + payload)


def _cache_snapshot() -> dict[str, Any]:
    compose = cm_compose.cache_info()
    return {
        "cm_compose": {"hits": compose.hits, "misses": compose.misses, "size": compose.currsize},
        "normalize": cm_normalize_cache_stats(),
        "bitset_env": bitset_env_cache_stats(),
        "ir_persistent": cm_ir_persistent_cache_stats(),
        "ir_alignment": cm_ir_alignment_cache_stats(),
    }


def reset_workload_caches() -> tuple[dict[str, Any], dict[str, Any]]:
    before = _cache_snapshot()
    cm_compose.cache_clear()
    clear_cm_normalize_caches()
    clear_bitset_env_cache()
    clear_words_env_cache()
    clear_cm_ir_compile_cache()
    clear_cm_ir_persistent_cache()
    clear_cm_ir_alignment_cache()
    after = _cache_snapshot()
    nonzero: list[str] = []
    for name, stats in after.items():
        for key, value in stats.items():
            if key in {"size", "currsize", "hits", "misses"} and value != 0:
                nonzero.append(f"{name}.{key}={value}")
    if nonzero:
        raise AssertionError("cache reset failed: " + ", ".join(nonzero))
    return before, after


class PairWorkProbe:
    """Untimed wrapper recording actual pair constructions and support scans."""
    def __init__(self) -> None:
        self.pair_constructions = 0; self.support_passes = 0; self.support_unique_visits = 0
        self._pair = pair_module._Pair; self._stats = pair_module._expr_stats
    def __enter__(self) -> "PairWorkProbe":
        original_pair, original_stats, owner = self._pair, self._stats, self
        def counted_pair(*args: Any, **kwargs: Any):
            owner.pair_constructions += 1; return original_pair(*args, **kwargs)
        def counted_stats(expr: Expr):
            result = original_stats(expr); owner.support_passes += 1; owner.support_unique_visits += result[2]; return result
        pair_module._Pair = counted_pair; pair_module._expr_stats = counted_stats
        return self
    def __exit__(self, *_: Any) -> None:
        pair_module._Pair = self._pair; pair_module._expr_stats = self._stats


def run_arm(expr: Expr, *, arm_id: str, rows: Sequence[str], cols: Sequence[str],
            fixed: Mapping[str, int], artifact: str, reuse_count: int = 1,
            diagnostics: bool = False) -> tuple[Any, dict[str, Any]]:
    if arm_id not in ARM_IDS: raise ValueError(f"unknown arm {arm_id!r}")
    if type(reuse_count) is not int or reuse_count < 1: raise ValueError("reuse_count must be positive")
    if arm_id == "abc_aig":
        raise NotImplementedError(f"{arm_id} requires a separately frozen qualified adapter")
    if arm_id == "robdd":
        return native_robdd_artifact(expr, rows, cols, fixed, artifact)
    strategy = {"cm_pure": "pure_structural", "cm_hybrid": "hybrid", "cm_tabulate": "retabulate"}.get(arm_id)
    metrics: dict[str, Any] = {}
    probe = PairWorkProbe() if diagnostics and strategy else None
    if probe: probe.__enter__()
    try:
        if strategy:
            if artifact == "token":
                compiled, native = compile_expr_to_cm_pair_token(expr, list(rows), list(cols), dict(fixed), strategy=strategy)
                metrics.update(native)
                if compiled is None: raise LookupError("NoPair")
                result = int(compiled.token)
                for _ in range(reuse_count - 1): cm_token_value(result, 0, 0)
            elif artifact == "dense":
                result, native = compile_expr_to_cm_pair(
                    expr, list(rows), list(cols), dict(fixed), pair_strategy=strategy,
                    output_budget=COMMON_DENSE_BUDGET)
                metrics.update(native)
            else:
                compiled, native = compile_expr_to_cm_pair_token(expr, list(rows), list(cols), dict(fixed), strategy=strategy)
                metrics.update(native)
                if compiled is None: raise LookupError("NoPair")
                result = bits_to_artifact(compiled.token, rows, cols, artifact)
        elif arm_id == "direct_packed":
            bits = direct_packed(expr, rows, cols, fixed)
            result = bits_to_artifact(bits, rows, cols, artifact)
            for _ in range(reuse_count - 1):
                if artifact == "token": cm_token_value(bits, 0, 0)
                else: _ = bits
        elif arm_id == "prepared_cse":
            program = compile_expr_cse(expr, flatten=False)
            env = _ambient_env(rows, cols, fixed)
            template, full_mask = _bind_flat_program(program, tuple(rows) + tuple(cols), fixed)
            # Enforce fixed-first overlap in the bound template too.
            for slot, kind, name in program.loads:
                if kind == "var" and name in env: template[slot] = env[name]
            prepared = PreparedFlatEvaluation(program, template, full_mask, False)
            bits = prepared.evaluate()
            for _ in range(reuse_count - 1): bits = prepared.evaluate()
            result = bits_to_artifact(bits, rows, cols, artifact)
            metrics["prepared_representation_bytes"] = sys.getsizeof(program) + sys.getsizeof(template)
        elif arm_id == "generic_local":
            bits=generic_local_bits(expr,rows,cols,fixed)
            result=bits_to_artifact(bits,rows,cols,artifact)
            metrics.update({"scalar_evaluations":1<<(len(rows)+len(cols)),
                            "scalar_occurrence_visits":expression_stats(expr)["ast_occurrences"]*(1<<(len(rows)+len(cols)))})
        else:  # ordinary_cm uses the ordinary IR builder without pair speculation.
            if artifact != "dense": raise NotImplementedError("ordinary_cm currently qualified for dense only")
            diagnostics_map: dict[str, Any] = {}
            result = compile_expr_to_cm(
                expr, list(rows), list(cols), dict(fixed), diagnostics=diagnostics_map,
                output_budget=COMMON_DENSE_BUDGET)
            metrics.update({key:value for key,value in diagnostics_map.items() if isinstance(value,(int,float,str))})
    finally:
        if probe:
            probe.__exit__()
    if probe:
        retained = 0 if metrics.get("root_outcome") == "ordinary_fallback" else int(probe.pair_constructions > 0)
        metrics.update({
            "support_discovery_passes": probe.support_passes,
            "support_unique_visits": probe.support_unique_visits,
            "retained_pair_constructions": retained,
            "discarded_pair_constructions": probe.pair_constructions - retained,
        })
    return result, metrics


def peak_process_memory_bytes() -> tuple[int, str]:
    """Absolute process peak memory; Windows uses PeakWorkingSetSize."""
    if os.name == "nt":
        from ctypes import wintypes
        class PMC_EX(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                        ("PrivateUsage", ctypes.c_size_t)]
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        get_current = kernel32.GetCurrentProcess
        get_current.argtypes = []; get_current.restype = wintypes.HANDLE
        get_memory = kernel32.K32GetProcessMemoryInfo
        get_memory.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC_EX), wintypes.DWORD]
        get_memory.restype = wintypes.BOOL
        counters = PMC_EX(); counters.cb = ctypes.sizeof(counters)
        ok = get_memory(get_current(), ctypes.byref(counters), counters.cb)
        if not ok: raise OSError(ctypes.get_last_error(), "K32GetProcessMemoryInfo failed")
        return int(counters.PeakWorkingSetSize), "PeakWorkingSetSize"
    import resource
    value = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    return value * (1 if sys.platform == "darwin" else 1024), "ru_maxrss"


def run_single_observation(case: Mapping[str, Any], *, arm_id: str, record_kind: str,
                           collect_diagnostics: bool = False,
                           expected_oracle_digest: str | None = None) -> dict[str, Any]:
    """One worker-side observation. Parent chain fields are added by AppendOnlyWriter."""
    if record_kind not in {"time", "memory", "correctness", "diagnostic"}:
        raise ValueError("unsupported worker record kind")
    expr, meta = stage_case(case)
    rows, cols, fixed = case["row_layout"], case["column_layout"], case["fixed_bindings"]
    cache_before, cache_after_reset = reset_workload_caches()
    gc.collect()
    started = time.perf_counter_ns()
    disposition = "ok"; error_type = error_message = None; result = None; metrics: dict[str, Any] = {}
    try:
        result, metrics = run_arm(
            expr, arm_id=arm_id, rows=rows, cols=cols, fixed=fixed,
            artifact=case["output_artifact"], reuse_count=case["reuse_count"],
            diagnostics=collect_diagnostics)
    except LookupError as exc:
        disposition = "no_pair"; error_type = type(exc).__name__; error_message = str(exc)
    except OutputBudgetExceeded as exc:
        disposition = "budget_refused"; error_type = type(exc).__name__; error_message = str(exc)
    except MemoryError as exc:
        disposition = "oom"; error_type = type(exc).__name__; error_message = str(exc)
    except Exception as exc:
        disposition = "exception"; error_type = type(exc).__name__; error_message = str(exc)[:500]
    elapsed = time.perf_counter_ns() - started
    peak, memory_metric = peak_process_memory_bytes()
    digest = None if result is None else artifact_digest(result, rows, cols, fixed, case["output_artifact"])
    oracle_digest = None
    correctness_status = "not_checked"
    equivalence_method = "not_checked"
    if disposition == "ok":
        # Reconstruct a fresh identity DAG and run the independent direct oracle
        # after the timed and peak-memory boundaries.  The worker exits after
        # this check, so oracle activity cannot warm a later observation.
        oracle_expr, _ = stage_case(case)
        oracle_bits = direct_packed(oracle_expr, rows, cols, fixed)
        oracle_artifact = bits_to_artifact(oracle_bits, rows, cols, case["output_artifact"])
        oracle_digest = artifact_digest(oracle_artifact, rows, cols, fixed, case["output_artifact"])
        equivalence_method = "exhaustive"
        if digest != oracle_digest or (expected_oracle_digest is not None and oracle_digest != expected_oracle_digest):
            disposition = "disagreement"
            error_type = "OracleDigestMismatch"
            error_message = "arm, direct oracle, or frozen oracle digest disagrees"
            correctness_status = "fail"
        else:
            correctness_status = "pass"
    return {
        "schema_version": SCHEMA_VERSION, "protocol_version": PROTOCOL_VERSION,
        "record_kind": record_kind, "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "process_id": os.getpid(), "fresh_process": True, "arm_id": arm_id,
        "worker_affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "worker_nice": os.getpriority(os.PRIO_PROCESS, 0) if hasattr(os, "getpriority") else None,
        "disposition": disposition, "error_type": error_type, "error_message": error_message,
        "elapsed_total_ns": elapsed if record_kind == "time" else None,
        "peak_process_memory_bytes": peak if record_kind == "memory" else None,
        "memory_metric": memory_metric if record_kind == "memory" else None,
        "correctness_digest": digest, "oracle_digest": oracle_digest,
        "correctness_status": correctness_status,
        "semantic_equivalence_method": equivalence_method,
        "token_value": int(result) if result is not None and case["output_artifact"] == "token" else None,
        "result_object_bytes": sys.getsizeof(result) if result is not None else None,
        "cache_before": cache_before, "cache_after_reset": cache_after_reset,
        "cache_after": _cache_snapshot(), "metrics": metrics, **meta,
    }


@dataclass
class AppendOnlyWriter:
    path: Path
    predecessor: str = ZERO_SHA256
    def __post_init__(self) -> None:
        self.path = Path(self.path)
        if self.path.exists() and self.path.stat().st_size:
            last = self.path.read_text(encoding="utf-8").splitlines()[-1]
            self.predecessor = json.loads(last)["row_sha256"]
    def append(self, row: Mapping[str, Any]) -> str:
        payload = dict(row); payload["previous_row_sha256"] = self.predecessor
        payload.pop("row_sha256", None)
        digest = sha256_json(payload); payload["row_sha256"] = digest
        validate_chain_row(payload, self.predecessor)
        with open(self.path, "a", encoding="utf-8", newline="\n") as stream:
            stream.write(canonical_json(payload).decode("utf-8") + "\n")
            stream.flush(); os.fsync(stream.fileno())
        self.predecessor = digest
        return digest


def validate_chain_row(row: Mapping[str, Any], expected_predecessor: str) -> None:
    if row.get("previous_row_sha256") != expected_predecessor: raise ValueError("broken predecessor chain")
    digest = row.get("row_sha256")
    if not isinstance(digest, str) or len(digest) != 64 or set(digest) - SHA256_HEX:
        raise ValueError("invalid row SHA-256")
    unsigned = dict(row); unsigned.pop("row_sha256")
    if sha256_json(unsigned) != digest: raise ValueError("row digest mismatch")


def system_identity() -> dict[str, Any]:
    return {
        "platform": platform.platform(), "python": sys.version,
        "python_executable": sys.executable, "numpy": np.__version__,
        "timer": "time.perf_counter_ns", "timer_resolution_seconds": time.get_clock_info("perf_counter").resolution,
        "affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "recursion_limit": sys.getrecursionlimit(),
        "environment": {key: os.environ.get(key) for key in (
            "PYTHONHASHSEED", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")},
    }
