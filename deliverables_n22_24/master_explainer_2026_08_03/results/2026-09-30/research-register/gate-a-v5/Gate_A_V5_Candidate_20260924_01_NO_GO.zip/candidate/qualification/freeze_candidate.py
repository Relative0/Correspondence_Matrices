"""One-shot, deterministic, non-authorizing candidate packaging."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import sys
import zipfile

TASK=Path(__file__).resolve().parents[1];ROOT=TASK/'candidate'
sys.path.insert(0,str(ROOT))
from v5_common import *

def main():
    dest=TASK/'Gate_A_V5_Candidate_20260924_01_NO_GO.zip'
    if dest.exists() or (ROOT/'CANDIDATE_MANIFEST_V5.json').exists():
        raise ValueError('Freeze identity already exists; never overwrite it')
    assert verify_source()==187
    assert all(p.stat().st_size==0 for p in (ROOT/'results').glob('*.jsonl'))
    log=(TASK/'evidence/V5_TESTS_FINAL.log').read_text()
    assert '61 passed' in log and 'failed' not in log.lower()
    assert '147 passed' in (TASK/'evidence/FOCUSED_SOURCE_TESTS.log').read_text()
    assert '95 passed' in (TASK/'evidence/BOUNDARY_TESTS.log').read_text()
    finite=json.loads((TASK/'evidence/FINITE_CORE.log').read_text())
    assert finite['total']==333794 and finite['failures']==0
    out=ROOT/'qualification';out.mkdir()
    names=['package_verification.json','source_identity.json','PRESERVATION_VERIFICATION.json',
           'V5_TESTS_ATTEMPT_01.log','V5_TESTS_ATTEMPT_02.log','V5_TESTS_FINAL.log',
           'FOCUSED_SOURCE_TESTS.log','BOUNDARY_TESTS.log','FINITE_CORE.log',
           'REPAIR_PROMPT_TIMING_STABILITY_V5.md','RUNPOD_STABLE_HOST_PILOT_REPORT.md',
           'remote_evidence_manifest_verification.json']
    for name in names:shutil.copyfile(TASK/'evidence'/name,out/name)
    for name in ['gate_a_regressions.py','finite_core_check.py']:
        shutil.copyfile(TASK/'inherited'/name,out/name)
    for name in ['build_documents.py','freeze_candidate.py']:
        shutil.copyfile(TASK/'work'/name,out/name)
    write_json(out/'VALIDATION_EXECUTION_RECORD_V5.json',{
        'scope':'untimed correctness and synthetic measurement implementation only',
        'performance_observations':0,'confirmatory_results_inspected':False,
        'natural_population_used':False,'paid_work':False,
        'successful_checks':[
            {'command':'python -B -m pytest tests/test_v5.py -q -p no:cacheprovider --basetemp <external-temp>', 'passed':61,'failed':0,'log':'V5_TESTS_FINAL.log'},
            {'command':'python -B -m pytest source/tests/test_cm_pair_alignment.py source/tests/test_cm_optimizations.py source/tests/test_output_budget.py source/tests/test_bitset_backend.py source/tests/test_bitset_cse.py -q -p no:cacheprovider --basetemp <external-temp>', 'passed':147,'failed':0,'log':'FOCUSED_SOURCE_TESTS.log'},
            {'command':'PYTHONPATH=<candidate/source> python -B -m pytest qualification/gate_a_regressions.py -q -p no:cacheprovider --basetemp <external-temp>','passed':95,'failed':0,'log':'BOUNDARY_TESTS.log'},
            {'command':'PYTHONPATH=<candidate/source> python -B qualification/finite_core_check.py','checks':333794,'failures':0,'log':'FINITE_CORE.log'}],
        'resolved_pre_test_issues':['Ambiguous ZIP suffix lookup for conftest.py corrected to exact path.',
                                    'Secondary schedule cells container added to expansion iterator.'],
        'earlier_suites':[{'passed':47,'log':'V5_TESTS_ATTEMPT_01.log'},{'passed':57,'log':'V5_TESTS_ATTEMPT_02.log'}]})
    entries=[]
    for path in sorted(ROOT.rglob('*')):
        if path.is_file():
            rel=path.relative_to(ROOT).as_posix()
            if '__pycache__' in rel or '.pytest_cache' in rel:raise ValueError('Cache contaminates candidate')
            entries.append({'path':rel,'bytes':path.stat().st_size,'sha256':sha256_file(path)})
    manifest={'schema':'cm_pair_v5_candidate_manifest','candidate_id':CANDIDATE,
        'freeze_identity':'protocol-v5-design-freeze-20260924-01','status':'IMMUTABLE_CANDIDATE_NO_GO',
        'gate_a':'NO-GO','authorization_to_execute':False,'performance_qualified':False,
        'candidate_may_be_promoted_in_place':False,'environment_status':'UNBOUND_UNQUALIFIED',
        'source_commit':'0ab8ffd0c23ffa71ee951d375b1c170ffdcc084b','source_files':187,
        'controlling_v4_package_sha256':'93c556a4c15099c260919287e95809079bf8d5ff21b8117e4155fd0482a7306a',
        'primary_corpus_sha256':CORPUS_HASH,'pilot_repetitions':11,'members_per_time_replicate':9,
        'pilot_elementary_workers':19800,'thresholds':{'mad_over_median_max':0.05,'per_elementary_overhead_fraction_max':0.01},
        'no_new_timing_collected':True,'no_confirmatory_results_inspected':True,'no_natural_population_used':True,
        'empty_append_only_files':[e for e in entries if e['path'].startswith('results/')],
        'files':entries}
    write_json(ROOT/'CANDIDATE_MANIFEST_V5.json',manifest)
    from verify_candidate import verify
    validation=verify()
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file():
                info=zipfile.ZipInfo('candidate/'+p.relative_to(ROOT).as_posix(),date_time=(2026,9,24,0,0,0))
                info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100444<<16
                z.writestr(info,p.read_bytes())
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for entry in entries:
            data=z.read('candidate/'+entry['path'])
            assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
        assert z.read('candidate/CANDIDATE_MANIFEST_V5.json')==(ROOT/'CANDIDATE_MANIFEST_V5.json').read_bytes()
    record={'archive':dest.name,'archive_sha256':sha256_file(dest),'archive_bytes':dest.stat().st_size,
            'archive_entries':len(entries)+1,'candidate_validation':validation,'gate_a':'NO-GO'}
    write_json(TASK/'PACKAGE_VERIFICATION_V5.json',record)
    (TASK/'SHA256SUMS.txt').write_text(f"{record['archive_sha256']}  {dest.name}\n{validation['manifest_sha256']}  candidate/CANDIDATE_MANIFEST_V5.json\n",encoding='ascii')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
