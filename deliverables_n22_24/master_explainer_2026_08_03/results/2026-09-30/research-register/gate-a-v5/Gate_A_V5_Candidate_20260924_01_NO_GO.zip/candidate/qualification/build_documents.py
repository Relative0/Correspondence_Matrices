"""Build prospective documentation; reads no performance observations."""
from pathlib import Path
import csv
import difflib
import hashlib
import json
import shutil
import sys
import zipfile

TASK=Path(__file__).resolve().parents[1];ROOT=TASK/'candidate'
sys.path.insert(0,str(ROOT))
from v5_common import *
from schema_v5 import ROW_FIELDS,WORKER_FIELDS

package=Path(r'C:\Users\brian\Documents\Codex\2026-09-23\referenced-chatgpt-conversation-this-is-an\outputs\Gate_A_V4_NO_GO_Qualification_Package.zip')
with zipfile.ZipFile(package) as z:
    for name in ['SECONDARY_CELLS_V4.json']:
        (ROOT/'data'/name).write_bytes(z.read('outputs/v4_freeze/'+name))
    for name in ['row_schema_v4.py','RAW_ROW_SCHEMA_V4.json','runner_v4.py','pilot_v4.py','CONTRACT_MATRIX_V4_FINAL.csv']:
        (ROOT/'legacy'/name).write_bytes(z.read('outputs/v4_freeze/'+name))
    (ROOT/'legacy'/'MEASUREMENT_SCHEMA_V4.md').write_bytes(z.read('outputs/MEASUREMENT_SCHEMA_V4.md'))

def md(name,text):
    (ROOT/name).write_text(text.strip()+'\n',encoding='utf-8')

md('MEASUREMENT_SCHEMA_V5.md','''
# Protocol v5 measurement schema

The authoritative semantic validator is schema_v5.py. RAW_ROW_SCHEMA_V5.json is the strict structural inventory. Unknown or missing row and worker keys are rejected. The primary pilot stores one elementary fresh-process call per row; it never stores an inner-loop sum. Median-of-nine values are derived only after exact schedule coverage validation.

Each row binds run ID, candidate ID and manifest, host environment, unchanged primary corpus, schedule, per-case content hash, and the frozen scalar-oracle manifest. Case layouts, N/U/height, sharing, endpoint, fixed bindings, DAG/syntax, and K remain in the hash-bound corpus rather than duplicated mutable metadata. The pilot accepts only cm_pure/direct_packed and token/K=1 from that corpus. Legacy schema and adapters are preserved separately for secondary endpoint metadata; v5 does not authorize a secondary campaign launcher.

Indices identify outer repetition and member 0..8 (memory member 0 only); schedule_index is globally ordered. pid and parent_pid show actual subprocess separation; worker_nonce distinguishes process instances even if the OS reuses a PID. launch() checks the child-parent relation. No worker pool or persistent child exists. Mode separates correctness, time, and memory. api_calls=1 means one measured arm invocation, excluding the explicitly untimed oracle calls. input_reconstructions=3 means arm input, scalar oracle input, and independent direct input.

Timing rows require positive integer elapsed_ns, integer median/max cost of 1,001 empty clock pairs, and positive integer timer_resolution_ns. Booleans, zero duration, floats, NaN, infinity, and mixed time/memory records are rejected. overhead_max_ns is diagnostic; median and resolution each must be <=1% of elapsed. Equality passes. No subtraction. Correctness rows contain no timing, overhead, or memory value. Memory rows contain only positive peak bytes and the bound ru_maxrss metric, captured before oracle work.

cache_reset must exactly equal all source-qualified empty-cache counters, including composition, normalization, packed environment and IR state. Clear routines also cover words and compile caches without exposed counters; fresh reconstruction covers attached caches. Cache-after is retained for inspection. preparation_included, gc_enabled, fresh_process must be true. Scheduling state before and after must equal the binding. All three digests (artifact, scalar oracle, independent direct) equal the per-case frozen digest; primary CM provenance must be pure_structural.

Failure rows retain timeout, infrastructure_failure, worker_failure, or invalid_observation plus an error and any available worker payload. V5 treats all of these as disqualifying; collection stops and no retry replaces the row. Internal arm NoPair, budget refusal, exception, OOM or disagreement surfaces as a failed worker in this primary-only launcher. Such primary failures cannot become exclusions. The inherited secondary schema retains its more detailed endpoint dispositions for a future separately reviewed secondary launcher.

Every line is canonical JSON, chained by previous_sha256 and row_sha256 (hash excludes row_sha256 itself). A single writer acquires an exclusive permanent .lock marker, fsyncs each append, and refuses resume/overwrite. A missing final row fails coverage even if the surviving prefix chain is valid. Candidate result templates stay zero bytes forever; actual future run ledgers belong in a new external run directory. Immutable storage requires the detached archive/manifest checksum, not filesystem read-only flags alone.
''')

schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Protocol v5 elementary primary observation',
        'type':'object','additionalProperties':False,'required':sorted(ROW_FIELDS),'properties':{k:{} for k in ROW_FIELDS}}
for k in ROW_FIELDS:
    if k.endswith('sha256'):schema['properties'][k]={'type':'string','pattern':'^[0-9a-f]{64}$'}
    elif k.endswith('_index'):schema['properties'][k]={'type':'integer','minimum':0}
    elif k not in ('worker','error'):schema['properties'][k]={'type':'string'}
schema['properties']['schema']={'const':'cm_pair_v5_elementary'}
schema['properties']['candidate_id']={'const':CANDIDATE}
schema['properties']['arm_id']={'enum':list(ARMS)}
schema['properties']['disposition']={'enum':['ok','timeout','infrastructure_failure','worker_failure','invalid_observation']}
schema['properties']['error']={'type':['string','null']}
schema['properties']['worker']={'oneOf':[{'type':'null'},{'type':'object','additionalProperties':False,'required':sorted(WORKER_FIELDS),'properties':{k:{} for k in WORKER_FIELDS}}]}
schema['$comment']='Semantic types, equality, hash-chain, mode, scheduling, coldness and overhead are enforced by schema_v5.py.'
write_json(ROOT/'RAW_ROW_SCHEMA_V5.json',schema)

md('MIGRATION_V4_TO_V5.md','''
# V4 → v5 migration record

This candidate is a prospective successor, not a promotion of the failed v4 identity. No v4 file is overwritten. Production code is unchanged. All revisions are external measurement and documentation code. The archive manifest binds these bytes; no real timing data were collected to set them.

| Surface | V4 | V5 |
|---|---|---|
| Timing unit | One cold process/call | Median of nine independent cold process/calls; raw members retained |
| Pilot | 11 single-call repetitions, 2,200 workers | 11 median-of-nine replicates, 19,800 workers |
| Confirmatory time | 30 single-call repetitions | 30 median-of-nine replicates; 54,000 elementary workers |
| Memory | 15 independent single-call workers | Unchanged 3,000 primary workers; never grouped by nine |
| Primary thresholds | R>=1.20, lower CI>1.00, M<=1.10 | Unchanged; no inference in this task |
| Stability | All 200 MAD/median <=0.05 | Same all-200 limit applied to frozen aggregate estimand |
| Overhead | Parent-clock median compared with case median | Per-worker 1,001 empty pairs; median and clock resolution <=1% of each elementary duration |
| Scheduling | Pilot arm-major observations | Explicit paired members and alternating arm order; outer confirmatory schedules preserved |
| Retry | One certain pre-start infrastructure retry allowed | No retries; fail/retain/stop, missing remainder invalidates pass |
| Oracle | Independent reconstructed direct oracle | Scalar exhaustive oracle plus reconstructed direct and frozen digest |
| Host | Candidate controls insufficient for stability | Exclusive core, offline siblings, performance governor, cgroup v2/no quotas, bound environment and monitoring |
| Primary row metadata | Repeated 125 fields | Content-addressed case metadata plus strict elementary-process envelope |
| Secondary | Frozen generated corpus/schedules and adapter contracts | Same generated corpus; time schedule expands by nine, memory unchanged; no execution authorized |
| Natural | Untouched pairability population | Remains in original package, not staged or used here |

No duration calibration or new tuning data were used. Median-of-nine changes the estimand; comparisons with v4 duration statistics are not permitted. The v4 0.05 gate is not retrospectively reinterpreted. Complete historical WSL identities and artifact hashes are retained separately in V4_EVIDENCE_INDEX.json. Their stored corpus_sha256 field is preserved exactly (9622f2...); it is not relabeled as the final primary file's byte hash (aa0cb2...). Runpod evidence has its own identity and hashes. Raw pilot observations are not parsed by this task.

The copied legacy pilot/runner are provenance only and must never be invoked from this candidate. Only runner_v5.py implements the new elementary observation contract. No confirmatory launcher or Frozen Execution Prompt is supplied. The future confirmatory analyzer has a fail-closed GO/freeze authorization gate; pure-estimator tests use synthetic arrays only.
''')

old=(TASK/'inherited'/'Operator_Level_CM_Compiler_Gate_A_Working_Copy.tex').read_text(encoding='utf-8')
new=old.replace('23 September 2026; not frozen','24 September 2026; Protocol v5 candidate; not frozen')
new=new.replace('Gate A requires Protocol v4 because output axes, cache policy, and the statistical estimand need material clarification. The accompanying v4 working copy is not a freeze authorization.',
 'Gate A now requires the prospective Protocol v5 timing amendment. A reported timing replicate is the median of nine independently launched, post-import cold-process API calls, each with preparation charged and mandatory oracle equality. This candidate is not a freeze authorization.')
new=new.replace('protocol-v4 pair compiler','protocol-v5 pair compiler').replace('What a negative protocol-v4 result would mean','What a negative protocol-v5 result would mean')
new=new.replace('The proposed v4 rule uses 100 distinct formula cases and 30 repetitions per case:',
 'The proposed v5 rule uses the unchanged 100 distinct formula cases and 30 timing replicates per case, each the median of nine independent cold-process calls:')
new=new.replace('The broader token/packed protocol v4 remains unexecuted in the current manuscript record.',
 'The broader token/packed confirmatory protocol remains unexecuted in the current manuscript record; Protocol v5 changes the timing estimand prospectively.')
new=new.replace('four completed exploratory pilots failed the predeclared all-case repeatability rule under mounted and native WSL staging, two pinned CPUs, and nice $-20$.',
 'four completed WSL exploratory pilots failed the predeclared all-case repeatability rule under mounted and native WSL staging, two pinned CPUs, and nice $-20$. A separate retained Runpod pilot also failed, passing 194 of 200 controls with affinity CPU 0 and nice 0.')
new=new.replace('the adopted protocol-v4 freeze and append-only observations','a later adopted protocol-v5 freeze and append-only observations')
amendment=r'''
\paragraph{Prospective Protocol v5 timing amendment (24 September 2026).}
The elementary unit remains one independently reconstructed, cache-reset input and one API operation in a fresh process. The reported replicate is the median of nine independent elementary durations, never an inner loop in a warm worker. Common imports and staging are excluded; all arm-specific preparation and output conversion are charged. No workload warm-up is performed. Scalar exhaustive and independently reconstructed direct oracles are checked after measurement. The 11-replicate exploratory pilot requires every one of 200 case/arm controls to have MAD/median at most 0.05, with each elementary clock-pair overhead and clock resolution at most one percent of its duration. All 19,800 raw elementary observations must be present and valid; failures stop the run without retries. Thirty future primary timing replicates therefore require 54,000 elementary processes. The 15 independent memory repetitions remain single-call absolute process peaks. The primary effect thresholds and paired outer-repetition bootstrap remain unchanged. The candidate has no new performance evidence and Gate A remains NO-GO. Only a later separately authorized, prospectively host-bound exploratory pilot may test stability; a design-test pass cannot establish Gate A GO.

'''
new=new.replace('\\paragraph{Gate A source-qualified check.}',amendment+'\\paragraph{Gate A source-qualified check (retained v4 evidence).}')
(ROOT/'MANUSCRIPT_V5_WORKING_COPY.tex').write_text(new,encoding='utf-8')
(ROOT/'MANUSCRIPT_V4_TO_V5.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='immutable-v4.tex',tofile='MANUSCRIPT_V5_WORKING_COPY.tex')),encoding='utf-8')
md('MANUSCRIPT_V5_STATEMENTS.md','''
# Manuscript status

MANUSCRIPT_V5_WORKING_COPY.tex is a new working source; the v4 TEX/PDF and companion foundations paper are unchanged. MANUSCRIPT_V4_TO_V5.patch makes the prospective edits reviewable. The v5 working source replaces the primary timing unit, explains the 19,800-worker pilot and 54,000-worker future time schedule, retains 15 independent memory repetitions and the primary effect thresholds, adds the Runpod control failure, and keeps Gate A NO-GO. Historical v4 correctness/native qualification counts are explicitly retained history, not claims about a new host.

This task supplies manuscript source and statements, not a newly typeset PDF. PDF layout is therefore not newly qualified. A later publication build can typeset and inspect the successor source; it is not a prerequisite for executing an independently approved exploratory control pilot, but final manuscript/protocol agreement remains a Gate A criterion.
''')

rows=[
['Source identity','187-file unchanged commit closure','verify_source; source_identity evidence','PASS, byte equality'],
['Timing estimand','Median of nine independent cold calls','observe; launch; validate_dataset','Implemented; empirical stability unqualified'],
['Arm preparation','run_arm fully inside each interval','Injected-clock boundary tests','PASS'],
['Cache/input isolation','Complete reset and new DAG for each process','Cache-clear and process tests','PASS'],
['Correctness','Scalar and direct oracle equality; primary S','100 cases x 2 arms untimed','PASS'],
['Pilot schedule','11 x 9; 100 cases; both arms','PILOT_SCHEDULE_V5.json','19,800 elementary rows; unexecuted'],
['Primary time/memory','30 grouped times; 15 single-call peaks','PRIMARY_*_SCHEDULE_V5.json','54,000 / 3,000 elementary rows; unexecuted'],
['Secondary','Preserve 30 cells/900 generated cases; expand time only','SECONDARY_*_SCHEDULE_V5.json; inherited adapters','Schedules verified; execution unqualified'],
['Natural','No population use or pair compiler run','Original Gate A package only','UNTOUCHED; no new natural claim'],
['Statistics','All-200 MAD/median<=0.05; per-leaf overhead<=1%','analyzer_v5.py; exact integer comparisons','Synthetic tests only; real stability UNQUALIFIED'],
['Primary inference','Outer paired bootstrap; thresholds unchanged','analyze_primary; synthetic estimator tests','No confirmation read/run; GO gate closed'],
['Host','Exclusive core; offline SMT; performance governor; no quota','environment_v5.py; prospective binding review','UNQUALIFIED; no host selected'],
['Native controls','Prior CUDD/ABC untimed qualifications','Immutable v4 package','Historical only; new environment requalification required'],
['Manuscript','V5 estimand and NO-GO statements','New TEX + patch; statement review','Source updated; no new PDF build'],
['Ledger/freeze','Empty templates; hash chain; no overwrite/resume','Ledger; candidate manifest; detached archive checksum','Candidate only, never execution authorization'],
]
with (ROOT/'CONTRACT_MATRIX_V5.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['Contract','Protocol/manuscript','Implementation/evidence','Disposition']);w.writerows(rows)

historical=json.loads((TASK/'inherited/v4_freeze/PILOT_CONTROL_SUMMARY_V4.json').read_text())
index={'controlling_package_sha256':sha256_file(package),'wsl_attempts':historical['attempts'],
       'wsl_setup_failures':historical['retained_setup_failures'],
       'runpod':{'run_id':'pilot-v4-runpod-20260924-03','controls_passed':194,'controls_failed':6,
        'raw_artifact_sha256':'b0c7602c638264897bf68bf2a6ef6bb1dfd04dc5c26224ff0b405b5c3c26af6a',
        'archive_sha256':'969c2b54ed471457e7bdf464e179589b96ca3a1b3117eced9c9fc160d6d58fbf',
        'cm_pure':{'passed':96,'failed':4,'max_mad_over_median':0.23801345992583745},
        'direct_packed':{'passed':98,'failed':2,'max_mad_over_median':0.2105232640339576},
        'timer_overhead_failures':0,'affinity':[0],'nice':0},
       'raw_duration_records_parsed':False,'confirmatory_results_inspected':False}
write_json(ROOT/'V4_EVIDENCE_INDEX.json',index)

md('README.md','''
# Protocol v5 candidate — Gate A NO-GO

Start with REVIEW_REPORT_V5.md and PROTOCOL_V5.md. This is prospective design and untimed validation, not a stability pass or an authorized confirmatory freeze.

The 187-file source closure is unmodified. The primary corpus bytes are unchanged. New measurement code lives at package root; legacy/ is immutable provenance. All result templates remain empty. No natural population is included. Generated secondary schedule expansions are data, not executable authorization.

Read-only integrity check (from the extracted candidate directory): `python -B verify_candidate.py`.
Untimed/synthetic design checks: `python -B -m pytest tests/test_v5.py -q -p no:cacheprovider --basetemp <new external temporary directory>`.
Do not run copied legacy pilot/runner scripts. No Frozen Execution Prompt is supplied. No future pilot binding is included. A future binding must be separately authorized and prepared on the selected controlled host; see Protocol section 8 and the review report.

The checksum-identified ZIP and manifest define the immutable candidate. Unzip into a new directory for review; never append to its result templates or promote this candidate manifest to GO. Future results belong under one new pilot-v5-* identity outside the candidate.
''')

print('Documentation and schema generated; no timing collected.')
