"""Pinned imports and non-measuring v5 primitives."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / 'source'), str(ROOT / 'legacy')]
from v4_harness import canonical_json, sha256_file, sha256_json

CANDIDATE = 'gate-a-v5-candidate-20260924-01'
ARMS = ('cm_pure', 'direct_packed')
MEMBERS = 9
PILOT_REPS = 11
ZERO = '0' * 64
CORPUS_HASH = 'aa0cb2f1f4f665ee77ae0fa881a755eb1baa27971d870eec9e5680dc1049112b'
ENV = {'PYTHONHASHSEED': '20260923', 'OMP_NUM_THREADS': '1',
       'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1', 'PYTHONDONTWRITEBYTECODE': '1'}

def load_corpus():
    path = ROOT / 'data' / 'PRIMARY_CORPUS_V4.json'
    if sha256_file(path) != CORPUS_HASH:
        raise ValueError('Primary corpus changed')
    cases = json.loads(path.read_text())['cases']
    if len(cases) != 100 or len({c['case_id'] for c in cases}) != 100:
        raise ValueError('Primary corpus cardinality')
    return {c['case_id']: c for c in cases}

def verify_source():
    entries = json.loads((ROOT / 'source_manifest.json').read_text())
    actual = {p.relative_to(ROOT / 'source').as_posix() for p in (ROOT / 'source').rglob('*') if p.is_file()}
    if actual != {e['path'] for e in entries}:
        raise ValueError('Unexpected or missing source closure file')
    for e in entries:
        data = (ROOT / 'source' / e['path']).read_bytes()
        blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
        if len(data) != e['bytes'] or hashlib.sha256(data).hexdigest() != e['sha256'] or blob != e['git_blob']:
            raise ValueError('Source closure mismatch: ' + e['path'])
    return len(entries)

def write_json(path, obj):
    Path(path).write_bytes(canonical_json(obj) + b'\n')

def integer(value, minimum=0):
    return type(value) is int and value >= minimum

def digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)
