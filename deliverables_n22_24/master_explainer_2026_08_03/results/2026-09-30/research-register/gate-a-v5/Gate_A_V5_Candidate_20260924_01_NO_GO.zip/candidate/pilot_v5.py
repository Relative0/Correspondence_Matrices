"""Future exploratory pilot only. Requires a new, prospectively reviewed run binding."""
from v5_common import *
import argparse
import subprocess
from environment_v5 import verify_environment, throttle_snapshot
from schema_v5 import Ledger, validate_worker
from analyzer_v5 import analyze_pilot

def validate_binding(binding):
    rid = binding.get('run_id','')
    if not isinstance(rid,str) or not rid.startswith('pilot-v5-') or 'confirm' in rid.lower():
        raise ValueError('Exploratory identity only')
    if binding.get('scope') != 'one_exploratory_pilot' or binding.get('separately_authorized') is not True:
        raise ValueError('Separate pilot authorization required')
    if binding.get('candidate_id') != CANDIDATE:
        raise ValueError('Wrong candidate')
    # Unbound booleans cannot replace the concrete reviewed authorization and host evidence.
    for name in ('authorization_record','host_review','monitor_start'):
        ref = binding.get(name,{})
        if not digest(ref.get('sha256')) or sha256_file(ref['path']) != ref['sha256']:
            raise ValueError('Missing reviewed record: '+name)
    start=json.loads(Path(binding['monitor_start']['path']).read_text())
    if start.get('run_id')!=rid or start.get('environment_sha256')!=binding.get('environment_sha256') or start.get('throttle')!=throttle_snapshot():
        raise ValueError('Host monitor/throttling drift')
    for name, path in [('candidate_manifest_sha256','CANDIDATE_MANIFEST_V5.json'),
                       ('schedule_sha256','data/PILOT_SCHEDULE_V5.json'),
                       ('oracle_manifest_sha256','data/ORACLE_V5.json')]:
        if binding.get(name) != sha256_file(ROOT/path): raise ValueError('Binding mismatch: '+name)
    if binding.get('corpus_sha256') != CORPUS_HASH:
        raise ValueError('Corpus binding')
    if binding.get('environment_sha256') != sha256_json(binding['environment']):
        raise ValueError('Environment binding hash')
    manifest=json.loads((ROOT/'CANDIDATE_MANIFEST_V5.json').read_text())
    from verify_candidate import verify
    verify()
    for entry in manifest['files']:
        p=ROOT/entry['path']
        if p.stat().st_size!=entry['bytes'] or sha256_file(p)!=entry['sha256']:
            raise ValueError('Candidate file integrity: '+entry['path'])
    verify_source()
    return verify_environment(binding['environment'])

def row_bindings(binding):
    return {k:binding[k] for k in ('run_id','candidate_manifest_sha256','environment_sha256',
                                  'corpus_sha256','schedule_sha256','oracle_manifest_sha256')}

def run(binding, output_dir):
    state=validate_binding(binding)
    output_dir=Path(output_dir).resolve()
    if output_dir == ROOT or ROOT in output_dir.parents:
        raise ValueError('Never write performance into immutable candidate')
    output_dir.mkdir(exist_ok=False,parents=True)
    write_json(output_dir/'RUN_BINDING.json',binding)
    ledger=Ledger(output_dir/'pilot.jsonl')
    rows=[]; cases=load_corpus(); oracle=json.loads((ROOT/'data/ORACLE_V5.json').read_text())
    schedule=json.loads((ROOT/'data/PILOT_SCHEDULE_V5.json').read_text())['rows']
    from runner_v5 import launch
    try:
        for slot in schedule:
            row={'schema':'cm_pair_v5_elementary','candidate_id':CANDIDATE,**row_bindings(binding),**slot,
                 'case_sha256':cases[slot['case_id']]['case_sha256'],'disposition':'ok','error':None,'worker':None}
            try:
                verify_environment(binding['environment'])
                w=launch({'case_id':slot['case_id'],'arm_id':slot['arm_id'],'mode':'time','binding':binding})
                row['worker']=w
                validate_worker(w,kind='time',arm=slot['arm_id'],expected_oracle=oracle[slot['case_id']],state=state)
                verify_environment(binding['environment'])
            except subprocess.TimeoutExpired:
                row.update(disposition='timeout',error='Worker exceeded fixed 60-second total timeout')
            except (OSError,RuntimeError) as exc:
                row.update(disposition='infrastructure_failure',error=str(exc)[:1000])
            except (ValueError,KeyError,TypeError) as exc:
                row.update(disposition='invalid_observation',error=str(exc)[:1000])
            rows.append(ledger.append(row))
            if row['disposition']!='ok': break
    finally:
        ledger.close()
    report=analyze_pilot(rows,schedule,row_bindings(binding),oracle,state)
    try:
        validate_binding(binding)
        write_json(output_dir/'HOST_MONITOR_END.json',{'run_id':binding['run_id'],'throttle':throttle_snapshot(),'controls_unchanged':True})
    except (ValueError,OSError,KeyError) as exc:
        report.update(all_controls_pass=False,decision='NO-GO',host_error=str(exc))
    # Stability alone cannot qualify the environment: monitor closeout must be
    # reviewed in the later task; it cannot be asserted by this launcher.
    report['host_monitor_closeout']='REQUIRED'
    report['gate_a']='NO-GO'
    write_json(output_dir/'PILOT_REVIEW.json',report)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('binding');p.add_argument('new_output_directory');a=p.parse_args()
    print(json.dumps(run(json.loads(Path(a.binding).read_text()),a.new_output_directory),indent=2))
