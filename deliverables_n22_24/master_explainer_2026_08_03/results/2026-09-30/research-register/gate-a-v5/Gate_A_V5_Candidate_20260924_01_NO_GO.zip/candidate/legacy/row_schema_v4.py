"""Strict raw-row schema and semantic validation for Protocol v4."""
from __future__ import annotations

import json
import math
import re
from typing import Any, Mapping

from v4_harness import ARM_IDS, ARTIFACTS, CORRECTNESS, DISPOSITIONS, RECORD_KINDS, SCHEMA_VERSION, PROTOCOL_VERSION, sha256_json


HASH_RE = re.compile(r"^[0-9a-f]{64}$")
REQUIRED_FIELDS = frozenset("""
schema_version protocol_version run_id manifest_sha256 protocol_sha256 source_manifest_sha256 analysis_sha256
row_id logical_observation_id attempt_index previous_row_sha256 row_sha256 record_kind timestamp_utc process_id environment_id schedule_index order_in_block
case_id case_sha256 identity_dag_sha256 structural_syntax_sha256 corpus_id corpus_manifest_sha256 source_output_id
cell_id stratum generator_seed sharing_class natural_source_revision natural_license original_file original_content_sha256 extraction_manifest_sha256 translation_sha256
original_support_count syntactic_unfixed_count ast_occurrences unique_object_nodes ast_height equal_distinct_subtree_count
row_layout column_layout variable_order fixed_bindings arm_id arm_source_sha256 endpoint_adapter_sha256 requested_strategy effective_strategy
root_outcome provenance token_disposition fallback_executed disposition error_type error_message correctness_status
output_artifact output_order output_shape output_dtype n_out output_elements output_payload_bytes output_information_bits
token_value output_owns_data output_writeable prepared_representation_bytes result_object_bytes
correctness_digest oracle_digest oracle_source_sha256 semantic_equivalence_method
output_budget_bytes output_budget_vars output_budget_estimate_bytes temporary_estimate_bytes output_budget_status
compiler_calls negation_nodes_scanned primitive_pair_tokens signed_operand_alignments token_negations token_fusions direct_pair_retabulations pair_attempts pair_collapses
support_discovery_passes support_unique_visits scalar_evaluations scalar_occurrence_visits discarded_pair_constructions retained_pair_constructions
retabulation_only_mode legacy_strategy_alias cache_regime cache_before cache_after import_policy_id cache_reset_policy_id fresh_process warmup_process_id
repetition_index reuse_count query_schedule_sha256 inner_iterations elapsed_total_ns preparation_ns execution_ns query_ns conversion_ns materialization_ns pair_attempt_ns fallback_ns
peak_process_memory_bytes memory_metric memory_scope memory_adapter_sha256 preparation_included sharing_policy result_reuse_policy timeout_seconds exclusion_reason
""".split())

NULLABLE = frozenset("""
source_output_id natural_source_revision natural_license original_file original_content_sha256 extraction_manifest_sha256 translation_sha256
original_support_count generator_seed requested_strategy effective_strategy root_outcome provenance error_type error_message token_value
output_owns_data output_writeable prepared_representation_bytes result_object_bytes correctness_digest oracle_digest oracle_source_sha256
output_budget_bytes output_budget_vars output_budget_estimate_bytes temporary_estimate_bytes compiler_calls negation_nodes_scanned
primitive_pair_tokens signed_operand_alignments token_negations token_fusions direct_pair_retabulations pair_attempts pair_collapses
support_discovery_passes support_unique_visits scalar_evaluations scalar_occurrence_visits discarded_pair_constructions retained_pair_constructions
query_schedule_sha256 elapsed_total_ns preparation_ns execution_ns query_ns conversion_ns materialization_ns pair_attempt_ns fallback_ns
peak_process_memory_bytes memory_metric memory_scope warmup_process_id exclusion_reason
""".split())

INT_FIELDS = frozenset("""
attempt_index process_id schedule_index order_in_block generator_seed original_support_count syntactic_unfixed_count ast_occurrences unique_object_nodes ast_height equal_distinct_subtree_count
n_out output_elements output_payload_bytes output_information_bits token_value prepared_representation_bytes result_object_bytes output_budget_bytes output_budget_vars
output_budget_estimate_bytes temporary_estimate_bytes compiler_calls negation_nodes_scanned primitive_pair_tokens signed_operand_alignments token_negations token_fusions
direct_pair_retabulations pair_attempts pair_collapses support_discovery_passes support_unique_visits scalar_evaluations scalar_occurrence_visits discarded_pair_constructions
retained_pair_constructions retabulation_only_mode legacy_strategy_alias repetition_index reuse_count inner_iterations elapsed_total_ns preparation_ns execution_ns query_ns
conversion_ns materialization_ns pair_attempt_ns fallback_ns peak_process_memory_bytes warmup_process_id timeout_seconds
""".split())

HASH_FIELDS = frozenset("""
manifest_sha256 protocol_sha256 source_manifest_sha256 analysis_sha256 previous_row_sha256 row_sha256 case_sha256 identity_dag_sha256 structural_syntax_sha256
corpus_manifest_sha256 arm_source_sha256 endpoint_adapter_sha256 correctness_digest oracle_digest oracle_source_sha256 query_schedule_sha256 memory_adapter_sha256
original_content_sha256 extraction_manifest_sha256 translation_sha256
""".split())


def _integer(value: Any, name: str) -> None:
    if type(value) is not int or value < 0: raise ValueError(f"{name} must be a nonnegative integer")


def validate_row(row: Mapping[str, Any], *, check_chain_digest: bool = True) -> None:
    keys = set(row)
    missing, unknown = REQUIRED_FIELDS - keys, keys - REQUIRED_FIELDS
    if missing: raise ValueError(f"missing fields: {sorted(missing)}")
    if unknown: raise ValueError(f"unknown fields: {sorted(unknown)}")
    if row["schema_version"] != SCHEMA_VERSION or row["protocol_version"] != PROTOCOL_VERSION:
        raise ValueError("schema/protocol version mismatch")
    if row["record_kind"] not in RECORD_KINDS: raise ValueError("record_kind")
    if row["arm_id"] not in ARM_IDS: raise ValueError("arm_id")
    if row["disposition"] not in DISPOSITIONS: raise ValueError("disposition")
    if row["correctness_status"] not in CORRECTNESS: raise ValueError("correctness_status")
    if row["output_artifact"] not in ARTIFACTS: raise ValueError("output_artifact")
    if row["sharing_class"] not in {"identity_shared", "equal_distinct", "unshared", "natural_mixed"}: raise ValueError("sharing_class")
    if row["requested_strategy"] not in {None, "pure_structural", "hybrid", "retabulate"}: raise ValueError("requested_strategy")
    if row["effective_strategy"] not in {None, "pure_structural", "hybrid", "retabulate"}: raise ValueError("effective_strategy")
    if row["root_outcome"] not in {None, "pure_structural", "hybrid_pair", "full_retabulation", "ordinary_fallback"}: raise ValueError("root_outcome")
    if row["provenance"] not in {None, "S", "T", "H"}: raise ValueError("provenance")
    if row["token_disposition"] not in {"pair", "no_pair", "invalid_request", "not_applicable"}: raise ValueError("token_disposition")
    if row["output_budget_status"] not in {"ok", "refused", "not_applicable"}: raise ValueError("output_budget_status")
    if row["semantic_equivalence_method"] not in {"exhaustive", "sample_plus_equivalence", "not_checked"}: raise ValueError("semantic_equivalence_method")
    if row["cache_regime"] not in {"post_import_cold", "prepared_reuse"}: raise ValueError("cache_regime")
    for name in INT_FIELDS:
        value = row[name]
        if value is None and name in NULLABLE: continue
        _integer(value, name)
    for name in HASH_FIELDS:
        value = row[name]
        if value is None and name in NULLABLE: continue
        if not isinstance(value, str) or HASH_RE.fullmatch(value) is None: raise ValueError(f"invalid hash {name}")
    for name in ("row_layout", "column_layout", "variable_order"):
        if not isinstance(row[name], list) or not all(isinstance(x, str) for x in row[name]): raise ValueError(name)
        if len(row[name]) != len(set(row[name])): raise ValueError(f"duplicate {name}")
    if set(row["row_layout"]) & set(row["column_layout"]): raise ValueError("axis overlap")
    if row["variable_order"] != row["row_layout"] + row["column_layout"]: raise ValueError("variable order")
    if not isinstance(row["fixed_bindings"], dict) or any(v not in (0, 1) for v in row["fixed_bindings"].values()): raise ValueError("fixed_bindings")
    if row["ast_occurrences"] < row["unique_object_nodes"]: raise ValueError("N must be >= U")
    if row["n_out"] != len(row["variable_order"]): raise ValueError("n_out")
    if row["output_elements"] != 1 << row["n_out"]: raise ValueError("output_elements")
    if row["output_artifact"] == "dense" and row["output_payload_bytes"] != row["output_elements"]: raise ValueError("dense bytes")
    if row["output_artifact"] == "packed" and row["output_payload_bytes"] != (row["output_elements"] + 7) // 8: raise ValueError("packed bytes")
    if row["output_artifact"] == "token" and (row["n_out"] != 2 or row["output_information_bits"] != 4): raise ValueError("token contract")
    if row["legacy_strategy_alias"] != 0: raise ValueError("legacy strategy alias forbidden")
    if row["fresh_process"] is not True: raise ValueError("fresh_process")
    if row["preparation_included"] is not True: raise ValueError("preparation_included")
    if row["record_kind"] == "time" and row["disposition"] == "ok" and (row["elapsed_total_ns"] is None or row["inner_iterations"] != 1): raise ValueError("time boundary")
    if row["record_kind"] == "memory" and row["disposition"] == "ok" and (row["peak_process_memory_bytes"] is None or row["memory_metric"] not in {"PeakWorkingSetSize", "ru_maxrss"}): raise ValueError("memory boundary")
    if row["stratum"] == "G_natural":
        for name in ("natural_source_revision", "natural_license", "original_file", "original_content_sha256", "extraction_manifest_sha256", "translation_sha256"):
            if row[name] is None: raise ValueError(f"natural provenance missing {name}")
    if row["disposition"] == "ok" and row["error_type"] is not None: raise ValueError("ok row with error")
    if row["disposition"] != "ok" and not row["error_type"] and row["disposition"] not in {"no_pair", "not_applicable"}: raise ValueError("failure lacks error")
    if row["disposition"] == "ok":
        if row["correctness_status"] != "pass": raise ValueError("ok row lacks correctness pass")
        if row["correctness_digest"] is None or row["oracle_digest"] is None: raise ValueError("ok row lacks correctness digests")
        if row["correctness_digest"] != row["oracle_digest"]: raise ValueError("ok row digest disagreement")
        if row["semantic_equivalence_method"] == "not_checked": raise ValueError("ok row correctness not checked")
    if row["arm_id"] == "cm_pure":
        if row["requested_strategy"] != "pure_structural" or row["effective_strategy"] != "pure_structural": raise ValueError("cm_pure strategy")
    if check_chain_digest:
        unsigned = dict(row); digest = unsigned.pop("row_sha256")
        if sha256_json(unsigned) != digest: raise ValueError("row digest mismatch")


def schema_document() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "cm_pair_gate_v4.schema.json", "type": "object",
        "additionalProperties": False, "required": sorted(REQUIRED_FIELDS),
        "properties": {name: {"description": "Validated semantically by row_schema_v4.py"} for name in sorted(REQUIRED_FIELDS)},
    }


if __name__ == "__main__":
    print(json.dumps(schema_document(), indent=2, sort_keys=True))
