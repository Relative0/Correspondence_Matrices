"""Strict elementary-row schema and append-only hash-chain verification."""
from v5_common import *

WORKER_FIELDS = {'worker_nonce','pid','parent_pid','mode','elapsed_ns','overhead_ns','overhead_max_ns',
    'timer_resolution_ns','peak_memory_bytes','memory_metric','cache_reset','cache_after','correctness_digest',
    'oracle_digest','direct_digest','root_outcome','state_before','state_after','api_calls','input_reconstructions',
    'preparation_included','gc_enabled','fresh_process'}
ROW_FIELDS = {'schema','run_id','candidate_id','candidate_manifest_sha256','environment_sha256',
    'corpus_sha256','schedule_sha256','oracle_manifest_sha256','schedule_index','case_id','case_sha256',
    'arm_id','repetition_index','member_index','disposition','error','worker','previous_sha256','row_sha256'}

def validate_worker(w, *, kind, arm, expected_oracle=None, state=None):
    if not isinstance(w, dict) or set(w) != WORKER_FIELDS:
        raise ValueError('Worker schema fields')
    if w['mode'] != kind or not integer(w['pid'], 1) or not integer(w['parent_pid'], 1) or w['pid'] == w['parent_pid']:
        raise ValueError('Worker identity/mode')
    if not isinstance(w['worker_nonce'], str) or len(w['worker_nonce']) != 32 or any(c not in '0123456789abcdef' for c in w['worker_nonce']):
        raise ValueError('Worker nonce')
    if w['api_calls'] != 1 or type(w['api_calls']) is not int or w['input_reconstructions'] != 3 or type(w['input_reconstructions']) is not int:
        raise ValueError('Single-call/reconstruction contract')
    if any(w[x] is not True for x in ('fresh_process','gc_enabled','preparation_included')):
        raise ValueError('Cold preparation contract')
    ds = [w[k] for k in ('correctness_digest','oracle_digest','direct_digest')]
    if not all(digest(v) for v in ds) or len(set(ds)) != 1 or (expected_oracle is not None and ds[0] != expected_oracle):
        raise ValueError('Independent oracle equality')
    if arm == 'cm_pure' and w['root_outcome'] != 'pure_structural':
        raise ValueError('Primary root outcome')
    for field in ('state_before','state_after'):
        s = w[field]
        if not isinstance(s, dict) or set(s) != {'affinity','nice'} or (state is not None and s != state):
            raise ValueError('Environment state mismatch')
    if w['state_before'] != w['state_after']:
        raise ValueError('Scheduling state drift')
    expected_caches = {'cm_compose','normalize','bitset_env','ir_persistent','ir_alignment'}
    if not isinstance(w['cache_reset'], dict) or set(w['cache_reset']) != expected_caches:
        raise ValueError('Missing cache reset evidence')
    # Exact reset structure is bound to the source-qualified reset implementation.
    from v4_harness import reset_workload_caches
    _, empty = reset_workload_caches()
    if w['cache_reset'] != empty:
        raise ValueError('Cache not empty')
    if kind == 'time':
        if not integer(w['elapsed_ns'], 1) or not integer(w['overhead_ns']) or not integer(w['overhead_max_ns']) or not integer(w['timer_resolution_ns'], 1):
            raise ValueError('Invalid integer timing')
        if w['overhead_max_ns'] < w['overhead_ns'] or 100*w['overhead_ns'] > w['elapsed_ns'] or 100*w['timer_resolution_ns'] > w['elapsed_ns']:
            raise ValueError('Overhead or resolution control failed')
        if w['peak_memory_bytes'] is not None or w['memory_metric'] is not None:
            raise ValueError('Mixed timing/memory')
    else:
        if any(w[k] is not None for k in ('elapsed_ns','overhead_ns','overhead_max_ns','timer_resolution_ns')):
            raise ValueError('Untimed observation contains timing')
        if kind == 'memory':
            if not integer(w['peak_memory_bytes'], 1) or w['memory_metric'] != 'ru_maxrss':
                raise ValueError('Memory metric mismatch')
        elif w['peak_memory_bytes'] is not None or w['memory_metric'] is not None:
            raise ValueError('Untimed correctness contains memory')

def validate_row(row, *, previous=None, expected=None, bindings=None, oracle=None, state=None, kind='time'):
    if not isinstance(row, dict) or set(row) != ROW_FIELDS or row['schema'] != 'cm_pair_v5_elementary':
        raise ValueError('Raw schema fields/version')
    if row['candidate_id'] != CANDIDATE or row['arm_id'] not in ARMS:
        raise ValueError('Candidate/arm mismatch')
    if not isinstance(row['run_id'], str) or not row['run_id']:
        raise ValueError('Run identity')
    for field in ('candidate_manifest_sha256','environment_sha256','corpus_sha256','schedule_sha256',
                  'oracle_manifest_sha256','case_sha256','previous_sha256','row_sha256'):
        if not digest(row[field]): raise ValueError('Invalid hash ' + field)
    if row['corpus_sha256'] != CORPUS_HASH:
        raise ValueError('Corpus binding mismatch')
    for field in ('schedule_index','repetition_index','member_index'):
        if not integer(row[field]): raise ValueError('Invalid index')
    if row['member_index'] >= (1 if kind == 'memory' else MEMBERS):
        raise ValueError('Member index')
    if previous is not None and row['previous_sha256'] != previous:
        raise ValueError('Chain predecessor')
    if row['row_sha256'] != sha256_json({k:v for k,v in row.items() if k != 'row_sha256'}):
        raise ValueError('Row digest')
    if expected is not None and any(row[k] != v for k,v in expected.items()):
        raise ValueError('Schedule mismatch')
    if bindings is not None and any(row[k] != v for k,v in bindings.items()):
        raise ValueError('Run binding mismatch')
    if row['disposition'] == 'ok':
        if row['error'] is not None: raise ValueError('Successful row has error')
        validate_worker(row['worker'], kind=kind, arm=row['arm_id'], expected_oracle=oracle, state=state)
    elif row['disposition'] not in ('timeout','infrastructure_failure','worker_failure','invalid_observation') or not isinstance(row['error'], str) or not row['error']:
        raise ValueError('Failure disposition')

def seal_row(row, previous=ZERO):
    row = dict(row); row['previous_sha256'] = previous
    row['row_sha256'] = sha256_json({k:v for k,v in row.items() if k != 'row_sha256'})
    return row

class Ledger:
    """Exclusive writer. Existing nonempty files cannot be resumed or replaced."""
    def __init__(self, path):
        self.path = Path(path)
        self.lock = self.path.with_suffix(self.path.suffix + '.lock')
        self.handle = self.lock.open('x')
        if self.path.exists() and self.path.stat().st_size:
            self.handle.close()
            raise ValueError('Nonempty ledger; new run identity required')
        self.previous = ZERO
    def append(self, row):
        row = seal_row(row, self.previous)
        validate_row(row)
        with self.path.open('ab') as stream:
            stream.write(canonical_json(row) + b'\n'); stream.flush()
            import os
            os.fsync(stream.fileno())
        self.previous = row['row_sha256']
        return row
    def close(self):
        self.handle.close()  # Leave lock as a permanent no-resume marker.
