"""Fresh-process Protocol v4 runner.

The parent retains every launch attempt. A retry is allowed only for a launch
failure before arm execution, and both attempts remain in the append-only file.
This file does not start a campaign when imported.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid
from typing import Any, Mapping

from row_schema_v4 import REQUIRED_FIELDS, validate_row
from v4_harness import (
    AppendOnlyWriter, PROTOCOL_VERSION, SCHEMA_VERSION, ZERO_SHA256,
    canonical_json, run_single_observation, sha256_file, sha256_json,
)


def _hash_or_zero(path: str | None) -> str:
    return sha256_file(path) if path else ZERO_SHA256


def make_raw_row(*, request: Mapping[str, Any], worker: Mapping[str, Any], attempt_index: int,
                 disposition_override: str | None = None, error_type: str | None = None,
                 error_message: str | None = None) -> dict[str, Any]:
    case=request["case"];kind=request["record_kind"];arm=request["arm_id"]
    hashes=request["hashes"];metrics=dict(worker.get("metrics") or {})
    rows,cols,fixed=case["row_layout"],case["column_layout"],case["fixed_bindings"]
    n_out=len(rows)+len(cols);elements=1<<n_out;artifact=case["output_artifact"]
    payload_bytes=(elements if artifact=="dense" else (elements+7)//8 if artifact=="packed" else 1)
    disposition=disposition_override or worker.get("disposition","infrastructure_failure")
    natural=case.get("stratum")=="G_natural"
    root=metrics.get("root_outcome")
    provenance={"pure_structural":"S","full_retabulation":"T","hybrid_pair":"H"}.get(root)
    strategy={"cm_pure":"pure_structural","cm_hybrid":"hybrid","cm_tabulate":"retabulate"}.get(arm)
    error_type=error_type if error_type is not None else worker.get("error_type")
    error_message=error_message if error_message is not None else worker.get("error_message")
    row={name:None for name in REQUIRED_FIELDS}
    row.update({
        "schema_version":SCHEMA_VERSION,"protocol_version":PROTOCOL_VERSION,"run_id":request["run_id"],
        "manifest_sha256":hashes["manifest_sha256"],"protocol_sha256":hashes["protocol_sha256"],
        "source_manifest_sha256":hashes["source_manifest_sha256"],"analysis_sha256":hashes["analysis_sha256"],
        "row_id":str(uuid.uuid4()),"logical_observation_id":request["logical_observation_id"],"attempt_index":attempt_index,
        "previous_row_sha256":ZERO_SHA256,"record_kind":kind,
        "timestamp_utc":worker.get("timestamp_utc",datetime.now(timezone.utc).isoformat()),
        "process_id":int(worker.get("process_id",0)),"environment_id":request["environment_id"],
        "schedule_index":request["schedule_index"],"order_in_block":request["order_in_block"],
        "case_id":case["case_id"],"case_sha256":case["case_sha256"],"identity_dag_sha256":case["identity_dag_sha256"],
        "structural_syntax_sha256":case["structural_syntax_sha256"],"corpus_id":request["corpus_id"],
        "corpus_manifest_sha256":hashes["corpus_manifest_sha256"],"source_output_id":case.get("source_output_id"),
        "cell_id":case["cell_id"],"stratum":case["stratum"],"generator_seed":case.get("generator_seed"),
        "sharing_class":case["sharing_class"],"natural_source_revision":case.get("natural_source_revision"),
        "natural_license":case.get("natural_license"),"original_file":case.get("original_file"),
        "original_content_sha256":case.get("original_content_sha256"),
        "extraction_manifest_sha256":case.get("extraction_manifest_sha256"),"translation_sha256":case.get("translation_sha256"),
        "original_support_count":case.get("original_support_count",2),"syntactic_unfixed_count":case.get("syntactic_unfixed_count",2),
        "ast_occurrences":case["ast_occurrences"],"unique_object_nodes":case["unique_object_nodes"],
        "ast_height":case["ast_height"],"equal_distinct_subtree_count":case["equal_distinct_subtree_count"],
        "row_layout":rows,"column_layout":cols,"variable_order":rows+cols,"fixed_bindings":fixed,
        "arm_id":arm,"arm_source_sha256":hashes["arm_source_sha256"][arm],
        "endpoint_adapter_sha256":hashes["endpoint_adapter_sha256"],"requested_strategy":strategy,"effective_strategy":strategy,
        "root_outcome":root,"provenance":provenance,
        "token_disposition":"pair" if disposition=="ok" else "no_pair" if disposition=="no_pair" else "invalid_request" if disposition=="invalid_request" else "not_applicable",
        "fallback_executed":bool(root=="ordinary_fallback" and artifact=="dense"),"disposition":disposition,
        "error_type":error_type,"error_message":error_message,"correctness_status":worker.get("correctness_status","not_checked"),
        "output_artifact":artifact,"output_order":"false-first lexicographic; row-major C order",
        "output_shape":[1<<len(rows),1<<len(cols)] if artifact=="dense" else [],
        "output_dtype":"bool" if artifact=="dense" else "uint8-bytes" if artifact=="packed" else "uint4" if artifact=="token" else "bool",
        "n_out":n_out,"output_elements":elements,"output_payload_bytes":payload_bytes,
        "output_information_bits":4 if artifact=="token" else elements,"token_value":worker.get("token_value"),
        "output_owns_data":True if artifact=="dense" and disposition=="ok" else None,
        "output_writeable":True if artifact=="dense" and disposition=="ok" else None,
        "prepared_representation_bytes":metrics.get("prepared_representation_bytes"),"result_object_bytes":worker.get("result_object_bytes"),
        "correctness_digest":worker.get("correctness_digest"),"oracle_digest":worker.get("oracle_digest"),
        "oracle_source_sha256":hashes["oracle_source_sha256"],"semantic_equivalence_method":worker.get("semantic_equivalence_method","not_checked"),
        "output_budget_bytes":65536,"output_budget_vars":16,"output_budget_estimate_bytes":payload_bytes,
        "temporary_estimate_bytes":2*payload_bytes,"output_budget_status":"refused" if disposition=="budget_refused" else "ok",
        "compiler_calls":metrics.get("compiler_calls"),"negation_nodes_scanned":metrics.get("negation_nodes_scanned"),
        "primitive_pair_tokens":metrics.get("primitive_pair_tokens"),"signed_operand_alignments":metrics.get("signed_operand_alignments"),
        "token_negations":metrics.get("token_negations"),"token_fusions":metrics.get("token_fusions"),
        "direct_pair_retabulations":metrics.get("direct_pair_retabulations"),"pair_attempts":metrics.get("pair_attempts"),
        "pair_collapses":metrics.get("pair_collapses"),"support_discovery_passes":metrics.get("support_discovery_passes"),
        "support_unique_visits":metrics.get("support_unique_visits"),"scalar_evaluations":metrics.get("scalar_evaluations"),
        "scalar_occurrence_visits":metrics.get("scalar_occurrence_visits"),
        "discarded_pair_constructions":metrics.get("discarded_pair_constructions"),
        "retained_pair_constructions":metrics.get("retained_pair_constructions"),
        "retabulation_only_mode":metrics.get("retabulation_only_mode",0),"legacy_strategy_alias":metrics.get("legacy_strategy_alias",0),
        "cache_regime":"post_import_cold" if case["reuse_count"]==1 else "prepared_reuse",
        "cache_before":worker.get("cache_before",{}),"cache_after":worker.get("cache_after",{}),
        "import_policy_id":"common_imports_v4","cache_reset_policy_id":"complete_reset_v4","fresh_process":True,
        "warmup_process_id":None,"repetition_index":request["repetition_index"],"reuse_count":case["reuse_count"],
        "query_schedule_sha256":case.get("query_schedule_sha256"),"inner_iterations":1,
        "elapsed_total_ns":worker.get("elapsed_total_ns") if kind=="time" else None,
        "preparation_ns":None,"execution_ns":None,"query_ns":None,"conversion_ns":None,"materialization_ns":None,
        "pair_attempt_ns":None,"fallback_ns":None,
        "peak_process_memory_bytes":worker.get("peak_process_memory_bytes") if kind=="memory" else None,
        "memory_metric":worker.get("memory_metric") if kind=="memory" else None,
        "memory_scope":"absolute_process_including_imports_and_staging" if kind=="memory" else None,
        "memory_adapter_sha256":hashes["memory_adapter_sha256"],"preparation_included":True,
        "sharing_policy":"preserve_identity_dag","result_reuse_policy":f"K={case['reuse_count']}",
        "timeout_seconds":request.get("timeout_seconds",60),"exclusion_reason":case.get("exclusion_reason"),
    })
    row["row_sha256"]=sha256_json({k:v for k,v in row.items() if k!="row_sha256"})
    validate_row(row)
    return row


def launch_one(request: Mapping[str, Any], *, output: str | Path, python: str = sys.executable) -> list[dict[str, Any]]:
    writer=AppendOnlyWriter(Path(output));retained=[]
    for attempt in (0,1):
        command=[python,str(Path(__file__).resolve()),"--worker"]
        env=os.environ.copy();env.update({"PYTHONHASHSEED":"20260923","OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1"})
        try:
            completed=subprocess.run(command,input=canonical_json(request),stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                     timeout=request.get("timeout_seconds",60),env=env,check=False)
        except subprocess.TimeoutExpired as exc:
            worker={};row=make_raw_row(request=request,worker=worker,attempt_index=attempt,
                disposition_override="timeout",error_type="TimeoutExpired",error_message=str(exc)[:500])
            writer.append(row);retained.append(row);break
        if completed.returncode==0:
            try: worker=json.loads(completed.stdout)
            except Exception as exc:
                worker={};row=make_raw_row(request=request,worker=worker,attempt_index=attempt,
                    disposition_override="infrastructure_failure",error_type=type(exc).__name__,error_message="invalid worker JSON")
                writer.append(row);retained.append(row)
                if attempt==0: continue
                break
            row=make_raw_row(request=request,worker=worker,attempt_index=attempt)
            writer.append(row);retained.append(row);break
        row=make_raw_row(request=request,worker={},attempt_index=attempt,
            disposition_override="infrastructure_failure",error_type="WorkerExit",
            error_message=completed.stderr.decode("utf-8","replace")[:500])
        writer.append(row);retained.append(row)
        if attempt==1: break
    return retained


def worker_main() -> int:
    request=json.loads(sys.stdin.buffer.read())
    result=run_single_observation(request["case"],arm_id=request["arm_id"],record_kind=request["record_kind"],
                                  collect_diagnostics=request.get("collect_diagnostics",False),
                                  expected_oracle_digest=request.get("expected_oracle_digest"))
    sys.stdout.buffer.write(canonical_json(result));return 0


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--worker",action="store_true")
    args=parser.parse_args()
    if not args.worker: parser.error("only --worker is directly executable; campaigns require a frozen launcher manifest")
    raise SystemExit(worker_main())
