"""One cold API call. Untimed mode never reads a performance clock."""
from v5_common import *
import gc
import math
import os
import statistics
import time
import uuid
import v4_harness as adapter

def scalar_oracle(case):
    expr, _ = adapter.stage_case(case)
    # Independent scalar truth evaluation, not the direct_packed arm.
    bits = adapter.generic_local_bits(expr, case['row_layout'], case['column_layout'], case['fixed_bindings'])
    out = adapter.bits_to_artifact(bits, case['row_layout'], case['column_layout'], case['output_artifact'])
    return adapter.artifact_digest(out, case['row_layout'], case['column_layout'], case['fixed_bindings'], case['output_artifact'])

def scheduling_state():
    return {'affinity': sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None,
            'nice': os.getpriority(os.PRIO_PROCESS, 0) if hasattr(os, 'getpriority') else None}

def observe(case, arm, *, mode='correctness', clock=None, expected_digest=None):
    if mode not in ('correctness', 'time', 'memory') or arm not in adapter.ARM_IDS:
        raise ValueError('Unknown observation mode/arm')
    before = scheduling_state()
    overhead = overhead_max = resolution = elapsed = peak = metric = None
    if mode == 'time':
        clock = clock or time.perf_counter_ns
        info = time.get_clock_info('perf_counter')
        if not info.monotonic or info.adjustable:
            raise ValueError('Unqualified clock')
        resolution = math.ceil(info.resolution * 1_000_000_000)
        costs = []
        for _ in range(1001):
            a = clock(); b = clock(); costs.append(b - a)
        if any(v < 0 for v in costs):
            raise ValueError('Nonmonotonic clock')
        overhead = int(statistics.median(costs)); overhead_max = max(costs)
    expr, _ = adapter.stage_case(case)
    _, reset = adapter.reset_workload_caches()
    gc.enable(); gc.collect()
    if mode == 'time':
        start = clock()
    # No arm setup takes place before this boundary.
    result, metrics = adapter.run_arm(expr, arm_id=arm, rows=case['row_layout'],
        cols=case['column_layout'], fixed=case['fixed_bindings'], artifact=case['output_artifact'],
        reuse_count=case['reuse_count'], diagnostics=False)
    if mode == 'time':
        elapsed = clock() - start
    if mode == 'memory':
        peak, metric = adapter.peak_process_memory_bytes()
    after = scheduling_state()
    after_cache = adapter._cache_snapshot()
    result_digest = adapter.artifact_digest(result, case['row_layout'], case['column_layout'],
                                           case['fixed_bindings'], case['output_artifact'])
    oracle = scalar_oracle(case)
    direct_expr, _ = adapter.stage_case(case)
    direct = adapter.direct_packed(direct_expr, case['row_layout'], case['column_layout'], case['fixed_bindings'])
    direct_result = adapter.bits_to_artifact(direct, case['row_layout'], case['column_layout'], case['output_artifact'])
    direct_digest = adapter.artifact_digest(direct_result, case['row_layout'], case['column_layout'],
                                           case['fixed_bindings'], case['output_artifact'])
    if result_digest != oracle or direct_digest != oracle or (expected_digest is not None and oracle != expected_digest):
        raise ValueError('Oracle disagreement')
    if case.get('cell_id') == 'primary_B_1023_unshared_token_K1' and arm == 'cm_pure' and metrics.get('root_outcome') != 'pure_structural':
        raise ValueError('Primary provenance failure')
    if before != after:
        raise ValueError('Scheduling controls changed')
    return {'worker_nonce': uuid.uuid4().hex, 'pid': os.getpid(), 'parent_pid': os.getppid(),
            'mode': mode, 'elapsed_ns': elapsed, 'overhead_ns': overhead, 'overhead_max_ns': overhead_max,
            'timer_resolution_ns': resolution, 'peak_memory_bytes': peak, 'memory_metric': metric,
            'cache_reset': reset, 'cache_after': after_cache, 'correctness_digest': result_digest,
            'oracle_digest': oracle, 'direct_digest': direct_digest, 'root_outcome': metrics.get('root_outcome'),
            'state_before': before, 'state_after': after, 'api_calls': 1, 'input_reconstructions': 3,
            'preparation_included': True, 'gc_enabled': gc.isenabled(), 'fresh_process': True}
