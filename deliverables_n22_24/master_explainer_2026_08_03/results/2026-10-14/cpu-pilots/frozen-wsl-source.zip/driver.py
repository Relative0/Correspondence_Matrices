"""Serial measured cells under a shared cgroup parent; no network or file writes."""
from dataclasses import asdict
import json
import os
from pathlib import Path
import sys
import time
from linux_guard import Limits,run,values

HERE=Path(__file__).resolve().parent


def main():
    deadline=time.monotonic()+float(sys.argv[1])-5
    schedule=json.loads((HERE/'SCHEDULE.json').read_text())['cells']
    parent=Path(os.environ['CM_PILOT_CGROUP'])
    stopped=set();digests={}
    for cell in schedule:
        if values(parent/'memory.events').get('max',0)>0 or values(parent/'pids.events').get('max',0)>0:
            print(json.dumps({'status':'global_stop','reason':'shared_kernel_limit_event'}),flush=True);break
        panel=cell['panel']
        if panel in stopped or time.monotonic()+cell['timeout_seconds']+3>=deadline:
            reason='panel_stopped' if panel in stopped else 'global_remaining_time_insufficient'
            print(json.dumps({'cell':cell,'status':'unrun','reason':reason}),flush=True)
            if reason.startswith('global'):stopped.update(c['panel'] for c in schedule)
            continue
        result=run([sys.executable,'-B',str(HERE/'worker.py'),str(cell['cell_id'])],parent=parent,cwd=HERE/'source',
                   limits=Limits(timeout_seconds=cell['timeout_seconds']))
        row=asdict(result);row['stdout']=result.stdout.decode(errors='replace');row['stderr']=result.stderr.decode(errors='replace');row['cell']=cell
        resources=result.resources
        valid=(result.status=='ok' and resources['cleanup_verified'] and not resources.get('stdout_truncated')
               and not resources.get('stderr_truncated') and resources.get('memory_events',{}).get('max',0)==0
               and resources.get('pids_events',{}).get('max',0)==0)
        row['valid']=False
        if valid:
            try:
                parsed=json.loads(row['stdout'])
                assert parsed['valid'] and parsed['cell']==cell and len(parsed['repetitions'])==1
                digest=parsed['repetitions'][0]['delivered_sha256']
                if cell['case'] in digests and digests[cell['case']]!=digest:raise ValueError('paired artifact mismatch')
                digests[cell['case']]=digest;row['result']=parsed;row.pop('stdout');row['valid']=True
            except (AssertionError,ValueError,KeyError,TypeError):row['reason']='malformed_or_mismatched_artifact'
        if not row['valid']:stopped.add(panel)
        print(json.dumps(row),flush=True)
        if not resources['cleanup_verified'] or result.status=='refused':
            print(json.dumps({'status':'global_stop','reason':'shared_infrastructure_failure'}),flush=True);break


if __name__=='__main__':main()
