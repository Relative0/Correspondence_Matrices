"""Prespecified descriptive pilot analysis; no promotion/confirmation claims."""
from collections import defaultdict
import json
from pathlib import Path
from statistics import median
import sys

def analyze(rows):
    groups=defaultdict(list);invalid=[];unrun=[]
    for row in rows:
        if row.get('status')=='unrun':unrun.append(row);continue
        if not row.get('valid'):invalid.append(row);continue
        cell=row['cell'];groups[(cell['case'],cell['lifecycle'])].append(row)
    result=[]
    for (case,lifecycle),records in sorted(groups.items()):
        arms=defaultdict(list)
        for row in records:arms[row['cell']['arm']].append(row)
        totals={arm:median(r['wall_ns'] for r in rs) for arm,rs in arms.items()}
        paired=[]
        if len(arms)==2:
            a,b=sorted(arms);left={r['cell']['pair']:r['wall_ns'] for r in arms[a]};right={r['cell']['pair']:r['wall_ns'] for r in arms[b]}
            paired=[{'pair':i,'numerator_arm':b,'denominator_arm':a,'ratio':right[i]/left[i]} for i in sorted(left.keys()&right.keys())]
        result.append({'case':case,'lifecycle':lifecycle,'valid_cells':len(records),'arm_median_full_lifecycle_ns':totals,
                       'fully_charged_paired_ratios':paired,'complete_pair_set':len(paired)==(3 if lifecycle=='cold' else 5),
                       'prepared_note':'Five independent prepared processes per arm; preparation, validation and all declared queries charged. Small-sample descriptive pilot; no confirmation claim.',
                       'peak_job_committed_bytes':{a:max(r['resources']['peak_job_committed_bytes'] for r in rs) for a,rs in arms.items()}})
    return {'cases':result,'invalid_or_failed_rows':invalid,'unrun_rows':unrun,
            'claims':'Descriptive development pilot only. No pooling across panels/contracts/lifecycles and no universal improvement, equivalence or confirmation claim.',
            'timing_resolution_note':'Cold enclosure includes process startup and supervisor overhead; use recorded phases to understand tiny-operation floor, not to erase overhead.'}

if __name__=='__main__':
    rows=[json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines() if line.strip()]
    print(json.dumps(analyze(rows),indent=2))
