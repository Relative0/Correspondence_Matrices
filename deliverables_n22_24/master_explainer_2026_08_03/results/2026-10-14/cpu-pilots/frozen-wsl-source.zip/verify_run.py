"""Independent completed-run structure, paired hashes and analytical P2/P4 checks."""
import hashlib
import json
from pathlib import Path
from statistics import median
import sys

HERE=Path(__file__).resolve().parent


def load(name):return json.loads((HERE/name).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def expected_hash(case):
    if case['panel']=='P2':
        n=case['n'];parameters=case['parameters'];order=parameters['live_order'];width=len(order)
        a=width-1-order.index(n-2);b=width-1-order.index(n-1)
        hashed=hashlib.sha256()
        for fixed_pair in range(4):
            x0,x1=bool(fixed_pair//2),bool(fixed_pair%2)
            packed=bytearray(max(1,((1<<width)+7)//8))
            for index in range(1<<width):
                xn2,xn1=bool((index>>a)&1),bool((index>>b)&1)
                value=(x0 and xn1)!=((not (x1 or not xn2)) or (x0==xn1))
                packed[index//8]|=int(value)<<(index%8)
            for _ in range(16):hashed.update(packed)
        return hashed.hexdigest()
    if case['panel']=='P4':
        n=case['n'];parameters=case['parameters']
        if case['kind']=='affine':
            value=1<<(n-2-(parameters['pair_count']-1));counts=[value,0,0,value]
        elif case['kind']=='disjoint':
            value=3**(parameters['pair_count']-1);counts=[0,value,value,value]
        else:
            counts=[0]*4
            for index in range(1<<n):
                if all(any(bool((index>>(n-abs(literal)))&1)==(literal>0) for literal in clause) for clause in parameters['clauses']):
                    counts[index>>(n-2)]+=1
        return hashlib.sha256(json.dumps(counts,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return None


def main():
    schedule=load('SCHEDULE.json')['cells'];cases={c['id']:c for c in load('CASES.json')['cases']}
    rows=[json.loads(line) for line in (HERE/'ROWS.jsonl').read_text().splitlines()]
    execution=load('EXECUTION.json');approval=load('APPROVAL.json');qualification=load('HOST_QUALIFICATION.json');startup=load('STARTUP_DEBIT.json')
    checks={'exact_schedule':len(rows)==112 and [r.get('cell') for r in rows]==schedule,
            'source_frozen':all(sha(HERE/name)==digest for name,digest in load('SOURCE_SEAL.json')['files'].items()),
            'grant_source_qualification_debits':approval['seal_sha256']==sha(HERE/'SOURCE_SEAL.json') and approval['qualification_sha256']==sha(HERE/'HOST_QUALIFICATION.json') and approval['startup_debit_sha256']==sha(HERE/'STARTUP_DEBIT.json'),
            'actual_host_qualified':qualification['passed'], 'whole_cleanup':execution['status']=='ok' and execution['resources']['cleanup_verified'],
            'aggregate_elapsed':execution['total_active_wall_seconds']<1200,
            'aggregate_cpu_conservative':startup['conservative_core_seconds']+qualification['conservative_shared_core_debit_seconds']+execution['guardian_cpu_seconds']+execution['resources']['cpu_stat']['usage_usec']/1e6<1200,
            'artifact_cap':sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())<128*1024**2}
    pairs={};per_cell=True;analytical=True;oracle_cells=0
    expected={name:expected_hash(case) for name,case in cases.items()}
    for row in rows:
        cell=row.get('cell',{});resources=row.get('resources',{});result=row.get('result',{})
        if not row.get('valid') or row.get('status')!='ok' or not result.get('valid'):
            per_cell=False;continue
        rb=resources.get('cgroup_readback',{});rep=result['repetitions'][0]
        per_cell &= (rb.get('memory.max')==str(2*1024**3) and rb.get('memory.swap.max')=='0' and rb.get('pids.max')=='4'
                     and rb.get('cpu.max')=='100000 100000' and rb.get('cpuset.cpus','').isdigit()
                     and resources['cleanup_verified'] and resources['cgroup_removed']
                     and resources['memory_events'].get('max',0)==0 and resources['pids_events'].get('max',0)==0
                     and not resources['stdout_truncated'] and not resources['stderr_truncated']
                     and resources['peak_job_committed_bytes']<=2*1024**3 and rep['serialized_bytes']<=64*1024**2)
        key=(cell['case'],cell['lifecycle'],cell['pair']);pairs.setdefault(key,{})[cell['arm']]=rep['delivered_sha256']
        if expected[cell['case']] is not None:
            analytical &= expected[cell['case']]==rep['delivered_sha256'];oracle_cells+=1
    checks.update(all_valid_and_enclosed=per_cell,matching_pairs=len(pairs)==56 and all(len(p)==2 and len(set(p.values()))==1 for p in pairs.values()),
                  independent_P2_P4_digests=analytical and oracle_cells==80)
    resources=execution['resources']
    checks['outer_kernel_limit_events_absent']=resources['memory_events'].get('max',0)==0 and resources['pids_events'].get('max',0)==0
    reproduced=True
    for entry in load('SUMMARY.json')['cases']:
        selected=[r for r in rows if r.get('valid') and r['cell']['case']==entry['case'] and r['cell']['lifecycle']==entry['lifecycle']]
        for arm,value in entry['arm_median_full_lifecycle_ns'].items():
            reproduced &= median(r['wall_ns'] for r in selected if r['cell']['arm']==arm)==value
        for ratio in entry['fully_charged_paired_ratios']:
            def arm_time(arm):return next(r['wall_ns'] for r in selected if r['cell']['pair']==ratio['pair'] and r['cell']['arm']==arm)
            reproduced &= arm_time(ratio['numerator_arm'])/arm_time(ratio['denominator_arm'])==ratio['ratio']
    checks['analysis_independently_reproduced']=reproduced
    output={'passed':all(checks.values()),'checks':checks,'rows':len(rows),'matching_pairs':len(pairs),'analytical_cells':oracle_cells,
            'provider_cleanup':'Not established by this verifier; separate authenticated provider inventory disappearance evidence required.',
            'P1_scope':'Paired canonical/digest equality plus frozen worker independent truth assertions; no independent reconstruction of canonical keys.'}
    with (HERE/'RUN_VERIFICATION.json').open('x') as stream:json.dump(output,stream,indent=2,sort_keys=True)
    print(json.dumps(output))
    if not output['passed']:raise SystemExit(1)


if __name__=='__main__':main()
