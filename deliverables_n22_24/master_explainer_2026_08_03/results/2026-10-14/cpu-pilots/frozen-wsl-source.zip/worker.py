"""Frozen trusted pilot worker. Emits bounded JSON; never writes artifacts."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import_started=time.perf_counter_ns()
import numpy as np
import bitset_backend as bits
import cm_ir
from cm_exprlib import Var,And,Or,Xor,Not,Imp,Eqv
from cm_normalize import lift_cm
from cm_expr_serde import expr_to_json_dag
from cmbench.backends.packed_mask_cache import PackedMaskCache
from cmbench.backends.packed_queries import _execute
from cmbench.backends.affine_constraints import AffineConstraintPlan
from cmbench.backends.factorized_counts import FactorizedCountPlan
from cmbench.backends.bucket_counts import BucketCNFCountPlan
from cmbench.backends.bucket_numpy import NumpyBucketCNFCountPlan
from cmbench.comparative.gf2_projection_optimized import compile_packed_cofactor_plan,project_packed_truth
from cmbench.recognition.gf2_decomposition import analyze_exact_gf2,analyze_screened_exact_gf2
spec=importlib.util.spec_from_file_location('_pilot_legacy_ir',HERE/'legacy/cm_ir.py')
legacy=importlib.util.module_from_spec(spec);sys.modules[spec.name]=legacy;spec.loader.exec_module(legacy)
IMPORT_NS=time.perf_counter_ns()-import_started
MAX_OUTPUT=64*1024**2


class PackedDelivery:
    def __init__(self,values,size):self.values,self.size=values,size


def guard_array(n,itemsize=1):
    if type(n) is not int or not 0<=n<=22 or (1<<n)*itemsize>MAX_OUTPUT:
        raise ValueError('output allocation refused before construction')


def canonical(value):
    if isinstance(value,PackedDelivery):
        if value.size*len(value.values)>MAX_OUTPUT:raise ValueError('packed output limit')
        return b''.join(v.to_bytes(value.size,'little') for v in value.values)
    if isinstance(value,np.ndarray):
        if value.nbytes>MAX_OUTPUT:raise ValueError('array output limit')
        return value.tobytes(order='C')
    if type(value) is int:
        if value<0 or value.bit_length()>MAX_OUTPUT*8:raise ValueError('integer output limit')
        return value.to_bytes(max(1,(value.bit_length()+7)//8),'little')
    if isinstance(value,bytes):
        if len(value)>MAX_OUTPUT:raise ValueError('byte output limit')
        return value
    encoded=json.dumps(value,sort_keys=True,separators=(',',':')).encode()
    if len(encoded)>MAX_OUTPUT:raise ValueError('JSON output limit')
    return encoded


def expr(case):
    n=case['n'];p=case['parameters'];kind=case['kind']
    if kind=='shared':
        e=Or(Var(0),Var(1))
        for _ in range(p['depth']):e=Or(e,e)
        return e
    if kind=='unshared':
        def tree(d,i):
            if not d:return Var(i%min(n,4))
            return And(tree(d-1,i),Or(tree(d-1,i+1),Var((i+2)%min(n,4))))
        return tree(p['depth'],0)
    if kind=='gf2_low_rank':
        return Xor(And(Var(0),Var(n-1)),And(Var(1),Var(n-2)))
    if kind=='mixed':
        shared=Or(Var(1),Not(Var(n-2)))
        return Xor(And(Var(0),Var(n-1)),Imp(shared,Eqv(Var(0),Var(n-1))))
    clauses=cnf(case)
    nodes=[]
    for clause in clauses:
        terms=[Var(abs(v)-1) if v>0 else Not(Var(abs(v)-1)) for v in clause]
        e=terms[0]
        for v in terms[1:]:e=Or(e,v)
        nodes.append(e)
    e=nodes[0]
    for v in nodes[1:]:e=And(e,v)
    return e


def cnf(case):
    n=case['n'];p=case['parameters'];kind=case['kind']
    if kind=='affine':return [c for i in range(p['pair_count']) for c in [(-(2*i+1),2*i+2),(2*i+1,-(2*i+2))]]
    if kind=='disjoint':return [(2*i+1,2*i+2) for i in range(p['pair_count'])]
    if kind=='path':return [tuple(range(i+1,i+5)) for i in range(n-3)]
    if kind=='overlap':return p['clauses']
    raise ValueError('not CNF')


def oracle(expression,names,fixed=None):
    """Independent NumPy Boolean operation oracle, MSB-first named assignments."""
    fixed=fixed or {};n=len(names);guard_array(n,4)
    rows=np.arange(1<<n,dtype=np.uint32)
    env={name:((rows>>(n-1-i))&1).astype(bool) for i,name in enumerate(names)}
    env.update({name:np.full(1<<n,bool(value),dtype=bool) for name,value in fixed.items()})
    memo={}
    def rec(e):
        key=id(e)
        if key in memo:return memo[key]
        if isinstance(e,Var):out=env[f'x{e.i}']
        elif isinstance(e,Not):out=np.logical_not(rec(e.a))
        else:
            a,b=rec(e.a),rec(e.b)
            if isinstance(e,And):out=np.logical_and(a,b)
            elif isinstance(e,Or):out=np.logical_or(a,b)
            elif isinstance(e,Xor):out=np.logical_xor(a,b)
            elif isinstance(e,Imp):out=np.logical_or(np.logical_not(a),b)
            elif isinstance(e,Eqv):out=np.equal(a,b)
            else:raise TypeError(type(e).__name__)
        memo[key]=out;return out
    value=rec(expression)
    # Literal scalar assignments independently cross-check the array route on
    # every assignment through width 8 and fixed boundary rows on wider inputs.
    indices=range(1<<n) if n<=8 else [0,1,(1<<n)//2,(1<<n)-1]
    def scalar(e,assignment,memo):
        key=id(e)
        if key in memo:return memo[key]
        if isinstance(e,Var):out=assignment[f'x{e.i}']
        elif isinstance(e,Not):out=not scalar(e.a,assignment,memo)
        else:
            a,b=scalar(e.a,assignment,memo),scalar(e.b,assignment,memo)
            if isinstance(e,And):out=a and b
            elif isinstance(e,Or):out=a or b
            elif isinstance(e,Xor):out=a!=b
            elif isinstance(e,Imp):out=(not a) or b
            elif isinstance(e,Eqv):out=a==b
            else:raise TypeError(type(e).__name__)
        memo[key]=out;return out
    for index in indices:
        assignment={name:bool((index>>(n-1-i))&1) for i,name in enumerate(names)}
        assignment.update({name:bool(v) for name,v in fixed.items()})
        # Fresh identity memo per assignment; source Boolean semantics remain independent.
        if bool(value[index])!=scalar(expression,assignment,{}):raise AssertionError('oracle routes disagree')
    return int.from_bytes(np.packbits(value,bitorder='little').tobytes(),'little')


def build(case,arm,phases):
    def timed(name,fn):
        start=time.perf_counter_ns();value=fn();phases[name]+=time.perf_counter_ns()-start;return value
    n=case['n'];guard_array(n,4);names=tuple(f'x{i}' for i in range(n));expression=timed('parse',lambda:expr(case)) if case['kind']!='gf2_random' else None
    if not case['id'].startswith('control-'):
        def check_source():
            expected=next(r for r in json.loads((HERE/'CASE_INPUTS.json').read_text())['case_inputs'] if r['case']==case['id'])
            document=expr_to_json_dag(expression) if expression is not None else {'truth_hex':case['parameters']['truth_hex'],'n':n}
            actual=hashlib.sha256(json.dumps(document,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            if actual!=expected['source_sha256']:raise ValueError('case generator/input byte drift')
        timed('parse',check_source)
    if case['panel']=='P1':
        module=legacy if arm=='legacy_compile' else cm_ir
        module.clear_cm_ir_compile_cache()
        digest=timed('hash',lambda:module._persistent_digest(expression,{}))
        node=timed('compile',lambda:module.compile_expr_to_cm_ir(expression,reuse_cache=True))
        expected=timed('validation',lambda:oracle(expression,names))
        def query():
            node=module.compile_expr_to_cm_ir(expression,reuse_cache=True)
            return node
        def validate(node):
            actual=bits.eval_cm_node_flat(node,names)
            if actual!=expected:raise AssertionError('P1 exact truth mismatch')
            return {'canonical_key':repr(node.key),'truth':hex(actual),'persistent_digest':digest.hex()}
        return query,validate,{'compile_admission':'current guard; legacy only on frozen shallow acyclic common domain'}
    if case['panel']=='P2':
        prefix=case['parameters']['prefix'];q=case['parameters']['queries']
        if not 0<=prefix<n or q>1<<prefix:raise ValueError('query contract')
        order=case['parameters'].get('live_order',list(range(prefix,n)))
        if sorted(order)!=list(range(prefix,n)):raise ValueError('residual axis contract')
        live=tuple(names[i] for i in order)
        contexts=[{names[j]:(i>>(prefix-1-j))&1 for j in range(prefix)} for i in range(q)]
        expected=timed('validation',lambda:[oracle(expression,live,fixed) for fixed in contexts])
        if arm=='full_cofactor':
            program=timed('compile',lambda:bits.compile_expr_cse(expression,flatten=True))
            cache=PackedMaskCache(max_bytes=32*1024**2,max_width=22)
            full=timed('preparation',lambda:_execute(program,names,{},cache))
            plans=timed('preparation',lambda:[compile_packed_cofactor_plan(n,f,live) for f in contexts])
            query=lambda:[project_packed_truth(full,p) for p in plans]
        else:
            node=timed('compile',lambda:cm_ir.compile_expr_to_cm_ir(expression))
            program=timed('compile',lambda:bits.get_flat_program(node))
            cache=PackedMaskCache(max_bytes=32*1024**2,max_width=22)
            timed('preparation',lambda:cache.environment(live))
            query=lambda:[_execute(program,live,f,cache) for f in contexts]
        def validate(values):
            if values!=expected:raise AssertionError('P2 restriction/layout mismatch')
            # Serialize every requested packed vector at its declared width,
            # including zero padding; never substitute a list of hash digests.
            size=max(1,((1<<len(live))+7)//8)
            if size*len(values)>MAX_OUTPUT:raise ValueError('packed batch output cap')
            return PackedDelivery(values,size)
        return query,validate,{'queries':q,'remaining_order':live,'fixed_prefix':prefix}
    if case['panel']=='P4':
        clauses=cnf(case);contexts=[{'x0':i//2,'x1':i%2} for i in range(4)]
        expected=timed('validation',lambda:[oracle(expression,names[2:],fixed).bit_count() for fixed in contexts])
        if arm=='affine':plan=timed('preparation',lambda:AffineConstraintPlan([3<<(2*i) for i in range(case['parameters']['pair_count'])],[0]*case['parameters']['pair_count'],names))
        elif arm=='factorized':
            program=timed('compile',lambda:bits.compile_expr_cse(expression,flatten=True))
            plan=timed('preparation',lambda:FactorizedCountPlan(program,names,cache=PackedMaskCache(max_bytes=1024**2,max_width=16)))
        else:
            plan=timed('preparation',lambda:BucketCNFCountPlan(clauses,names,max_width=12,max_cells=1<<16,max_work=1<<22))
            if arm=='numpy_bucket':plan=timed('copies',lambda:NumpyBucketCNFCountPlan(plan,max_array_cells=1<<16))
        def query():return [plan.count(f) for f in contexts]
        def validate(values):
            if values!=expected:raise AssertionError('P4 exact count mismatch')
            return values
        return query,validate,{'queries':4,'plan_stats':getattr(plan,'stats',None),'count_semantics':'full assignments under fixed prefix; exact arbitrary integers'}
    if case['panel']=='P3':
        order=case['parameters']['order'];wanted=tuple(names[i] for i in order)
        expected=timed('validation',lambda:oracle(expression,wanted))
        if arm=='dense_gather':
            node=timed('compile',lambda:cm_ir.compile_expr_to_cm_ir(expression))
            guard_array(n)
            dense=timed('preparation',lambda:cm_ir.materialize_cm(node,list(names[:n//2]),list(names[n//2:])))
            query=lambda:lift_cm(dense,list(names[:n//2]),list(names[n//2:]),list(wanted[:n//2]),list(wanted[n//2:])).reshape(-1)
        else:
            node=timed('compile',lambda:cm_ir.compile_expr_to_cm_ir(expression))
            full=timed('preparation',lambda:bits.eval_cm_node_flat(node,names))
            plan=timed('preparation',lambda:compile_packed_cofactor_plan(n,{},wanted))
            # Deliver the same dense Boolean artifact, charging packing/unpacking.
            query=lambda:np.unpackbits(np.frombuffer(project_packed_truth(full,plan).to_bytes((1<<n)//8,'little'),dtype=np.uint8),bitorder='little').astype(bool)
        def validate(value):
            actual=int.from_bytes(np.packbits(value,bitorder='little').tobytes(),'little')
            if actual!=expected:raise AssertionError('P3 dense/layout mismatch')
            return value
        return query,validate,{'order':wanted,'artifact':'complete dense Boolean vector; packed transport conversion charged'}
    if case['panel']=='P5':
        full=int(case['parameters']['truth_hex'],16) if case['kind']=='gf2_random' else timed('preparation',lambda:oracle(expression,names))
        # Fixed common portfolio, including balanced and skewed cuts.
        partitions=[(i,) for i in range(n)]+[tuple(range(n//2)),tuple(range(1,n))]
        analyzer=analyze_exact_gf2 if arm=='gf2_exhaustive' else analyze_screened_exact_gf2
        result=timed('preparation',lambda:analyzer(full,n,row_partitions=partitions))
        def query():return result.best
        def validate(best):
            if best is None:return {'best':None,'source':hex(full)}
            if best.reconstruct()!=full:raise AssertionError('P5 reconstruction mismatch')
            return {'best':best.document,'source':hex(full)}
        return query,validate,{'partitions':partitions,'materialized_artifacts':result.artifacts_materialized,'contract':'canonical best exact artifact only, not complete portfolio enumeration'}
    raise ValueError('panel')


def execute(case,arm,repetitions):
    phases={k:0 for k in ['parse','hash','compile','preparation','copies','query','validation','serialization','teardown']}
    start=time.perf_counter_ns();cpu=time.process_time_ns()
    query,validate,metadata=build(case,arm,phases)
    rows=[]
    for index in range(repetitions):
        q=time.perf_counter_ns();value=query();query_ns=time.perf_counter_ns()-q;phases['query']+=query_ns
        v=time.perf_counter_ns();delivered=validate(value);phases['validation']+=time.perf_counter_ns()-v
        s=time.perf_counter_ns();payload=canonical(delivered);phases['serialization']+=time.perf_counter_ns()-s
        rows.append({'repetition':index,'query_ns':query_ns,'delivered_sha256':hashlib.sha256(payload).hexdigest(),'serialized_bytes':len(payload)})
        if rows[-1]['delivered_sha256']!=rows[0]['delivered_sha256']:raise AssertionError('repeated output drift')
    t=time.perf_counter_ns();del query,validate;phases['teardown']+=time.perf_counter_ns()-t
    return {'case':case['id'],'panel':case['panel'],'arm':arm,'valid':True,'phases_ns':phases,
            'worker_wall_ns':time.perf_counter_ns()-start,'worker_cpu_ns':time.process_time_ns()-cpu,
            'import_ns':IMPORT_NS,'repetitions':rows,'metadata':metadata,'validation_charged':True,
            'timing_note':'outer lifecycle includes startup/import/worker/teardown; five independent prepared paired sessions each include preparation plus the complete declared query sequence'}


def main():
    if sys.argv[1]=='--admission':
        cases=json.loads((HERE/'CASES.json').read_text())['cases'];records=[]
        for case in cases:
            if case['kind']=='gf2_random':
                document={'truth_hex':case['parameters']['truth_hex'],'n':case['n']};count,depth=0,0
            else:
                expression=expr(case);document=expr_to_json_dag(expression)
                visited=set();stack=[(expression,1)];depth=0
                while stack:
                    node,d=stack.pop();depth=max(depth,d)
                    if id(node) in visited:continue
                    visited.add(id(node))
                    if isinstance(node,Not):stack.append((node.a,d+1))
                    elif not isinstance(node,Var):stack.extend([(node.a,d+1),(node.b,d+1)])
                count=len(visited)
                if count>10000 or depth>256:raise ValueError('frozen source admission')
            encoded=json.dumps(document,sort_keys=True,separators=(',',':')).encode()
            records.append({'case':case['id'],'n':case['n'],'unique_nodes':count,'depth':depth,
                            'source_document':document,'source_sha256':hashlib.sha256(encoded).hexdigest()})
        print(json.dumps({'case_inputs':records,'measurement_cells_executed':0,'source_generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}));return
    if sys.argv[1]=='--controls':
        controls=[{'panel':'P1','id':'control-compile','kind':'mixed','n':4,'arms':['legacy_compile','current_compile'],'parameters':{}},
                  {'panel':'P2','id':'control-packed','kind':'mixed','n':10,'arms':['full_cofactor','cm_residual'],'parameters':{'prefix':6,'queries':4}},
                  {'panel':'P4','id':'control-count','kind':'affine','n':8,'arms':['affine','bucket'],'parameters':{'pair_count':2}},
                  {'panel':'P4','id':'control-factorized','kind':'disjoint','n':6,'arms':['factorized','bucket'],'parameters':{'pair_count':3}},
                  {'panel':'P4','id':'control-numpy','kind':'overlap','n':6,'arms':['bucket','numpy_bucket'],'parameters':{'clauses':[[1,-2,3],[-1,2,4],[2,-4,5],[-3,5,-6]]}},
                  {'panel':'P3','id':'control-layout','kind':'mixed','n':6,'arms':['dense_gather','packed_layout'],'parameters':{'order':[1,2,0,3,4,5]}},
                  {'panel':'P5','id':'control-gf2','kind':'gf2_low_rank','n':4,'arms':['gf2_exhaustive','gf2_screened'],'parameters':{'max_partitions':6}}]
        if len(sys.argv)>2:
            panels=set(sys.argv[2].split(','));controls=[c for c in controls if c['panel'] in panels]
        if len(sys.argv)>3:
            ids=set(sys.argv[3].split(','));controls=[c for c in controls if c['id'] in ids]
        rows=[]
        for case in controls:
            pair=[execute(case,arm,2) for arm in case['arms']]
            if pair[0]['repetitions'][0]['delivered_sha256']!=pair[1]['repetitions'][0]['delivered_sha256']:raise AssertionError('control pair mismatch')
            rows+=pair
        print(json.dumps({'non_holdout_controls':True,'pairs':len(controls),'valid':True,'rows':rows}))
        return
    cell_id=int(sys.argv[1]);schedule=json.loads((HERE/'SCHEDULE.json').read_text());cell=schedule['cells'][cell_id]
    case=next(c for c in json.loads((HERE/'CASES.json').read_text())['cases'] if c['id']==cell['case'])
    result=execute(case,cell['arm'],cell.get('paired_repetitions',1));result['cell']=cell
    print(json.dumps(result))


if __name__=='__main__':main()
