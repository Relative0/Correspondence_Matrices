"""Untimed small semantic/regression controls; no scheduled pilot cells."""
import json
import contextlib
import io
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import worker as w
import driver
import launch
from verify_run import expected_hash
from linux_guard import Limits, Result, cpus
from analyze import analyze

HERE=Path(__file__).resolve().parent


class SuccessorTests(unittest.TestCase):
    def test_shared_dag_scalar_oracle(self):
        case={'kind':'shared','n':4,'parameters':{'depth':16}}
        self.assertEqual(w.oracle(w.expr(case),('x0','x1','x2','x3')),0xfff0)

    def test_active_axis_order_has_observable_effect(self):
        expression=w.expr({'kind':'mixed','n':10,'parameters':{}})
        natural=('x6','x7','x8','x9');permuted=('x9','x6','x8','x7')
        effects=[]
        for a in range(4):
            fixed={f'x{i}':0 for i in range(6)};fixed.update(x0=a//2,x1=a%2)
            first=w.oracle(expression,natural,fixed);second=w.oracle(expression,permuted,fixed)
            effects.append(first!=second)
            # Independent literal arithmetic reduction of the actual expression.
            expected=0
            for index in range(16):
                assignment=dict(fixed)
                assignment.update({name:(index>>(3-i))&1 for i,name in enumerate(permuted)})
                x0,x1,x8,x9=(bool(assignment[k]) for k in ('x0','x1','x8','x9'))
                bit=(x0 and x9)!=((not (x1 or not x8)) or (x0==x9))
                expected|=int(bit)<<index
            self.assertEqual(second,expected)
        self.assertTrue(any(effects))

    def test_arms_match_on_small_active_order(self):
        case={'id':'control-active-order','panel':'P2','kind':'mixed','n':10,
              'parameters':{'prefix':6,'queries':64,'live_order':[9,6,8,7]}}
        results=[w.execute(case,arm,1) for arm in ('full_cofactor','cm_residual')]
        self.assertEqual(results[0]['repetitions'][0]['delivered_sha256'],results[1]['repetitions'][0]['delivered_sha256'])
        self.assertEqual(results[0]['repetitions'][0]['delivered_sha256'],expected_hash(case))

    def test_independent_structured_count_hashes(self):
        controls=[{'id':'control-affine','panel':'P4','kind':'affine','n':8,'parameters':{'pair_count':2}},
                  {'id':'control-disjoint','panel':'P4','kind':'disjoint','n':6,'parameters':{'pair_count':3}},
                  {'id':'control-overlap','panel':'P4','kind':'overlap','n':6,'parameters':{'clauses':[[1,-2,3],[-1,2,4],[2,-4,5],[-3,5,-6]]}}]
        for case in controls:
            result=w.execute(case,'bucket',1)
            self.assertEqual(result['repetitions'][0]['delivered_sha256'],expected_hash(case))

    def test_schedule_is_balanced_and_complete(self):
        cells=json.loads((HERE/'SCHEDULE.json').read_text())['cells']
        self.assertEqual(len(cells),112)
        self.assertEqual([c['cell_id'] for c in cells],list(range(112)))
        for case in json.loads((HERE/'CASES.json').read_text())['cases']:
            if case['panel']=='P2':
                self.assertEqual(sorted(case['parameters']['live_order']),list(range(6,case['n'])))
            for lifecycle,count in [('cold',3),('prepared',5)]:
                selected=[c for c in cells if c['case']==case['id'] and c['lifecycle']==lifecycle]
                self.assertEqual(len(selected),2*count)
                self.assertEqual([c['arm'] for c in selected[:2]],list(reversed([c['arm'] for c in selected[2:4]])))

    def test_limits_reject_invalid_inputs(self):
        for limit in (Limits(timeout_seconds=float('nan')),Limits(timeout_seconds=1200),Limits(memory_bytes=3*1024**3),Limits(processes=8)):
            with self.assertRaises(ValueError):limit.validate()
        self.assertEqual(cpus('0-2,4'),{0,1,2,4})
        with self.assertRaises(ValueError):cpus('4-1')

    def test_failed_pairs_not_imputed(self):
        output=analyze([{'status':'timeout','valid':False},{'status':'unrun','reason':'budget'}])
        self.assertEqual(output['cases'],[])
        self.assertEqual(len(output['invalid_or_failed_rows']),1)
        self.assertEqual(len(output['unrun_rows']),1)

    def test_driver_stops_mismatched_panel(self):
        schedule=json.loads((HERE/'SCHEDULE.json').read_text())['cells']
        calls=[]
        def fake_run(command,**kwargs):
            cell=schedule[int(command[-1])];calls.append(cell)
            digest='different' if cell['cell_id']==1 else 'same'
            value={'valid':True,'cell':cell,'repetitions':[{'delivered_sha256':digest}]}
            return Result('ok','completed',0,json.dumps(value).encode(),resources={
                'cleanup_verified':True,'stdout_truncated':False,'stderr_truncated':False,'memory_events':{},'pids_events':{}})
        output=io.StringIO()
        with patch.object(driver,'run',fake_run),patch.object(driver,'values',return_value={}),patch.object(sys,'argv',['driver.py','1100']),patch.dict(os.environ,CM_PILOT_CGROUP='/sys/fs/cgroup/test'),contextlib.redirect_stdout(output):
            driver.main()
        rows=[json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual(len(rows),112)
        self.assertFalse(rows[1]['valid'])
        self.assertTrue(all(row['status']=='unrun' for row in rows[2:32]))
        self.assertTrue(any(c['panel']=='P4' for c in calls))

    def test_driver_stops_whole_schedule_on_cleanup_failure(self):
        result=Result('error','cleanup_unverified',resources={'cleanup_verified':False})
        output=io.StringIO()
        with patch.object(driver,'run',return_value=result) as runner,patch.object(driver,'values',return_value={}),patch.object(sys,'argv',['driver.py','1100']),patch.dict(os.environ,CM_PILOT_CGROUP='/sys/fs/cgroup/test'),contextlib.redirect_stdout(output):
            driver.main()
        self.assertEqual(runner.call_count,1)
        self.assertEqual(json.loads(output.getvalue().splitlines()[-1])['status'],'global_stop')

    def test_driver_refuses_shared_kernel_limit_event(self):
        output=io.StringIO()
        with patch.object(driver,'run') as runner,patch.object(driver,'values',return_value={'max':1}),patch.object(sys,'argv',['driver.py','1100']),patch.dict(os.environ,CM_PILOT_CGROUP='/sys/fs/cgroup/test'),contextlib.redirect_stdout(output):
            driver.main()
        runner.assert_not_called()
        self.assertEqual(json.loads(output.getvalue())['reason'],'shared_kernel_limit_event')

    def test_invalid_startup_debit_cannot_launch(self):
        grant={'user_message':'test only','execution_count':1,'seal_sha256':'fixed','qualification_sha256':'fixed','startup_debit_sha256':'fixed'}
        with patch.object(launch,'sha',return_value='fixed'):
            for debit in ({'active_wall_seconds':float('nan')}, {'active_wall_seconds':-1},
                          {'active_wall_seconds':0,'measured_core_seconds':10,'conservative_core_seconds':1}):
                with self.assertRaises(ValueError):launch.validate_grant(grant,{}, {'passed':True,'runtime':{}},debit)


if __name__=='__main__':unittest.main()
