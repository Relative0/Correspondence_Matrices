"""Fail-closed hierarchical cgroup-v2 supervisor for reviewed CPU workers."""
from dataclasses import dataclass, field
import math
import os
from pathlib import Path
import selectors
import subprocess
import sys
import time
import uuid

CONTROLLERS = {'cpu', 'cpuset', 'memory', 'pids'}


def values(path):
    result = {}
    for line in path.read_text().splitlines():
        key, value = line.split()
        if key in result or not value.isascii() or not value.isdigit():
            raise ValueError('invalid cgroup telemetry')
        result[key] = int(value)
    return result


def cpus(value):
    out = set()
    for part in value.strip().split(','):
        pair = part.split('-')
        first, last = int(pair[0]), int(pair[-1])
        if len(pair)>2 or first<0 or last<first or last-first>4096:
            raise ValueError('invalid cpuset')
        out.update(range(first,last+1))
    return out


@dataclass(frozen=True)
class Limits:
    timeout_seconds: float = 20
    memory_bytes: int = 2*1024**3
    processes: int = 4  # Linux pids controller bounds tasks, including threads.
    stdout_bytes: int = 1024**2
    stderr_bytes: int = 65536
    branch: bool = False

    def validate(self):
        if type(self.timeout_seconds) not in (int,float) or not math.isfinite(self.timeout_seconds) or not .05<=self.timeout_seconds<=1100:
            raise ValueError('wall limit')
        if type(self.memory_bytes) is not int or not 16*1024**2<=self.memory_bytes<=2*1024**3:
            raise ValueError('memory limit')
        if self.processes!=4 or any(type(v) is not int or not 1<=v<=1024**2 for v in (self.stdout_bytes,self.stderr_bytes)):
            raise ValueError('task/output limit')


@dataclass
class Result:
    status: str
    reason: str
    returncode: int|None = None
    stdout: bytes = b''
    stderr: bytes = b''
    wall_ns: int = 0
    resources: dict = field(default_factory=dict)


class Scope:
    def __init__(self,parent,limits):
        self.parent=Path(parent).resolve();self.limits=limits;self.path=None;self.leaf=None;self.readback={}

    def create(self):
        self.limits.validate()
        root=Path('/sys/fs/cgroup').resolve()
        if not sys.platform.startswith('linux') or not self.parent.is_relative_to(root):
            raise RuntimeError('Linux cgroup-v2 parent required')
        if not CONTROLLERS<=set((self.parent/'cgroup.subtree_control').read_text().split()):
            raise RuntimeError('delegated cpu/cpuset/memory/pids controllers required; no parent edits or RSS fallback')
        eligible=cpus((self.parent/'cpuset.cpus.effective').read_text()) & os.sched_getaffinity(0)
        if not eligible:raise RuntimeError('no eligible logical CPU')
        cpu=min(eligible)
        os.sched_setaffinity(0,{cpu})
        if os.sched_getaffinity(0)!={cpu}:raise RuntimeError('guardian affinity failed')
        self.path=self.parent/('cm-pilot-'+str(uuid.uuid4()))
        self.path.mkdir()
        settings={'memory.max':str(self.limits.memory_bytes),'memory.swap.max':'0','memory.oom.group':'1',
                  'pids.max':str(self.limits.processes),'cpu.max':'100000 100000',
                  'cpuset.cpus':str(cpu),'cpuset.mems':(self.parent/'cpuset.mems.effective').read_text().strip()}
        try:
            for name,value in settings.items():(self.path/name).write_text(value)
            self.readback={name:(self.path/name).read_text().strip() for name in settings}
            if self.readback!=settings or cpus((self.path/'cpuset.cpus.effective').read_text())!={cpu}:
                raise RuntimeError('kernel limit readback mismatch')
            # Require telemetry and recursive kill before any worker starts.
            for name in ('cgroup.kill','cgroup.events','memory.events','memory.peak','pids.events','pids.peak','cpu.stat'):
                if not (self.path/name).is_file():raise RuntimeError('required cgroup interface missing: '+name)
            self.leaf=self.path
            if self.limits.branch:
                (self.path/'cgroup.subtree_control').write_text('+cpu +cpuset +memory +pids')
                self.leaf=self.path/'controller';self.leaf.mkdir()
            return self.readback
        except BaseException:
            self.close()
            raise

    def command(self,command):
        bootstrap="import os,sys; p=sys.argv[1]; open(p+'/cgroup.procs','w').write(str(os.getpid())); os.execv(sys.argv[2],sys.argv[2:])"
        return [sys.executable,'-I','-B','-c',bootstrap,str(self.leaf),*command]

    def close(self):
        if self.path is None:return {'cleanup_verified':True,'cgroup_removed':True}
        result={'cleanup_verified':False,'cgroup_removed':False}
        try:
            (self.path/'cgroup.kill').write_text('1')
            end=time.monotonic()+2
            while values(self.path/'cgroup.events').get('populated')!=0:
                if time.monotonic()>=end:raise RuntimeError('owned cgroup remained populated')
                time.sleep(.005)
            result.update(cleanup_verified=True, memory_events=values(self.path/'memory.events'),
                          pids_events=values(self.path/'pids.events'),cpu_stat=values(self.path/'cpu.stat'),
                          peak_job_committed_bytes=int((self.path/'memory.peak').read_text()),
                          memory_metric='cgroup_v2_memory_peak_not_Windows_committed_memory',
                          pids_peak=int((self.path/'pids.peak').read_text()))
            # Remove only owned descendants after emptiness proof; no recursive shell deletion.
            for child in sorted((p for p in self.path.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):
                if values(child/'cgroup.events').get('populated')!=0:raise RuntimeError('child populated')
                child.rmdir()
            self.path.rmdir();result['cgroup_removed']=not self.path.exists()
            result['cleanup_verified'] &= result['cgroup_removed']
        except (OSError,ValueError,RuntimeError) as exc:
            result.update(cleanup_verified=False,cleanup_error=str(exc))
        return result


def run(command,*,parent,cwd=None,limits=Limits()):
    limits.validate()
    if not isinstance(command,list) or not command or not Path(command[0]).is_absolute() or any(not isinstance(v,str) or '\0' in v for v in command):
        raise ValueError('explicit executable and arguments required')
    began=time.monotonic_ns();deadline=time.monotonic()+limits.timeout_seconds
    scope=Scope(parent,limits);process=None;selector=selectors.DefaultSelector();buffers={'stdout':bytearray(),'stderr':bytearray()}
    result=Result('refused','qualification_failed',resources={'launched':False,'cleanup_verified':False,'aggregate_memory_limit_is_kernel_enforced':True})
    exceeded=set()
    try:
        readback=scope.create()
        env=os.environ.copy()
        env.update(PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',CM_RUNPOD_DISABLE_ENV_FILES='1')
        for key in tuple(env):
            if key.startswith(('RUNPOD_','CM_RUNPOD_')) and key!='CM_RUNPOD_DISABLE_ENV_FILES':env.pop(key)
        if limits.branch:env['CM_PILOT_CGROUP']=str(scope.path)
        process=subprocess.Popen(scope.command(command),cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,bufsize=0)
        result.resources.update(launched=True,cgroup_readback=readback,cgroup_path=str(scope.path),attached_before_target_exec=True)
        for name in buffers:
            pipe=getattr(process,name);os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,name)
        result.status='ok';result.reason='completed'
        while selector.get_map() or process.poll() is None:
            if time.monotonic()>=deadline:
                result.status='timeout';result.reason='wall_limit';break
            for key,_ in selector.select(min(.01,max(0,deadline-time.monotonic()))):
                name=key.data;maximum=getattr(limits,name+'_bytes')
                chunk=os.read(key.fileobj.fileno(),min(65536,maximum-len(buffers[name])+1))
                if not chunk:selector.unregister(key.fileobj);continue
                room=maximum-len(buffers[name]);buffers[name].extend(chunk[:room])
                if len(chunk)>room:exceeded.add(name)
            if exceeded:result.status='limit';result.reason='output_limit';break
        if process.poll() is not None and process.returncode and result.status=='ok':result.status='error';result.reason='worker_exit'
    except (OSError,ValueError,RuntimeError) as exc:
        result.status='refused' if process is None else 'error';result.reason=str(exc)
    finally:
        result.resources.update(scope.close())
        if process is not None:
            try:result.returncode=process.wait(timeout=2)
            except subprocess.TimeoutExpired:result.resources['cleanup_verified']=False
        for key in list(selector.get_map().values()):
            selector.unregister(key.fileobj)
        selector.close()
        if process is not None:
            for name in buffers:getattr(process,name).close()
        result.resources.update(streams_closed=True,stdout_truncated='stdout' in exceeded,stderr_truncated='stderr' in exceeded)
        if not result.resources['cleanup_verified']:result.status='error';result.reason='cleanup_unverified'
        result.stdout=bytes(buffers['stdout']);result.stderr=bytes(buffers['stderr']);result.wall_ns=time.monotonic_ns()-began
    return result
