"""Small untimed correctness/admission tests; no scheduled cases executed."""
import copy
import hashlib
import json
import unittest
import trial as t
from linux_guard import Limits, cpus
from verify_run import expected_digest


class TrialTests(unittest.TestCase):
    def control(self,sharing,restricted=True,q=64):
        case=copy.deepcopy(t.cases()[2 if sharing=='shared' else 3])
        case.update(n=14,sharing=sharing)
        case['live_order']=['x13','x8','x11','x6','x12','x7','x10','x9']
        if not restricted:
            case.update(n=12,fixed_axes=[],contexts=[{}],q=1,
                        live_order=[f'x{i}' for i in [11,0,9,2,7,4,5,6,3,8,1,10]])
        return case

    def test_small_all_routes_and_independent_scalar(self):
        for sharing in ('shared','unshared'):
            for restricted in (False,True):
                case=self.control(sharing,restricted)
                expected=[]
                for context in case['contexts']:
                    data=bytearray(t.admitted(case))
                    for row in range(1 << len(case['live_order'])):
                        env={name:(row>>(len(case['live_order'])-1-i))&1 for i,name in enumerate(case['live_order'])}
                        env.update(context)
                        data[row//8] |= t.scalar_formula(case,env) << (row%8)
                    self.assertEqual(bytes(data),t.oracle_bytes(case,context))
                    expected.append(bytes(data))
                for arm in ('raw','cse','cm','words'):
                    t.reset()
                    expr=t.expr_from_json(json.loads(t.source_bytes(case)))
                    program,cache,execute=t.prepare(case,arm,expr)
                    actual=[execute(c).to_bytes(t.admitted(case),'little') for c in case['contexts']]
                    self.assertEqual(actual,expected,(sharing,restricted,arm))
                if restricted: self.assertEqual(len(set(expected)),64)
                digest,contexts=expected_digest(case)
                self.assertEqual(digest,hashlib.sha256(b''.join(expected)).hexdigest())
                self.assertEqual(contexts,[hashlib.sha256(data).hexdigest() for data in expected])

    def test_schedule_and_real_support(self):
        cases=t.cases(); cells=t.schedule(cases)
        self.assertEqual(len(cells),112)
        for case in cases:
            functions=[t.anf(case,c) for c in case['contexts']]
            self.assertEqual(len(set(functions)),case['q'])
            for poly in functions:
                support=set().union(*(set(m) for m in poly))
                self.assertTrue(set(case['live_order']).issubset(support))
            for lifecycle,count in [('cold',3),('prepared',5)]:
                selected=[c for c in cells if c['case']==case['id'] and c['lifecycle']==lifecycle]
                self.assertEqual(len(selected),2*count)
                self.assertEqual([c['arm'] for c in selected[:2]],list(reversed([c['arm'] for c in selected[2:4]])))

    def test_invalid_contracts_refused(self):
        for mutate in (lambda c:c.update(n=23),lambda c:c.update(live_order=['x6']*10),
                       lambda c:c['contexts'].__setitem__(0,c['contexts'][1]),
                       lambda c:c['contexts'][0].update(x0=2)):
            case=copy.deepcopy(t.cases()[2]); mutate(case)
            with self.assertRaises(ValueError): t.admitted(case)

    def test_permutation_changes_actual_bytes(self):
        case=self.control('shared'); altered=copy.deepcopy(case)
        altered['live_order']=sorted(case['live_order'],key=lambda s:int(s[1:]))
        self.assertTrue(any(t.oracle_bytes(case,c)!=t.oracle_bytes(altered,c) for c in case['contexts']))

    def test_supervisor_admission(self):
        self.assertEqual(cpus('0-2,4'),{0,1,2,4})
        for limits in (Limits(timeout_seconds=float('nan')),Limits(memory_bytes=3*1024**3),Limits(processes=5)):
            with self.assertRaises(ValueError): limits.validate()


if __name__=='__main__': unittest.main()
