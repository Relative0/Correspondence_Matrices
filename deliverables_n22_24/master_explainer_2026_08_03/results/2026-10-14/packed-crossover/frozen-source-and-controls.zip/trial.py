"""Frozen synthetic crossover definitions and adapters. No default measurements."""
from pathlib import Path
import hashlib
import json
import random
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'source'))
import numpy as np
import bitset_backend as bits
import cm_ir
from cm_exprlib import Var, And, Or, Xor
from cm_expr_serde import expr_to_json, expr_from_json
from cmbench.backends.packed_mask_cache import PackedMaskCache

MAX_OUTPUT = 64 * 1024**2
SEED = 20261014


def cases():
    # Seven edges, 14 arm/case entries, eight fresh sessions each = 112 cells.
    specs = [
        (12, 'shared', 'full', 1, ('raw', 'cse')),
        (12, 'unshared', 'full', 1, ('raw', 'cse')),
        (16, 'shared', 'restriction', 64, ('cse', 'cm')),
        (16, 'unshared', 'restriction', 64, ('cse', 'cm')),
        (22, 'shared', 'full', 1, ('cse', 'words')),
        (20, 'unshared', 'full', 1, ('cse', 'words')),
        (22, 'shared', 'restriction', 1, ('cse', 'words')),
    ]
    out = []
    for index, (n, sharing, task, q, arms) in enumerate(specs):
        fixed_axes = list(range(6)) if task == 'restriction' else []
        live = list(range(len(fixed_axes), n))
        # A seeded nontrivial permutation moves influential live axes.
        random.Random(SEED + index).shuffle(live)
        if live == sorted(live): live = live[1:] + live[:1]
        codes = list(range(64)) if q == 64 else ([37] if fixed_axes else [0])
        random.Random(SEED + 100 + index).shuffle(codes)
        contexts = [{f'x{i}': (code >> (5-i)) & 1 for i in fixed_axes} for code in codes]
        out.append(dict(id=f'{sharing}-{n}-{task}-q{q}', n=n, sharing=sharing,
                        task=task, q=q, arms=list(arms), seed=SEED+index,
                        live_order=[f'x{i}' for i in live], contexts=contexts,
                        fixed_axes=fixed_axes, selector_codes=codes,
                        output_bytes=q * max(1, (1 << len(live)) // 8)))
    return out


def expression(case):
    n = case['n']
    variables = [Var(i) for i in range(n)]
    tail = variables[6:]
    # Degree-one parity guarantees every tail axis remains influential after
    # any restriction: every additional term has degree >= 2 on distinct axes.
    value = tail[0]
    for variable in tail[1:]: value = Xor(value, variable)
    # Six distinct quadratic monomials encode 64 genuinely different contexts.
    for i in range(6):
        value = Xor(value, And(variables[i], And(tail[i], tail[(i+1) % len(tail)])))
    if case['sharing'] == 'shared':
        # Repeated nonlinear supports favor structural reuse. Tree persistence
        # preserves occurrences; each arm receives identical deserialized input.
        for i in range(min(4, len(tail)-3)):
            common = And(tail[i], tail[i+1])
            value = Xor(value, Or(And(common, tail[i+2]), And(common, tail[i+3])))
    else:
        # No repeated internal subtrees: a negative sharing control, same live
        # support and six selectors, with a different nontrivial connective mix.
        for i in range(min(4, len(tail)-3)):
            value = Xor(value, And(tail[i], Or(tail[i+2], tail[i+3])))
    return value


def source_bytes(case):
    return (json.dumps(expr_to_json(expression(case)), sort_keys=True,
                       separators=(',', ':'))+'\n').encode()


def admitted(case):
    n = case['n']; live = case['live_order']; contexts = case['contexts']
    if type(n) is not int or not 8 <= n <= 22: raise ValueError('width cap')
    wanted = {f'x{i}' for i in range(n)}
    fixed = {f'x{i}' for i in case['fixed_axes']}
    if len(live) != len(set(live)) or set(live) != wanted-fixed: raise ValueError('basis')
    if len(contexts) != case['q'] or case['q'] not in (1,64): raise ValueError('q')
    if any(set(c) != fixed or any(type(v) is not int or v not in (0,1) for v in c.values()) for c in contexts):
        raise ValueError('fixed contexts')
    if len({json.dumps(c, sort_keys=True) for c in contexts}) != len(contexts): raise ValueError('duplicate contexts')
    size = max(1, ((1 << len(live))+7)//8)
    if size*len(contexts) > MAX_OUTPUT: raise ValueError('output cap')
    return size


def scalar_formula(case, assignment):
    """Independent closed Boolean formula: no Expr/CM/flat dispatch."""
    tail = [bool(assignment[f'x{i}']) for i in range(6, case['n'])]
    result = sum(tail) % 2 == 1
    for i in range(6): result ^= bool(assignment[f'x{i}']) and tail[i] and tail[(i+1)%len(tail)]
    for i in range(min(4,len(tail)-3)):
        if case['sharing'] == 'shared': result ^= tail[i] and tail[i+1] and (tail[i+2] or tail[i+3])
        else: result ^= tail[i] and (tail[i+2] or tail[i+3])
    return int(result)


def oracle_bytes(case, fixed, chunk_width=12):
    """Independent formula, bounded unpacked chunks. Complete canonical bytes.

    No backend mask generation, source evaluator, cofactor, or compiler reused.
    """
    live = case['live_order']; width = len(live); total = 1 << width
    result = bytearray()
    for start in range(0,total,1 << chunk_width):
        rows = np.arange(start,min(total,start+(1 << chunk_width)),dtype=np.uint32)
        env = {name: ((rows >> (width-1-i)) & 1).astype(bool) for i,name in enumerate(live)}
        env.update({name:bool(value) for name,value in fixed.items()})
        tail = [env[f'x{i}'] for i in range(6,case['n'])]
        value = np.zeros(len(rows),dtype=bool)
        for column in tail: value ^= column
        for i in range(6): value ^= env[f'x{i}'] & tail[i] & tail[(i+1)%len(tail)]
        for i in range(min(4,len(tail)-3)):
            if case['sharing'] == 'shared': value ^= tail[i] & tail[i+1] & (tail[i+2] | tail[i+3])
            else: value ^= tail[i] & (tail[i+2] | tail[i+3])
        result.extend(np.packbits(value,bitorder='little').tobytes())
    return bytes(result)


def prepare(case, arm, expression_value, phase=lambda name,fn:fn()):
    """Returns program, cache, execute. All setup is charged by worker phases."""
    live = tuple(case['live_order'])
    if arm == 'raw':
        env = phase('mask_environment',lambda:bits.build_bitset_env(live))
        return None, env, lambda fixed: bits.eval_expr_bitset(expression_value, env, fixed=fixed)
    if arm == 'cm':
        node = phase('compile',lambda:cm_ir.compile_expr_to_cm_ir(expression_value, reuse_cache=False))
        program = phase('compile',lambda:bits.get_flat_program(node))
    else: program = phase('compile',lambda:bits.compile_expr_cse(expression_value, flatten=True))
    if arm == 'words':
        # Plan/environment are explicit preparation. Scratch allocation and
        # uint64->bytes->int conversion remain in the first query, not hidden.
        program.word_plan = phase('word_plan',lambda:bits._compute_word_plan(program))
        env = phase('mask_environment_including_int_to_words',lambda:bits._build_words_env_cached(live))
        return program, env, lambda fixed: bits._eval_words(program,live,fixed)
    if arm not in ('cse','cm'): raise ValueError('arm unavailable')
    cache = PackedMaskCache(max_bytes=32*1024**2,max_width=22)
    env = phase('mask_environment',lambda:cache.environment(live))
    full = phase('mask_environment',lambda:(1 << (1 << len(live))) - 1)
    def execute(fixed):
        # Bind once per context to avoid retaining 64 full slot templates.
        def bind():
            template = [0]*program.n_slots
            for slot,kind,payload in program.loads:
                template[slot] = (full if payload else 0) if kind == 'const' else ((full if fixed[payload] else 0) if payload in fixed else env[payload])
            return bits.PreparedFlatEvaluation(program,template,full,True)
        prepared=phase('binding',bind)
        return prepared.evaluate()
    return program, cache, execute


def schedule(case_list):
    cells = []
    for case in case_list:
        for lifecycle,count,timeout in [('cold',3,20),('prepared',5,45)]:
            for pair in range(count):
                arms = case['arms'] if pair%2 == 0 else list(reversed(case['arms']))
                for arm in arms:
                    cells.append(dict(cell_id=len(cells), case=case['id'], arm=arm,
                                      lifecycle=lifecycle, pair=pair, timeout_seconds=timeout))
    return cells


def reset():
    bits.clear_bitset_env_cache(); bits.clear_words_env_cache(); cm_ir.clear_cm_ir_compile_cache()


def anf(case, context):
    """Independent algebraic support/context certificate, no truth allocation."""
    def add(a,b): return a ^ b
    def mul(a,b):
        out=set()
        for x in a:
            for y in b: out.symmetric_difference_update({x|y})
        return out
    def either(a,b): return add(add(a,b),mul(a,b))
    env={f'x{i}':({frozenset()} if context[f'x{i}'] else set()) if f'x{i}' in context else {frozenset({f'x{i}'})} for i in range(case['n'])}
    tail=[env[f'x{i}'] for i in range(6,case['n'])]
    value=set()
    for a in tail: value=add(value,a)
    for i in range(6): value=add(value,mul(env[f'x{i}'],mul(tail[i],tail[(i+1)%len(tail)])))
    for i in range(min(4,len(tail)-3)):
        term=mul(tail[i],either(tail[i+2],tail[i+3]))
        if case['sharing']=='shared': term=mul(tail[i+1],term)
        value=add(value,term)
    return tuple(sorted(tuple(sorted(m)) for m in value))
