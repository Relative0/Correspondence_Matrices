"""Independent run structure, polynomial artifact hashes and paired analysis."""
import hashlib
import json
from pathlib import Path
from statistics import median
import sys
import trial as t

HERE=Path(__file__).resolve().parent


def expected_digest(case):
    # ANF monomial evaluation is independent of the worker's Boolean formula
    # and all candidate compilers/masks. Chunked full enumeration, no sampling.
    digest=hashlib.sha256(); context_hashes=[]
    width=len(case['live_order']); count=1 << width
    for context in case['contexts']:
        context_hash=hashlib.sha256()
        poly=t.anf(case,context)
        for start in range(0,count,4096):
            rows=t.np.arange(start,min(count,start+4096),dtype=t.np.uint32)
            env={name:((rows>>(width-1-i))&1).astype(bool) for i,name in enumerate(case['live_order'])}
            value=t.np.zeros(len(rows),dtype=bool)
            for monomial in poly:
                term=t.np.ones(len(rows),dtype=bool)
                for name in monomial: term &= env[name]
                value ^= term
            data=t.np.packbits(value,bitorder='little').tobytes()
            digest.update(data); context_hash.update(data)
        context_hashes.append(context_hash.hexdigest())
    return digest.hexdigest(),context_hashes


def verify(rows,schedule,cases):
    checks={'exact_schedule':len(rows)==len(schedule) and [r.get('cell') for r in rows]==schedule,
            'all_valid':all(r.get('valid') and r.get('status')=='ok' for r in rows)}
    expected={c['id']:expected_digest(c) for c in cases}
    semantic=True; resources_ok=True; pairs={}; analyses=[]
    for row in rows:
        cell=row.get('cell',{}); result=row.get('result',{}); r=row.get('resources',{})
        expected_hash,expected_contexts=expected.get(cell.get('case'),('',[]))
        semantic &= result.get('delivered_sha256')==expected_hash and result.get('context_hashes')==expected_contexts
        rb=r.get('cgroup_readback',{})
        resources_ok &= (r.get('cleanup_verified') and r.get('cgroup_removed') and not r.get('stdout_truncated')
                         and not r.get('stderr_truncated') and not r.get('memory_events',{}).get('max',0)
                         and not r.get('pids_events',{}).get('max',0) and rb.get('memory.max')=='2147483648'
                         and rb.get('memory.swap.max')=='0' and rb.get('cpu.max')=='100000 100000'
                         and rb.get('pids.max')=='4' and rb.get('cpuset.cpus')=='0'
                         and r.get('peak_job_committed_bytes',2**63)<=2147483648
                         and result.get('serialized_bytes',2**63)<=64*1024**2)
        pairs.setdefault((cell.get('case'),cell.get('lifecycle'),cell.get('pair')),{})[cell.get('arm')]=row
    checks.update(independent_complete_artifacts=semantic,resources_and_cleanup=bool(resources_ok),
                  complete_pairs=len(pairs)==56 and all(len(p)==2 for p in pairs.values()))
    for case in cases:
        for lifecycle in ('cold','prepared'):
            arm_a,arm_b=case['arms']; ratios=[]; sample={arm_a:[],arm_b:[]}
            for key,pair in pairs.items():
                if key[:2]!=(case['id'],lifecycle) or set(pair)!={arm_a,arm_b}: continue
                ratios.append({'pair':key[2],'ratio_b_over_a':pair[arm_b]['wall_ns']/pair[arm_a]['wall_ns']})
                for arm in sample: sample[arm].append(pair[arm]['wall_ns'])
            analyses.append({'case':case['id'],'lifecycle':lifecycle,'numerator':arm_b,'denominator':arm_a,
                             'paired_ratios':ratios,'median_ns':{a:median(s) if s else None for a,s in sample.items()},
                             'min_max_ns':{a:[min(s),max(s)] if s else [] for a,s in sample.items()}})
    return {'passed':all(checks.values()),'checks':checks,'analysis':analyses,'rows':len(rows),
            'interpretation':'Descriptive synthetic case-level paired ratios; no universal dispatch threshold or inference about scalar counts/74181.'}


def main():
    rows=[json.loads(s) for s in (HERE/'ROWS.jsonl').read_text().splitlines()]
    result=verify(rows,json.loads((HERE/'SCHEDULE.json').read_text())['cells'],json.loads((HERE/'CASES.json').read_text())['cases'])
    execution=json.loads((HERE/'EXECUTION.json').read_text())
    seal=json.loads((HERE/'SOURCE_SEAL.json').read_text())
    result['checks'].update(source_preserved=all(hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest for name,digest in seal['files'].items()),
        runtime_preserved=all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest for name,digest in json.loads((HERE/'PREPARATION_HOST.json').read_text())['runtime']['files'].items()),
        shared_cleanup=execution['resources'].get('cleanup_verified') and execution['resources'].get('cgroup_removed'),
        shared_limits=not execution['resources'].get('memory_events',{}).get('max',0) and not execution['resources'].get('pids_events',{}).get('max',0),
        artifacts=sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())<128*1024**2)
    result['passed']=all(result['checks'].values())
    with (HERE/'RUN_VERIFICATION.json').open('x') as stream: json.dump(result,stream,indent=2,sort_keys=True)
    if not result['passed']: raise SystemExit(1)


if __name__=='__main__': main()
