"""One granted cell, fresh process; no writes. Never imported for measurement."""
import hashlib
import json
from pathlib import Path
import sys
import time

IMPORT_BEGAN = time.perf_counter_ns()
import trial as t
from cm_expr_serde import expr_from_json
IMPORT_NS = time.perf_counter_ns()-IMPORT_BEGAN
HERE = Path(__file__).resolve().parent


def execute(case, arm):
    t.admitted(case); t.reset()
    phases = {}
    def phase(name, operation):
        began = time.perf_counter_ns(); value = operation()
        phases[name] = phases.get(name,0)+time.perf_counter_ns()-began
        return value
    source = phase('source_read',lambda: (HERE/'inputs'/f"{case['id']}.json").read_bytes())
    if hashlib.sha256(source).hexdigest() != case['source_sha256']: raise ValueError('source drift')
    expression = phase('parse',lambda: expr_from_json(json.loads(source)))
    program, cache, query = t.prepare(case,arm,expression,phase)
    digest = hashlib.sha256(); sizes = []; context_hashes = []
    size = t.admitted(case)
    for context in case['contexts']:
        binding_before=phases.get('binding',0)
        actual = phase('bind_and_query_including_word_conversion',lambda: query(context))
        # Binding is nested inside integer execution. Avoid double-counting
        # that recorded component when reporting the exclusive query phase.
        phases['bind_and_query_including_word_conversion']-=phases.get('binding',0)-binding_before
        data = phase('serialization',lambda: actual.to_bytes(size,'little'))
        expected = phase('validation',lambda: t.oracle_bytes(case,context))
        if data != expected: raise AssertionError('complete artifact mismatch')
        phase('delivery_hash',lambda: digest.update(data))
        context_hashes.append(hashlib.sha256(data).hexdigest()); sizes.append(len(data))
    if case['q'] == 64 and len(set(context_hashes)) != 64: raise AssertionError('effectively redundant contexts')
    del expression, query, program, cache, actual, data, expected
    phase('teardown',t.reset)
    return dict(valid=True,phases_ns=phases,import_ns=IMPORT_NS,
                delivered_sha256=digest.hexdigest(),context_hashes=context_hashes,
                serialized_bytes=sum(sizes), max_single_output_bytes=max(sizes),
                conversion='words kernel converts uint64->bytes->int; final int->fixed-width LE bytes charged',
                preparation='fresh process, compile/environment once; fixed binding per query; no uncharged warmups')


def main():
    if not (HERE/'APPROVAL.json').exists() or not (HERE/'LAUNCH_STARTED.json').exists():
        raise SystemExit('Performance execution requires a new matching one-execution grant and supervised launch.')
    cells=json.loads((HERE/'SCHEDULE.json').read_text())['cells']; cell=cells[int(sys.argv[1])]
    case=next(c for c in json.loads((HERE/'CASES.json').read_text())['cases'] if c['id']==cell['case'])
    result=execute(case,cell['arm']); result['cell']=cell
    print(json.dumps(result),flush=True)


if __name__ == '__main__': main()
