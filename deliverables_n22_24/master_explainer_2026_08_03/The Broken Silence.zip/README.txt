THE BROKEN SILENCE
A Prime Directive First-Contact Archetype Game
3-5 players | 65-90 minutes | Two improvised scenes

------------------------------------------------------------
HOW TO OPEN
------------------------------------------------------------
Double-click "The Broken Silence.html".

It opens in any modern web browser (Chrome, Edge, Firefox,
Safari) on Windows, macOS, Linux, iOS or Android. No internet
connection is required and nothing needs to be installed.

------------------------------------------------------------
WHAT'S INSIDE THE FILE
------------------------------------------------------------
Everything. The page is a single self-contained document:
the typefaces, the Pelagos IV viewport image, all styling and
all interactivity are embedded directly in the HTML. You can
email it, drop it on a USB stick, or put it in a shared folder
and it will look identical wherever it lands.

------------------------------------------------------------
USING IT
------------------------------------------------------------
* Top navigation jumps to any section - useful mid-session.
* In the Archetypes grid, click any name (e.g. "The Priest")
  to jump to that role's full card.
* Each role card has a link to its counterpart, so a player
  can follow their own pair forwards and backwards.
* The sun/moon button top-right switches light and dark.
  Dark reads well on a projector or in a dim room.

------------------------------------------------------------
PRINTING / PDF
------------------------------------------------------------
Ctrl+P (Cmd+P on Mac) is set up for it: the navigation bar is
hidden and role cards are kept from breaking across pages.
Choose "Save as PDF" as the destination for a shareable PDF.

To hand players a role privately, print just their two cards
using the page range in the print dialog.

------------------------------------------------------------
TYPEFACES
------------------------------------------------------------
Newsreader, IBM Plex Sans and IBM Plex Mono are embedded under
the SIL Open Font License 1.1, which permits redistribution
inside a document like this one.
